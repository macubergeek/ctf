/*
 * ========================================================================
 * Copyright 2006 University of Washington
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * ========================================================================
 *
 *
 *	Tim Rice	tim@trr.metro.net	Mon Jun  3 16:57:26 PDT 1996
 *
 *	a quick and dirty trancate()
 *	Altos System V (5.3.1) does not have one
 *	neither does SCO Open Server Enterprise 3.0
 *
 */
