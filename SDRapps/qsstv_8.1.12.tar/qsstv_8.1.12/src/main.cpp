/**************************************************************************
*   Copyright (C) 2000-2012 by Johan Maes                                 *
*   on4qz@telenet.be                                                      *
*   http://users.telenet.be/on4qz                                         *
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
*   This program is distributed in the hope that it will be useful,       *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
*   GNU General Public License for more details.                          *
*                                                                         *
*   You should have received a copy of the GNU General Public License     *
*   along with this program; if not, write to the                         *
*   Free Software Foundation, Inc.,                                       *
*   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
***************************************************************************/

#include <QApplication>

#include <QtGui>
//#include <QCDEStyle>
#include "qsstvglobal.h"
#include "mainwindow.h"
#include "dsp/filterparam.h"
#include "dsp/filter.h"
#include <QPixmap>
#include <QSplashScreen>
#include <QTimer>

QSplashScreen *splash;



int main( int argc, char ** argv )
{
  int result=TRUE;
  QTimer tm;
  tm.setSingleShot(TRUE);
  QApplication::setColorSpec( QApplication::ManyColor );
  QApplication app( argc, argv );
  QCoreApplication::setOrganizationName(ORGANIZATION);
  QCoreApplication::setApplicationName(APPLICATION);
  QPixmap pixmap(":/icons/qsstvsplash.png");
  QSplashScreen splash(pixmap,Qt::WindowStaysOnTopHint);
  splashPtr=&splash;
  splash.show();
  splashStr="\n\n\n";
  splashStr+=QString( "Starting QSSTV").rightJustified(25,' ')+"\n";
  splash.showMessage (splashStr,Qt::AlignLeft,Qt::white);
  tm.start(5);
  globalInit();
  mainWindowPtr=new mainWindow;
  mainWindowPtr->setWindowIcon(QPixmap(":/icons/qsstv.png"));
//  qDebug()<< QImageReader::supportedImageFormats();
  while(1)
  {
    app.processEvents();
    if(!tm.isActive()) break;
   }
  mainWindowPtr->init(); // this must follow show() because window has to be drawn first to determine fftframe window size
  mainWindowPtr->hide();
  splash.finish(mainWindowPtr);
  mainWindowPtr->show();
  result=app.exec();
  globalEnd();
  return result;
}

