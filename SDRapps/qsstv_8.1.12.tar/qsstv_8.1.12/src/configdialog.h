#ifndef CONFIGDIALOG_H
#define CONFIGDIALOG_H

#include "ui_configform.h"

/** @author Johan Maes - ON4QZ */






class configForm;

//! configuration Dialog

class configDialog: public QDialog, private Ui::configForm
{
Q_OBJECT
public:
    configDialog(QWidget *parent = 0, const char *name = 0);
    ~configDialog();
		void writeSettings();
		void readSettings();
    int exec();

		
public slots:
		void slotBrowseRxImagesPath();
		void slotBrowseTxImagesPath();
		void slotBrowseTemplatesPath();
		void slotBrowseAudioPath();
    void slotRp1BrowseButton();
    void slotRp2BrowseButton();
    void slotRp3BrowseButton();
    void slotRp4BrowseButton();
    void slotRepeaterTemplateBrowseButton();
    void slotIdleTemplateBrowseButton();


private:
		void getParams();
		void setParams();

};



#endif
