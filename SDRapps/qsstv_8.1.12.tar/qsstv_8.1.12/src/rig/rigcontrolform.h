#ifndef RIGCONTROLFORM_H
#define RIGCONTROLFORM_H

#include <QWidget>


namespace Ui {
class rigControlForm;
}

class rigControlForm : public QWidget
{
  Q_OBJECT
  
public:
  explicit rigControlForm(QWidget *parent = 0);
  ~rigControlForm();
  void readSettings();
  void writeSettings();
  void setParams();
  bool needsRestart() { return changed;}

public slots:
  void slotEnableCAT();
  void slotEnablePTT();
  void slotRestart();
  
private:
  Ui::rigControlForm *ui;
  bool changed;
  void getParams();
};

#endif // RIGCONTROLFORM_H
