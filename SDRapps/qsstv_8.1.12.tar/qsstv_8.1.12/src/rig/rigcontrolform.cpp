#include "rigcontrolform.h"
#include "ui_rigcontrolform.h"
#include "qsstvglobal.h"
#include "configparams.h"
#include "utils/supportfunctions.h"
#include "rig/rigcontrol.h"
#include <QSettings>

rigControlForm::rigControlForm(QWidget *parent) :
  QWidget(parent),
  ui(new Ui::rigControlForm)
{
  ui->setupUi(this);
  connect(ui->enableCATCheckBox,SIGNAL(clicked()),SLOT(slotEnableCAT()));
  connect(ui->enablePTTCheckBox,SIGNAL(clicked()),SLOT(slotEnablePTT()));
  connect(ui->restartPushButton,SIGNAL(clicked()),SLOT(slotRestart()));
}


rigControlForm::~rigControlForm()
{
  delete ui;
}

void rigControlForm::readSettings()
{
  QSettings qSettings;
  qSettings.beginGroup("RigControl");
  serialPort=qSettings.value("serialPort","/dev/ttyS0").toString();
  radioModel=qSettings.value("radioModel","dummy").toString();
  civAddress=qSettings.value("civAddress",0x70).toInt();
  baudrate=qSettings.value("baudrate",9600).toInt();
  parity=qSettings.value("parity","None").toString();
  stopbits=qSettings.value("stopbits",1).toInt();
  databits=qSettings.value("databits",8).toInt();
  handshake=qSettings.value("handshake","None").toString();
  enableCAT=qSettings.value("enableCAT",0).toBool();
  enableSerialPTT=qSettings.value("enableSerialPTT",0).toBool();
  pttSerialPort=qSettings.value("pttSerialPort",pttSerialPort).toString();
  qSettings.endGroup();
  setParams();
}

void rigControlForm::writeSettings()
{
  getParams();
  QSettings qSettings;
  qSettings.beginGroup("RigControl");
  qSettings.setValue("serialPort",serialPort);
  qSettings.setValue("radioModel",radioModel);
  qSettings.setValue("civAddress",civAddress);
  qSettings.setValue("baudrate",baudrate);
  qSettings.setValue("parity",parity);
  qSettings.setValue("stopbits",stopbits);
  qSettings.setValue("databits",databits);
  qSettings.setValue("handshake",handshake);
  qSettings.setValue("enableCAT",enableCAT);
  qSettings.setValue("enableSerialPTT",enableSerialPTT);
  qSettings.setValue("pttSerialPort",pttSerialPort);
  qSettings.endGroup();
}

void rigControlForm::setParams()
{
  if(rigController->getRadioList(ui->radioModelComboBox)) setValue(radioModel,ui->radioModelComboBox);
  setValue(serialPort,ui->serialPortLineEdit);
  setValue(civAddress,ui->civAddressLineEdit);
  setValue(baudrate,ui->baudrateComboBox);
  setValue(parity,ui->parityComboBox);
  setValue(stopbits,ui->stopbitsComboBox);
  setValue(databits,ui->databitsComboBox);
  setValue(handshake,ui->handshakeComboBox);
  setValue(enableCAT,ui->enableCATCheckBox);
  setValue(enableSerialPTT,ui->enablePTTCheckBox);
  setValue(pttSerialPort,ui->pttSerialPortLineEdit);
}

void rigControlForm::getParams()
{
  getValue(serialPort,ui->serialPortLineEdit);
  if(ui->radioModelComboBox->count()!=0) getValue(radioModel,ui->radioModelComboBox);
  getValue(civAddress,ui->civAddressLineEdit);
  getValue(baudrate,ui->baudrateComboBox);
  getValue(parity,ui->parityComboBox);
  getValue(stopbits,ui->stopbitsComboBox);
  getValue(databits,ui->databitsComboBox);
  getValue(handshake,ui->handshakeComboBox);
  getValue(enableCAT,ui->enableCATCheckBox);
  getValue(enableSerialPTT,ui->enablePTTCheckBox);
  getValue(pttSerialPort,ui->pttSerialPortLineEdit);
}

void rigControlForm::slotEnableCAT()
{
  if(ui->enableCATCheckBox->isChecked())
  {
    ui->enablePTTCheckBox->setChecked(FALSE);
    rigController->init();
  }
  else rigController->disable();
  getParams();
}

void rigControlForm::slotEnablePTT()
{
   if(ui->enablePTTCheckBox->isChecked())
  {
     ui->enableCATCheckBox->setChecked(FALSE);
     rigController->disable();
   }
   getParams();
}

void rigControlForm::slotRestart()
{
  if(ui->enableCATCheckBox->isChecked()) rigController->init();;
}
