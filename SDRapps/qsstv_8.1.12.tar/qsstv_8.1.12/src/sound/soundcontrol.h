#ifndef SOUNDCONTROL_H
#define SOUNDCONTROL_H

#include <QWidget>

namespace Ui {
  class soundControl;
  }

class soundControl : public QWidget
{
  Q_OBJECT
  
public:
  explicit soundControl(QWidget *parent = 0);
  ~soundControl();
  void readSettings();
  void writeSettings();
  void setParams();
  bool needsRestart() { return changed;}


private:
  Ui::soundControl *ui;
  int inputAudioDeviceIndex;
  int outputAudioDeviceIndex;
  bool changed;
  void getParams();
};

#endif // SOUNDCONTROL_H
