/***************************************************************************
 *   Copyright (C) 2000-2012 by Johan Maes                                 *
 *   on4qz@telenet.be                                                      *
 *   http://users.telenet.be/on4qz                                         *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "wavio.h"
#include "qsstvglobal.h"
#include <qfiledialog.h>
#include "configparams.h"
#include "utils/supportfunctions.h"
#include "unistd.h"

/**
	constructor: creates a waveIO instance
	\param samplingRate wave file samplingrate (e.g. 8000, 11025 ...)
*/

wavIO::wavIO(unsigned int samplingRate)
{
	samplingrate=samplingRate;
	reading=FALSE,
	writing=FALSE;
}


wavIO::~wavIO()
{
}

void wavIO::closeFile()
{
	inopf.close();
	reading=FALSE;
	writing=FALSE;
}

/**
	 opens a wave file for reading
	\param fname the name of the file to open
	\param ask if ask==TRUE, a filedialog will be opened
	\return TRUE if the file is succcesfully opened. The file is also checked if it is a supported format.
	\sa read
*/ 

bool  wavIO::openFileForRead(QString fname,bool ask)
{
  QString tmp;
	
  if (ask)
    {
                dirDialog d((QWidget *)mainWindowPtr,"Wave file",TRUE);
                d.show();
                QString s=d.openFileName(audioPath,"*",TRUE);
				if (s==QString::null) return FALSE;
				if (s.isEmpty()) return FALSE;
       	inopf.setFileName(s);
    }
  else
    {
      inopf.setFileName(fname);
    }
  if(!inopf.open(QIODevice::ReadOnly))
    {
    return FALSE;
    }
	reading=TRUE;
  if(inopf.read(&waveHeader.chunkID[0],sizeof(sWave))!=sizeof(sWave))
    {
			closeFile();
      return FALSE;
    }


// check the header
  if(  (!checkString(waveHeader.chunkID,"RIFF"))
     ||(!checkString(waveHeader.format,"WAVE"))
     ||(!checkString(waveHeader.subChunk1ID,"fmt "))
     ||(!checkString(waveHeader.subChunk2ID,"data")))
     {
      addToLog("wavio read header error",LOGALL);
			closeFile();
      return FALSE;
     }

  if( (waveHeader.subChunk1Size!=16)
      ||(waveHeader.audioFormat!=1)
      ||(waveHeader.numChannels>MAXNUMCHANNELS)
      ||(waveHeader.sampleRate!=samplingrate)
      ||(waveHeader.byteRate!=sizeof(SOUNDFRAME)*samplingrate)
      ||(waveHeader.blockAlign!=4)
      ||(waveHeader.bitsPerSample!=16))
      {
        addToLog("wavio read header error, not supported",LOGALL);
				closeFile();
        return FALSE;
      }

  numberOfSamples=waveHeader.subChunk2Size/sizeof(SOUNDFRAME);
  numberOfChannels=waveHeader.numChannels;
	samplesRead=0;
	return TRUE;
}

/**
	read data from wave file

	\param dPtr pointer to buffer for 16 bit samples
	\param numSamples  number of samples to read
	\return returns the nummber of samples read. -1 is returned if the end of the file is reached. The file is then automatically closed.
*/

int  wavIO::read(SOUNDFRAME *dPtr ,uint numSamples)
{
	int llen,result;
	if(!inopf.isOpen())
		{
      addToLog("wavio not open during read",LOGALL);
      return -2;
		}
  llen=numSamples*sizeof(SOUNDFRAME);
	if(numberOfSamples<=samplesRead)
		{
			closeFile();
			return -1;
		}
	result=inopf.read((char*)dPtr,llen);
	if(result==0) inopf.close();
  samplesRead+=result/sizeof(SOUNDFRAME);
  return result/sizeof(SOUNDFRAME);
}

/**
	 opens a wave file for writing
	\param fname the name of the file to open
	\param ask if ask==TRUE, a filedialog will be opened
	\return TRUE if the file is succcesfully opened, and the header written, FALSE otherwise?
	\sa write
*/

bool  wavIO::openFileForWrite(QString fname,bool ask)
{
  QFileInfo fin;
  if (ask)
    {
            dirDialog d((QWidget *)mainWindowPtr,"wave IO",TRUE);
            d.show();
			QString fn=d.saveFileName(audioPath,"*.wav","wav");
      inopf.setFileName(fn);
    }
  else
    {
      inopf.setFileName(fname);
    }
  if(!inopf.open(QIODevice::WriteOnly|QIODevice::Truncate))
    {
      return FALSE;
    }
  numberOfSamples=0;
  initHeader();

	if(!writeHeader()) return FALSE;
  writing=TRUE;
	numberOfSamples=0;
	return TRUE;
}

/**
	\brief write data to wave file

	To signal the end, call this function with numSamples=0. The file will automatically be closed.
	\param dPtr pointer to buffer for 16 bit samples
	\param numSamples  number of samples to read
	\return returns TRUE the correct number of samples are written. FALSE otherwise.
*/

bool  wavIO::write(quint16 *dPtr, uint numSamples, bool isStereo)
{
#define LENTEMPBUF (4096*2)
  uint i;
	int len;
  quint16 tempBuf[LENTEMPBUF];
  quint16 *tmpPtr;
  tmpPtr=dPtr;
  len=numSamples*sizeof(SOUNDFRAME);

  if((!writing)&&(numSamples!=0))
		{
      addToLog("wavio not open during write",LOGALL);
	 		return TRUE;
		}
	if((!writing)&&(numSamples==0)) return TRUE;
	if(numSamples==0)
		{
      addToLog(QString("wavio write close samples=%1").arg(numberOfSamples),LOGWAVIO);
			inopf.flush();
			writeHeader();
			closeFile();
			return TRUE;
		}
  if(!isStereo)
    {
      tmpPtr=tempBuf;
      for(i=0;i<numSamples;i++)
        {
          tempBuf[i*2]=dPtr[i];
          tempBuf[i*2+1]=0;
        }
    }

   if(inopf.write((char *)tmpPtr,len)!=len)
     {
      addToLog("wavio write error",LOGALL);
      closeFile();
      return FALSE;
     }
	numberOfSamples+=numSamples;
  addToLog(QString("wavio write:%1 total samples=%2").arg(numSamples).arg(numberOfSamples),LOGWAVIO);
  return TRUE;
}


/** setup the defaults in the wave header */

void wavIO::initHeader()
{
    waveHeader.chunkID[0]='R';
    waveHeader.chunkID[1]='I';
    waveHeader.chunkID[2]='F';
    waveHeader.chunkID[3]='F';
    
    waveHeader.format[0]='W';
    waveHeader.format[1]='A';
    waveHeader.format[2]='V';
    waveHeader.format[3]='E';

 
    waveHeader.subChunk1ID[0]='f';
    waveHeader.subChunk1ID[1]='m';
    waveHeader.subChunk1ID[2]='t';
    waveHeader.subChunk1ID[3]=' ';

    waveHeader.subChunk2ID[0]='d';
    waveHeader.subChunk2ID[1]='a';
    waveHeader.subChunk2ID[2]='t';
    waveHeader.subChunk2ID[3]='a';

    waveHeader.subChunk1Size=16;      // always 16 for PCM
    waveHeader.audioFormat=1;         // PCM
    waveHeader.numChannels=MAXNUMCHANNELS;         // Stereo
    waveHeader.sampleRate=samplingrate;
    waveHeader.byteRate=sizeof(SOUNDFRAME)*samplingrate;    // 16 bit samples
    waveHeader.blockAlign=4;
    waveHeader.bitsPerSample=16;
    waveHeader.chunkSize=36+numberOfSamples*sizeof(short int);
    waveHeader.subChunk2Size=numberOfSamples*sizeof(short int);
}

bool  wavIO::checkString(char *str,const char *cstr)
{
  for (int i=0;i<4;i++)
    {
      if (str[i]!=cstr[i]) return FALSE;
    }
  return TRUE;
}

bool  wavIO::writeHeader()
{
	int err;
	waveHeader.subChunk2Size=numberOfSamples*sizeof(short int);
	lseek(inopf.handle(),0,SEEK_SET); //position at beginning
  if((err=inopf.write(&waveHeader.chunkID[0],sizeof(sWave)))!=sizeof(sWave))
     {
		 	
      addToLog(QString("wavio write header error %1").arg(err),LOGWAVIO);
      closeFile();
      return FALSE;
     }
	inopf.flush();
	lseek(inopf.handle(),0,SEEK_END); //position at beginning
  addToLog(QString("wavio write header %1 %2 %3 %4").arg(waveHeader.chunkID[0]).arg(waveHeader.chunkID[1]).arg(waveHeader.chunkID[2]).arg(waveHeader.chunkID[3]),LOGWAVIO);
  addToLog(QString("wavio write header samples=%1").arg(numberOfSamples),LOGWAVIO);
  addToLog(QString("wavio write header total bytes=%1").arg(numberOfSamples*2+sizeof(sWave)),LOGWAVIO);
  return TRUE;
}
