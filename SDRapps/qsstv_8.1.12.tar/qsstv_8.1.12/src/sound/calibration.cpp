/**************************************************************************
*   Copyright (C) 2000-2012 by Johan Maes                                 *
*   on4qz@telenet.be                                                      *
*   http://users.telenet.be/on4qz                                         *
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
*   This program is distributed in the hope that it will be useful,       *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
*   GNU General Public License for more details.                          *
*                                                                         *
*   You should have received a copy of the GNU General Public License     *
*   along with this program; if not, write to the                         *
*   Free Software Foundation, Inc.,                                       *
*   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
***************************************************************************/
#include "calibration.h"
#include "ui_calibration.h"


#include <QDebug>
#include <QApplication>
#include "qsstvglobal.h"
#include "sound/soundio.h"
#include <math.h>
#include "QMessageBox"
#include <QPushButton>


#define ITERATIONS 100


/**
 * \class calibration
 *
 * Check first if ntp is running and it is synchronised. A dialog window will appear and show the progress ofr the RX and TX clocks.
 * About 10000 blocks of data will be read/written to calculate the exact timing. If the OK button is pressed, the clocks will be saved for later use.
 *
 **/



/**
 * @brief Calibration constructor
 *
 * @param parent parent widget pointer
 */
calibration::calibration(QWidget *parent) :
  QDialog(parent),
  ui(new Ui::calibration)
{
  ui->setupUi(this);
  init();
}



calibration::~calibration()
{
  delete ui;
}



/**
 * @brief start calibration
 *
 * Call this function to start the calibration proces. The use the results, check the return status and get the value of the clocks by calling getRXClock() and getTXClock().
 *
 * \sa getRXClock() \sa getTXClock()
 *
 * @return bool TRUE if calibration is successful. Return FALSE if an error occured or the dialog was canceled
 */
int calibration::exec()
{

  init();
  show();
  ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(FALSE);
  if(!start(TRUE)) return QDialog::Rejected;
  if(!start(FALSE)) return QDialog::Rejected;
  ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(TRUE);
  while(!stopped)
    {
      qApp->processEvents();
    }
 if(!canceled) return QDialog::Accepted;
 return QDialog::Rejected;
}


/**
 * @brief initialize
 *
 * This function is called by exec to initialize the calibration and setup the dialog box
 *
  */

void calibration::init()
{
  stopped=FALSE;
  canceled=FALSE;
  // find out if we working with nanoseconds or microseconds
  ui->rxProgress->setMaximum(ITERATIONS-1);
  ui->txProgress->setMaximum(ITERATIONS-1);
  ui->rxProgress->setValue(0);
  ui->txProgress->setValue(0);
  display(BASESAMPLERATE,ui->rxLCD);
  display(BASESAMPLERATE,ui->txLCD);
  connect(this,SIGNAL(finished(int)),SLOT(hasFinished(int)));

}

/**
 * @brief slot for finish
 *
 * This slot is called when the dialog is closed by pressing CANCEL or OK. It will abort the loop executed in start and set the bool canceled to FALSE or TRUE
 * depending on the CANCEL or OK button being presssed.
 **/

void calibration::hasFinished(int result)
{
  stopped=TRUE;
  if(result==QDialog::Rejected) canceled=TRUE;
}


/**
 * @brief initialize
 *
 * @param bool isRX: If isRX is set then the receive clock will be calibrated, else the transmit clock will be calibrated.
 *
 * Start is called by exec and performs the clock calibration using NTP (Network Time Protocol).
 * It starts counting when the first 100 blocks are read or when the first 100 blocks are written in order to start with a stable condition.
 * @return bool returns TRUE if calibration is successful or FALSE when either the CANCEL button was pressed or a read NTP time erro has occured.
 *
 **/

bool calibration::start(bool isRX)
{
  unsigned int i;
  double clock=48000;
  int frames;
  int framesDone=-1;
  int elapsed;
  QString blockStr;
  if(isRX)
    {
      blockStr="blockRX: ";
    }
  else
    {
      blockStr="blockTX: ";
    }

  if(!soundIOPtr->startCalibration(isRX))
    {
      QMessageBox::critical(this,"Calibration Error","Souncard not active");
      return FALSE;
    }
  for(i=0;i<ITERATIONS;)
    {
      qApp->processEvents();
      if(!soundIOPtr->isRunning()) return FALSE;
      elapsed=soundIOPtr->calibrationCount(frames);
      if((frames%50==0)&&(frames>0)&&(frames!=framesDone))
        {
          i++;
//          qDebug() << "frames" << frames << "time" << elapsed;
//          logfile->addToAux(QString("%1\t%2").arg(frames).arg(elapsed));

          framesDone=frames;
          clock=((double)frames*1000.*PERIODSIZE)/((double)elapsed);
          if(isRX)
            {
              display(clock,ui->rxLCD);
              ui->rxProgress->setValue(i);
            }
          else
            {
              display(clock,ui->txLCD);
              ui->txProgress->setValue(i);
            }
        }
     }
  soundIOPtr->idle();
  if(isRX)
    {
      rxCardClock=clock;
    }
  else
    {
      txCardClock=clock;
    }
  return TRUE;
}


void calibration::display(double value,QLCDNumber *dspl)
{
  QString tmp=QString::number(value,'g',7);
  switch(tmp.length())
    {
    case 5: tmp+=".00"; break;
    case 6: tmp+="00"; break;
    case 7: tmp+="0"; break;
    }
   dspl->display(tmp);
}


