#ifndef WATERFALLTEXT_H
#define WATERFALLTEXT_H
#include "qsstvdefs.h"
//#include <complex.h>
#include "fftw3.h"
#include <QString>
#include <QImage>

class imageViewer;
class filter;


class waterfallText
{
public:
  waterfallText();
  ~ waterfallText();
  void init();
  void setText(QString txt);
  QImage *getImagePtr() {return &image;}
 DSPFLOAT *nextLine();
 int getLength() {return fftLength;}
 double getDuration(QString txt=NULL);
private:
  int fftLength;
  int samplingrate;
  fftw_complex *out;
  fftw_complex *dataBuffer;

  DSPFLOAT *outFiltered;
  DSPFLOAT *audioBuf;
  fftw_plan plan;
  void setupImage(QString txt);
  int imageWidth;
  int width;
  int height;
  int line;
  filter *txFilter;
  QImage image;
  int dLine;
  int startFreqIndex;
  double *phr;
  double *phi;
  double amplitude;
};

#endif // WATERFALLTEXT_H
