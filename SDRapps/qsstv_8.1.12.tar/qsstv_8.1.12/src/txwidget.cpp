#include "txwidget.h"
#include <rxwidget.h>
#include "ui_txwidget.h"
#include <QTimer>
#include "configparams.h"
#include "dispatcher.h"
#include "utils/supportfunctions.h"
#include "gallerywidget.h"

#include "ui_freqform.h"
#include "ui_sweepform.h"
#include "widgets/cameracontrol.h"
#include "videocapt/videocapture.h"
#include "sound/soundio.h"
#include "widgets/waterfallform.h"
#include "drmtx/bsrform.h"
#include "drmrx/fixform.h"
#include "mainwindow.h"




txWidget *txWidgetPtr;

txWidget::txWidget(QWidget *parent) :
  QWidget(parent),
  ui(new Ui::txWidget)
{
  int i;
  ui->setupUi(this);
  txFunctionsPtr=new txFunctions();
  imageViewerPtr=ui->imageFrame;
  imageViewerPtr->createImage(QSize(320,256),QColor(0,0,128));
  imageViewerPtr->displayImage();
  readSettings();
  for(i=0;i<NUMSSTVMODES-1;i++) // exclude Calibrate
    {
      ui->modeComboBox->addItem(getSSTVModeNameLong((esstvMode)i));
    }
  connect(ui->modeComboBox,SIGNAL(activated(int)),SLOT(slotModeChanged(int )));
  connect(ui->templatesComboBox,SIGNAL(currentIndexChanged(int)),SLOT(slotGetParams()));
  connect(ui->templateCheckBox,SIGNAL(toggled(bool)),SLOT(slotGetParams()));
  connect(ui->cwCheckBox,SIGNAL(toggled(bool)),SLOT(slotGetParams()));
  connect(ui->voxCheckBox,SIGNAL(toggled(bool)),SLOT(slotGetParams()));
  connect(ui->toCallLineEdit,SIGNAL(editingFinished ()),SLOT(slotGetParams()));
  connect(ui->operatorLineEdit,SIGNAL(editingFinished ()),SLOT(slotGetParams()));
  connect(ui->rsvLineEdit,SIGNAL(editingFinished ()),SLOT(slotGetParams()));
  connect(ui->comment1LineEdit,SIGNAL(editingFinished ()),SLOT(slotGetParams()));
  connect(ui->comment2LineEdit,SIGNAL(editingFinished ()),SLOT(slotGetParams()));
  connect(ui->comment3LineEdit,SIGNAL(editingFinished ()),SLOT(slotGetParams()));
  connect(ui->startToolButton, SIGNAL(clicked()), this, SLOT(slotStart()));
  connect(ui->stopToolButton, SIGNAL(clicked()), this, SLOT(slotStop()));


  connect(ui->generateToneToolButton, SIGNAL(clicked()), this, SLOT(slotGenerateSignal()));
  connect(ui->sweepToneToolButton, SIGNAL(clicked()), this, SLOT(slotSweepSignal()));
  connect(ui->repeaterToneToolButton, SIGNAL(clicked()), this, SLOT(slotGenerateRepeaterTone()));
  connect(ui->openToolButton, SIGNAL(clicked()), this, SLOT(slotFileOpen()));
  //   connect(ui->actionAlignement, SIGNAL(triggered()), this, SLOT(slotAlignementSignal()));
  connect(ui->editToolButton, SIGNAL(clicked()), this, SLOT(slotEdit()));
  //   connect(ui->actionReplay, SIGNAL(triggered()), this, SLOT(slotReplay()));
  connect(ui->snapshotToolButton, SIGNAL(clicked()), this, SLOT(slotSnapshot()));
  connect(imageViewerPtr, SIGNAL(imageChanged()), this, SLOT(slotGetParams()));
  connect(ui->qualitySpinBox,SIGNAL(valueChanged(int)),SLOT(slotQuality(int)));
  currentTXMode=NOMODE;
}

txWidget::~txWidget()
{
    delete ui;
}

void txWidget::init()
{
  splashStr+=QString( "Setting up TX" ).rightJustified(25,' ')+"\n";
  splashPtr->showMessage ( splashStr ,Qt::AlignLeft,Qt::white);
  qApp->processEvents();
  ed=NULL;
  repeaterIndex=0;
  initView();
  repeaterTimer=new QTimer(this);
  connect(repeaterTimer,SIGNAL(timeout()),SLOT(slotRepeaterTimer()));
  repeaterTimer->start(60000*repeaterImageInterval);
  imageViewerPtr->setType(imageViewer::TXIMG);
  slotModeChanged(modeIndexTx);
  slotQuality(quality);
  txFunctionsPtr->start();

}

void txWidget::readSettings()
{
  QSettings qSettings;
  qSettings.beginGroup("TX");
  modeIndexTx=((esstvMode)qSettings.value("modeIndexTx",0).toInt());
  templateIndex=qSettings.value("templateIndex",0).toInt();
  useTemplate=qSettings.value("useTemplate",FALSE).toBool();
  useCW=qSettings.value("useCW",FALSE).toBool();
  useVOX=qSettings.value("useVOX",FALSE).toBool();
  quality=qSettings.value("quality",100).toInt();
  drmParams.bandwith=qSettings.value("drmBandWith",0).toInt();
  drmParams.interleaver=qSettings.value("drmInterLeaver",0).toInt();
  drmParams.protection=qSettings.value("drmProtection",0).toInt();
  drmParams.qam=qSettings.value("drmQAM",0).toInt();
  drmParams.robMode=qSettings.value("drmRobMode",0).toInt();
  drmParams.readSolomon=qSettings.value("drmReedSolomon",0).toInt();
  qSettings.endGroup();
  setParams();
}

void txWidget::writeSettings()
{
  QSettings qSettings;
  slotGetParams();
  qSettings.beginGroup("TX");
  qSettings.setValue( "modeIndexTx", modeIndexTx);
  qSettings.setValue( "templateIndex", templateIndex);
  qSettings.setValue( "useTemplate", useTemplate);
  qSettings.setValue( "useVOX", useVOX);
  qSettings.setValue( "useCW", useCW);
  qSettings.setValue("drmBandWith",drmParams.bandwith);
  qSettings.setValue("drmInterLeaver",drmParams.interleaver);
  qSettings.setValue("drmProtection",drmParams.protection);
  qSettings.setValue("drmQAM",drmParams.qam);
  qSettings.setValue("drmRobMode",drmParams.robMode);
  qSettings.setValue("drmReedSolomon",drmParams.readSolomon);
  qSettings.setValue("quality",quality);
  qSettings.endGroup();
}

void txWidget::slotGetParams()
{
  int temp=modeIndexTx;
  getIndex(temp,ui->modeComboBox);
  modeIndexTx=esstvMode(temp);
  getIndex(templateIndex,ui->templatesComboBox);
  getValue(useTemplate,ui->templateCheckBox);
  getValue(useVOX,ui->voxCheckBox);
  getValue(useCW,ui->cwCheckBox);
  getValue(imageViewerPtr->toCall,ui->toCallLineEdit);
  getValue(imageViewerPtr->toOperator,ui->operatorLineEdit);
  getValue(imageViewerPtr->rsv,ui->rsvLineEdit);
  getValue(imageViewerPtr->comment1,ui->comment1LineEdit);
  getValue(imageViewerPtr->comment2,ui->comment2LineEdit);
  getValue(imageViewerPtr->comment3,ui->comment3LineEdit);
  getIndex(drmParams.bandwith,ui->drmTxBandwidthComboBox);
  getIndex(drmParams.interleaver,ui->drmTxInterleaveComboBox);
  getIndex(drmParams.protection,ui->drmTxProtectionComboBox);
  getIndex(drmParams.qam,ui->drmTxQAMComboBox);
  getIndex(drmParams.robMode,ui->drmTxModeComboBox);
  getIndex(drmParams.readSolomon,ui->drmTxReedSolomonComboBox);
  getValue(quality,ui->qualitySpinBox);
  drmParams.callsign=myCallsign;
//  if(!txFunctionsPtr->isRunning())
  if(txFunctionsPtr->getTXState()==txFunctions::TXIDLE)
    {
      applyTemplate();
    }
}

void txWidget::setParams()
{
  setIndex(((int)modeIndexTx),ui->modeComboBox);
  setIndex(templateIndex,ui->templatesComboBox);
  setValue(useTemplate,ui->templateCheckBox);
  setValue(useVOX,ui->voxCheckBox);
  setValue(useCW,ui->cwCheckBox);
  setIndex(drmParams.bandwith,ui->drmTxBandwidthComboBox);
  setIndex(drmParams.interleaver,ui->drmTxInterleaveComboBox);
  setIndex(drmParams.protection,ui->drmTxProtectionComboBox);
  setIndex(drmParams.qam,ui->drmTxQAMComboBox);
  setIndex(drmParams.robMode,ui->drmTxModeComboBox);
  setIndex(drmParams.readSolomon,ui->drmTxReedSolomonComboBox);
  setValue(quality,ui->qualitySpinBox);
}

void txWidget::initView()
{
  ui->modeComboBox->setCurrentIndex((int)modeIndexTx);
  setupTemplatesComboBox();
  ui->progressBar->setRange(0,100);
}

void txWidget::setupTemplatesComboBox()
{
  QStringList sl;
   int i;
  ui->templatesComboBox->clear();
  sl=galleryWidgetPtr->getFilenames();
  for(i=0;i<sl.count();i++)
  {
    ui->templatesComboBox->insertItem(i,sl.at(i));
  }
   ui->templatesComboBox->setCurrentIndex(templateIndex);
}

void  txWidget::setPreviewWidget(QString fn)
{
   ui->previewWidget->openImage(fn,FALSE,FALSE);
}

void txWidget::start(bool st,bool check)
{
  if(st)
    {
      slotGetParams();
      if(check)
        {
          if(!imageViewerPtr->hasValidImage())
            {
              QMessageBox::warning(this,"TX Error","No image loaded");
              return;
            }
        }
      soundIOPtr->startPlayback();
    }
  else
    {
      writeSettings();
      txFunctionsPtr->stopAndWait();
    }
}

void txWidget::slotStart()
{
//  start(TRUE);
  slotGetParams();
  switch(currentTXMode)
    {
    case SSTV:
       dispatcherPtr->startSSTVTx();
    break;
    case DRM:
       txFunctionsPtr->setDRMTxParams(drmParams);
       dispatcherPtr->startDRMTx();
    break;
//    case FAX:
//    break;
    case NOMODE:
      break;
    }
}

void txWidget::sendBSR()
{
  QByteArray *p;
  bsrForm::eResult res;
  bsrForm bsrf;
  bsrf.init();
  res=(bsrForm::eResult)bsrf.exec();
  if(res==bsrForm::CANCEL) return;
  p=bsrf.getBA(res==bsrForm::COMPAT);
  drmParams=bsrf.getDRMParams();
  txFunctionsPtr->setDRMTxParams(drmParams);
  dispatcherPtr->startDRMBSRTx(p);
}


void txWidget::sendID()
{
  dispatcherPtr->sendWF(myCallsign);
}

void txWidget::sendWfText()
{
  waterfallForm wf;
  if((wf.exec()==QDialog::Accepted)&&(!wf.text().isEmpty()))
    {
      dispatcherPtr->sendWF(wf.text());
    }
}

void txWidget::slotStop()
{
//  qDebug() << "slotStop tx";
  soundIOPtr->abortPlayback();
  start(FALSE);
  dispatcherPtr->restartRX();
}


void txWidget::slotDisplayStatusMessage(QString s)
{
    statusBarPtr->showMessage(s);
}


//void txWidget::slotReplay()
//{
//  QString fn;
//  QImage *im=NULL;
//  fn=galleryWidgetPtr->getLastRxImage();
//  editorScene scene(0);
//  QFile f(fn);
//  if(!scene.load(f))
//    {
//      QMessageBox::warning(this,"Image Properties","Error while loading\n" + fn);
//      return;
//    }
//  im=scene.renderImage();
//  dispatcherPtr->setTXImage(im);
//  slotStartTX();
//}


void txWidget::slotFileOpen()
{
  QString fileName;
  imageViewerPtr->openImage(fileName,txImagesPath,TRUE,TRUE,TRUE);
}

void txWidget::slotGenerateSignal()
{
  QDialog qd;
   Ui::freqForm *ff=new Ui::freqForm;

  ff->setupUi(&qd);
  int freq;
  int  duration;
  if(qd.exec())
    {
      getValue(freq,ff->frequencySpinBox);
      getValue(duration,ff->durationSpinBox);
      dispatcherPtr->sendTone((double)duration,(double)freq);
    }
}

void txWidget::slotSweepSignal()
{
  QDialog qd;
 Ui::sweepForm *ff=new Ui::sweepForm;
  ff->setupUi(&qd);
  int upperFreq;
  int lowerFreq;
  int  duration;
  if(qd.exec())
    {
      getValue(lowerFreq,ff->lowerFrequencySpinBox);
      getValue(upperFreq,ff->upperFrequencySpinBox);
      getValue(duration,ff->durationSpinBox);
      dispatcherPtr->sendSweepTone((double)duration,(double)lowerFreq,(double)upperFreq);
    }
}


void txWidget::slotGenerateRepeaterTone()
{
  addToLog(QString("start of buffer %1").arg(soundIOPtr->txBuffer.count()),LOGTXMAIN);
  dispatcherPtr->sendTone(3.,1750);
}



void txWidget::slotEdit()
{
  if (ed!=NULL) delete ed;
  ed=new editor(this);
  if(txFunctionsPtr->isRunning())
    {
      QMessageBox::warning(this,"Editor","Transmission busy, editor not available");
      return;
    }
  connect(ed,SIGNAL(imageAvailable(QImage *)),SLOT(setImage(QImage *)));
  ed->setImage(imageViewerPtr->getImagePtr());
  ed->show();
}


void txWidget::slotModeChanged(int m)
{
  addToLog("slotModeChange",LOGTXMAIN);
  modeIndexTx=(esstvMode)m;
//  txFunctionsPtr->create(modeIndexTx,txClock/SUBSAMPLINGRATIO);
  applyTemplate();
}




/** \todo implement repeater */
void txWidget::applyTemplate()
{
  if(currentTXMode!=DRM)
    {
      txFunctionsPtr->create(modeIndexTx,txClock/SUBSAMPLINGRATIO);
      imageViewerPtr->applyTemplate(galleryWidgetPtr->getTemplateFileName(ui->templatesComboBox->currentIndex()),useTemplate, txSSTVParam.numberOfPixels,txSSTVParam.numberOfDisplayLines);
    }
  else
    {
      slotQuality(quality);
      imageViewerPtr->applyTemplate(galleryWidgetPtr->getTemplateFileName(ui->templatesComboBox->currentIndex()),useTemplate);
    }
}

void 	txWidget::setImage(QImage *im)
{
  if(imageViewerPtr->openImage(*im))
    {
      applyTemplate();
    }
}

void 	txWidget::setImage(QString fn)
{
  imageViewerPtr->openImage(fn,TRUE,TRUE);
}


void txWidget::setProgress(uint prg)
{
  ui->progressBar->setValue(prg);
}


/** \todo implement repeater */

// void txWidget::repeat(QImage *im,esstvMode sm)
void txWidget::repeat(QImage *,esstvMode )
{
/*	setValue((int)sm,ui->modeComboBox);
  txf->setModeIndex((sstvMode)sm);
//	slotModeChanged(sm);

  txf->setImage(im);
  dsp->setCaptureSource(TRUE,NULL,FALSE);
  txf->process();*/
}

void txWidget::slotRepeaterTimer()
{
  QString fn;
  QFile fi;
  if(txFunctionsPtr->isRunning()) repeaterTimer->start(60000*repeaterImageInterval);

  else if ((rxWidgetPtr->functionsPtr()->isRunning()) || (!repeaterEnable))
    {
      // wait 10 seconds and check if busy or repeaterEnable has changed
      repeaterTimer->start(10000);
    }
  else
    {
      switch(repeaterIndex)
        {
          case 0:
            fn=repeaterImage1;
          break;
          case 1:
            fn=repeaterImage2;
          break;
          case 2:
            fn=repeaterImage3;
          break;
          case 3:
            fn=repeaterImage4;
          break;
          default:
            fn=repeaterImage1;
          break;
        }
      fi.setFileName(fn);
      if (fi.exists())
        {
          slotModeChanged(repeaterTxMode);
          setImage(fn);
        }
      repeaterIndex++;
      if(repeaterIndex>3) repeaterIndex=0;
      repeaterTimer->start(60000*repeaterImageInterval);
      //QApplication::processEvents();
      startAutoRepeaterEvent* ce = new startAutoRepeaterEvent();
      QApplication::postEvent(dispatcherPtr, ce );
    }
}



void txWidget::slotSnapshot()
{
  cameraControl cc(this);
  if(cc.exec())
    {
      setImage(cc.getImage());
    }
}





//void txWidget::test()
//{

//}

void txWidget::setSettingsTab()
{
  int i;
  currentTXMode=transmissionModeIndex;
  start(FALSE);

  if((transmissionModeIndex>=0)&&(transmissionModeIndex<NOMODE))
    {
      for(i=0;i<NOMODE;i++)
        {
          if(i!=transmissionModeIndex) ui->settingsTableWidget->widget(i)->setEnabled(FALSE);
        }
      ui->settingsTableWidget->widget(transmissionModeIndex)->setEnabled(TRUE);
      ui->settingsTableWidget->setCurrentIndex(transmissionModeIndex);
    }
  applyTemplate();
}

bool txWidget::prepareFIX(QByteArray bsrByteArray)
{
  int i,j;
//  unsigned int mode=0;
//  eRSType rsType;
  bool inSeries;
  QString fileName,extension;
  txSession *sessionPtr;
  bool extended,done;
  int block;
  fixBlockList.clear();
  unsigned short trID,lastBlock;
  QString str(bsrByteArray);
  str.replace("\r","");
  //  information is in the QByteArray ba
  QStringList sl;
  sl=str.split("\n",QString::SkipEmptyParts);

  if(sl.at(1)!="H_OK")
    {
      return FALSE;
    }
  trID=sl.at(0).toUInt();
  lastBlock=sl.at(3).toUInt();
  fixBlockList.append(lastBlock++);
  inSeries=FALSE;
  done=FALSE;
  extended=FALSE;
  for(i=4;(!done)&&i<sl.count();i++)
    {
      block=sl.at(i).toInt();
      if(block==-99)
        {
          done=TRUE;
          i++;
          break;
        }
      if(block<0) inSeries=TRUE;
      else
        {
          if(inSeries)
            {
              inSeries=FALSE;
              for(j=lastBlock;j<block;j++) fixBlockList.append(j);
            }
          fixBlockList.append(block);
          lastBlock=block+1;
        }
    }
  // check if we have a filename beyond -99
  if((i+1)<sl.count()) // we need an additional 2 entries (filename and mode)
    {
      extended=TRUE;
      fileName=sl.at(i++);
//      mode=sl.at(i).toUInt();
//      qDebug() << " bsr received with " << fileName << mode;
    }
  fixForm fx(mainWindowPtr);
  sessionPtr=txFunctionsPtr->getSessionPtr(trID);
  if ((sessionPtr==NULL) && (!extended))
    {
      QMessageBox *mbox = new QMessageBox(this);
      mbox->setWindowTitle(tr("BSR Received"));
      mbox->setText("This BSR is not for you");
      mbox->show();
      QTimer::singleShot(4000, mbox, SLOT(hide()));
      return FALSE;
    }
  else if (sessionPtr!=NULL)
    {
      // take it from the transmitlist

      fx.setInfoInternal(paramsToMode(sessionPtr->drmParams),sessionPtr->filename,fixBlockList.count(),&sessionPtr->ba);
      if(fx.exec()==QDialog::Rejected) return FALSE;
      txFunctionsPtr->initDRMFIX(sessionPtr);
     }
  else
    {
      // At this moment sending a FIX on behalf of another station, is disabled
      //      QFileInfo finfo(fileName);
      //      QString baseName=finfo.baseName();
      //      extension=finfo.suffix();

      //      if(extension=="rs1") rsType=RST1;
      //      else if(extension=="rs2") rsType=RST2;
      //      else if(extension=="rs3") rsType=RST3;
      //      else if(extension=="rs4") rsType=RST4;
      //      else rsType=RSTNONE;

      //      //we have to look in our receive image directory and in our transmitlist
      //      QDir dd(rxImagesPath);
      //      QStringList nameFilter;
      //      if(rsType==RSTNONE) nameFilter<< fileName;
      //      else  nameFilter<< QString(baseName+".*");
      //      QStringList slfile=dd.entryList(nameFilter,QDir::Files);
      //      if(slfile.count()==1)
      //        {
      //          QFileInfo fin(rxImagesPath,slfile.at(0));
      //          fileName=fin.absoluteFilePath();
      //          //we found the original filename
      //          fx.setInfoExternal(mode,fileName,fixBlockList.count()); // False=external
      //          if(fx.exec()==QDialog::Rejected) return FALSE;
      //          if(!txFunctionsPtr->initDRMFIX(fileName,fin.suffix(),rsType,mode))
      //            {
      //              return FALSE;
      //            }
      //        }
      //      else
      //        {
      QMessageBox *mbox = new QMessageBox(this);
      mbox->setWindowTitle(tr("BSR Received"));
      mbox->setText("This BSR is not for you");
      mbox->show();
      QTimer::singleShot(4000, mbox, SLOT(hide()));
      return FALSE;
      //        }
    }
  return TRUE;
}

void txWidget::slotQuality(int v)
{
  QString t;
  int fileSize;
  quality=v;
  imageViewerPtr->setQuality(v,"jpg");
  imageViewerPtr->displayImage();
  fileSize=imageViewerPtr->getFileSize();
  fileSize=(fileSize+500)/1000.;
  t=QString::number(fileSize) +" kB";
  setValue(t,ui->filesizeLineEdit);


}
