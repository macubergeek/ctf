/***************************************************************************
 *   Copyright (C) 2000-2008 by Johan Maes                                 *
 *   on4qz@telenet.be                                                      *
 *   http://users.telenet.be/on4qz                                         *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
/*!
	The dispatcher is the central system that routes all messages from the different threads.
It also starts, stops and synchronizes the threads.

*/
#include "dispatcher.h"
#include "qsstvglobal.h"
#include "configparams.h"
#include "rxwidget.h"
#include "txwidget.h"
#include "gallerywidget.h"
#include <QSettings>
#include "widgets/spectrumwidget.h"
#include "widgets/vumeter.h"
#include <sys/ioctl.h>
#include <unistd.h>
#include <fcntl.h>
#include "rig/rigcontrol.h"
#include "utils/ftp.h"
#include "editor/editor.h"
#include "sound/soundio.h"
#include "sound/waterfalltext.h"
#include "mainwindow.h"
#include "drmrx/drm.h"





/*!
creates dispatcher instance
 */

dispatcher::dispatcher()
{
}

/*!
delete dispatcher instance
 */

dispatcher::~dispatcher()
{

}

void dispatcher::init()
{
  editorActive=FALSE;
  rxWidgetPtr->fftDisplayPtr()->init(RXSTRIPE,1,BASESAMPLERATE/SUBSAMPLINGRATIO);
  galleryWidgetPtr->init();
  rxWidgetPtr->init();
  txWidgetPtr->init();
  waterfallPtr=new waterfallText;
  waterfallPtr->init();
  rigController->init();
  restartRXFlag=FALSE;
  infoTextPtr=new textDisplay(mainWindowPtr);
  infoTextPtr->hide();

}



void dispatcher::stopRX()
{
  rxWidgetPtr->start(FALSE);
}

void dispatcher::stopTX()
{
  activatePTT(FALSE);
  txWidgetPtr->start(FALSE);
}

void dispatcher::stopRXTX()
{
  stopRX();
  stopTX();
}

void dispatcher::startRX(bool st)
{
  stopTX();
  rxWidgetPtr->start(st);
  if(st)
    {
      addToLog("dispatcher: starting RX",LOGDISPAT);
    }
  else
    {
      addToLog("dispatcher: stopping RX",LOGDISPAT);
    }
}

void dispatcher::startTX(bool st)
{
  stopRX();
  if(st)
    {
      addToLog("dispatcher: starting TX",LOGDISPAT);
    }
  else
    {
      addToLog("dispatcher: stopping TX",LOGDISPAT);
    }
  activatePTT(st);
  txWidgetPtr->start(st);
}



void dispatcher::readSettings()
{
	QSettings qSettings;
  logfile->readSettings(qSettings);
}

void dispatcher::writeSettings()
{
	QSettings qSettings;
  logfile->writeSettings(qSettings);
}

/*!
	All communication between the threads are passed via this eventhandler.
*/

void dispatcher::customEvent( QEvent * e )
{
  dispatchEventType type;
  QString fn;
  type=(dispatchEventType)e->type();
  addToLog(((baseEvent*)e)->description,LOGDISPAT);
  switch(type)
    {
    case displayFFT:
      addToLog("dispatcher: displayFFT",LOGDISPAT);
      rxWidgetPtr->fftDisplayPtr()->realFFT(((displayFFTEvent*)e)->data());
      rxWidgetPtr->fftDisplayPtr()->repaint();
    break;
    case displaySync:
      // addToLog("dispatcher: displaySync",LOGDISPAT);
      uint s;double v;
      ((displaySyncEvent*)e)->getInfo(s,v);
      rxWidgetPtr->sMeterPtr()->setValue((double)s);
      rxWidgetPtr->vMeterPtr()->setValue(v);
    break;
    case rxSSTVStatus:
      rxWidgetPtr->setSSTVStatusText(((statusMsgEvent*)e)->getStr());
    break;
    case rxDRMStatus:
      rxWidgetPtr->setDRMStatusText(((statusMsgEvent*)e)->getStr());
    break;
    case startImageRX:
      addToLog("dispatcher: clearing RxImage",LOGDISPAT);
      rxWidgetPtr->getImageViewerPtr()->createImage( ((startImageRXEvent*)e)->getSize(),QColor(255,255,0));
      rxWidgetPtr->getImageViewerPtr()->clear();
    break;
    case lineDisplay:
      {
        rxWidgetPtr->getImageViewerPtr()->displayImage();
      }
    break;
    case syncLost:
    case verticalRetrace:
      addToLog("dispatcher: verticalRetrace",LOGDISPAT);
      if(autoSave)
        {
          addToLog("dispatcher: verticalRetrace savingRxImage",LOGDISPAT);
          saveRxSSTVImage();
        }
      rxWidgetPtr->functionsPtr()->retraceVertical();
    break;
    case endImageRX:
      if(autoSave)
        {
          addToLog("dispatcher:endImage savingRxImage",LOGDISPAT);
          saveRxSSTVImage();
        }
    break;
    case callEditor:
      if(editorActive) break;
      editorActive=TRUE;
      ed=new editor();
      ed->show();
      iv=((callEditorEvent*)e)->getImageViewer();
      addToLog (QString(" callEditorEvent imageViewPtr: %1").arg(QString::number((ulong)iv,16)),LOGDISPAT);
      addToLog(QString("editor: filename %1").arg(((callEditorEvent*)e)->getFilename()),LOGDISPAT);
      ed->openFile(((callEditorEvent*)e)->getFilename());
    break;

    case editorFinished:
      if(!editorActive) break;
      if(((editorFinishedEvent*)e)->isOK())
        {
          addToLog (QString(" editorFinishedEvent imageViewPtr: %1").arg(QString::number((ulong)iv,16)),LOGDISPAT);
          iv->reload();
        }
      editorActive=FALSE;
      delete ed;
    break;

    case templatesChanged:
      txWidgetPtr->setupTemplatesComboBox();
    break;
    case progressTX:
      txTimeCounter=0;
      prTimerIndex=startTimer(((progressTXEvent*)e)->getInfo()*10); // tim in seconds -> times 1000 for msec,divide by 100 for progress
    break;
    case stoppingTX:
      addToLog("dispatcher: endTXImage",LOGDISPAT);
      while(!soundIOPtr->stoppedPlaying())
        {
          qApp->processEvents();
        }
      activatePTT(FALSE);
    break;

    case endImageTX:
      addToLog("dispatcher: endTXImage",LOGDISPAT);
      while(!soundIOPtr->stoppedPlaying())
        {
          qApp->processEvents();
        }
      activatePTT(FALSE);
      restartRX();
    break;
    case displayDRMInfo:
//      rxWidgetPtr->psdWdg()->setPSD();
      rxWidgetPtr->mscWdg()->setConstellation(MSC);
      rxWidgetPtr->facWdg()->setConstellation(FAC);
      rxWidgetPtr->statusWdg()->setStatus();
    break;

    case displayDRMStat:
      DSPFLOAT s1;DSPFLOAT v1;
      ((displayDRMStatEvent*)e)->getInfo(s1,v1);
      rxWidgetPtr->sMeterPtr()->setValue(s1);
      rxWidgetPtr->vMeterPtr()->setValue(v1);
    break;

    case loadRXImage:
      {
      ((loadRXImageEvent*)e)->getFilename(fn);
      rxWidgetPtr->getImageViewerPtr()->openImage(fn,TRUE,FALSE);
      }
    break;

    case saveDRMImage:
      {
      ((saveDRMImageEvent*)e)->getFilename(fn);
       rxWidgetPtr->getImageViewerPtr()->openImage(fn,TRUE,FALSE);
       saveImage(fn);
       }
    break;
    case prepareFix:
      addToLog("prepareFix",LOGDISPAT);


      startDRMFIXTx( ((prepareFixEvent*)e)->getData());
    break;
    case displayText:
      infoTextPtr->clear();
      infoTextPtr->setWindowTitle(QString("Received from %1").arg(drmCallsign));
      infoTextPtr->append(((displayTextEvent*)e)->getStr());
      infoTextPtr->show();

    break;
    default:
      addToLog(QString("unsupported event: %1").arg(((baseEvent*)e)->description), LOGALL);
    break;
    }
  ((baseEvent *)e)->setDone();
}



void dispatcher::receiveImage()
{
}

void dispatcher::restartRX()
{
  txTimeCounter=9999999; //force stop timer
  startRX(TRUE);
}

void dispatcher::startSSTVTx()
{
  stopRX();
  txWidgetPtr->start(TRUE,FALSE);
  if(txWidgetPtr->functionsPtr()->getTXState()!=txFunctions::TXIDLE) return;
  activatePTT(TRUE);
  txWidgetPtr->functionsPtr()->setTXState(txFunctions::TXSSTVIMAGE);
  addToLog("send SSTV Image",LOGDISPAT);

}

void dispatcher::sendTone(double duration,double freq)
{
  stopRX();
  txWidgetPtr->start(TRUE,FALSE);
  if(txWidgetPtr->functionsPtr()->getTXState()!=txFunctions::TXIDLE) return;
  txWidgetPtr->functionsPtr()->setToneParam(duration,freq);
  activatePTT(TRUE);
  txWidgetPtr->functionsPtr()->setTXState(txFunctions::TXSENDTONE);
  addToLog("sendTone",LOGDISPAT);
 }

void dispatcher::sendWF(QString txt)
{
  stopRX();
  txWidgetPtr->start(TRUE,FALSE);
  if(txWidgetPtr->functionsPtr()->getTXState()!=txFunctions::TXIDLE) return;
  waterfallPtr->setText(txt);
  activatePTT(TRUE);
  txWidgetPtr->functionsPtr()->setTXState(txFunctions::TXSENDID);
  addToLog("sendID",LOGDISPAT);
 }

void dispatcher::startDRMTx()
{
  stopRX();
  txWidgetPtr->start(TRUE,FALSE);
  if(txWidgetPtr->functionsPtr()->getTXState()!=txFunctions::TXIDLE) return;
  //  waterfallPtr->setText(pictureWF);
  activatePTT(TRUE);
  txWidgetPtr->functionsPtr()->setTXState(txFunctions::TXSENDDRM);
  addToLog("sendDRM",LOGDISPAT);
}

void dispatcher::startDRMBSRTx(QByteArray *ba)
{
  if(ba==NULL) return;
  stopRX();
  txWidgetPtr->start(TRUE,FALSE);
  if(txWidgetPtr->functionsPtr()->getTXState()!=txFunctions::TXIDLE) return;
  activatePTT(TRUE);
  txWidgetPtr->functionsPtr()->initDRMBSR(ba);
  txWidgetPtr->functionsPtr()->setTXState(txFunctions::TXSENDDRMBSR);
  addToLog("sendDRM",LOGDISPAT);
 }

void dispatcher::startDRMFIXTx(QByteArray ba)
{
  if(!txWidgetPtr->prepareFIX(ba)) return;
  stopRX();
  txWidgetPtr->start(TRUE,FALSE);
  if(txWidgetPtr->functionsPtr()->getTXState()!=txFunctions::TXIDLE) return;
  activatePTT(TRUE);
  txWidgetPtr->functionsPtr()->setTXState(txFunctions::TXSENDDRMFIX);
  addToLog("sendDRM",LOGDISPAT);
 }

void dispatcher::sendSweepTone(double duration,double lowerFreq,double upperFreq)
{
  stopRX();
  txWidgetPtr->start(TRUE,FALSE);
  txWidgetPtr->functionsPtr()->setToneParam(duration,lowerFreq,upperFreq);
  activatePTT(TRUE);
  txWidgetPtr->functionsPtr()->setTXState(txFunctions::TXSENDTONE);
  addToLog("sendSweepTone",LOGDISPAT);
}


void dispatcher::activatePTT(bool b)
{
  int modemlines;
  if(enableSerialPTT)
  {
    if (pttSerialPort.isEmpty()) return;
    if(serialP==0)
      {
        serialP=::open(pttSerialPort.toLatin1().data(),O_RDONLY);
        if (serialP<=0)
          {
            QMessageBox::warning(txWidgetPtr,"Serial Port Error",
            QString("Unable to open serial port %1\ncheck Options->Configuration\n"
            "make sure that you have read/write permission\nIf you do not have a serial port,\n"
            "then disable -Serial PTT- option in the configuration").arg(pttSerialPort) ,
            QMessageBox::Ok,0 );
            return;
          }
      }
    if(serialP>0)
      {
        if(b)
          {
          ioctl(serialP,TIOCMGET,&modemlines);
          modemlines |= TIOCM_DTR;
          modemlines |= TIOCM_RTS;
          ioctl(serialP,TIOCMSET,&modemlines);
          //ioctl(serial,TIOCMBIS,&t);
          }
        else
          {
          ioctl(serialP,TIOCMGET,&modemlines);
          modemlines &= ~TIOCM_DTR;
          modemlines &= ~TIOCM_RTS;
          ioctl(serialP,TIOCMSET,&modemlines);
          //	ioctl(serial,TIOCMBIC,&t);
          }
      }
  }
  else rigController->setPTT(b); // does nothing if rigController is disabled
  mainWindowPtr->setPTT(b);
  if(b)
    {

      addToLog("dispatcher: PTT activated",LOGDISPAT);
    }
  else
   {
      addToLog("dispatcher: PTT deactivated",LOGDISPAT);
   }
}

void dispatcher::saveRxSSTVImage()
{
  if (rxWidgetPtr->functionsPtr()->getModeString().isEmpty()) return;
  if(!rxWidgetPtr->functionsPtr()->saveOK()) return;
  QString s,fileName;
  QDateTime dt(QDateTime::currentDateTime().toUTC()); //this is compatible with QT 4.6
  dt.setTimeSpec(Qt::UTC);
  int intdate=dt.date().year()*10000+dt.date().month()*100+dt.date().day();
  int inttime=dt.time().hour()*10000+100*dt.time().minute()+dt.time().second();
  s.sprintf("%s_%d_%d",rxWidgetPtr->functionsPtr()->getModeString().toLatin1().data(),intdate,inttime);
  fileName=rxImagesPath+"/"+s+"."+defaultImageFormat;
  addToLog("dispatcher: saveRxImage() ",LOGDISPAT);
  rxWidgetPtr->getImageViewerPtr()->save(fileName,defaultImageFormat,TRUE);
  saveImage(fileName);
}

void dispatcher::saveImage(QString fileName)
{
  QImage im;
  QFileInfo info(fileName);
  QString fn="/tmp/"+info.baseName()+"."+ftpDefaultImageFormat;
  galleryWidgetPtr->putRxImage(fileName);
  txWidgetPtr->setPreviewWidget(fileName);
  if(enableFTP)
    {
      rxWidgetPtr->getImageViewerPtr()->save(fn,ftpDefaultImageFormat,TRUE);
      ftpIntf->uploadFile(fn,"",FALSE);
    }
}



void dispatcher::timerEvent(QTimerEvent *event)
 {
  if(event->timerId()==prTimerIndex)
    {
      txWidgetPtr->setProgress(++txTimeCounter);
      if(txTimeCounter>=100)
       {
         if(prTimerIndex>=0)
           {
             killTimer(prTimerIndex);
             prTimerIndex=-1;
             txWidgetPtr->setProgress(0);
           }
       }
      txWidgetPtr->setProgress(txTimeCounter);
    }
  else if(event->timerId()==logTimerIndex)
    {
//      addToLog(QString("dumping dispatcher status"),LOGALL);
//      if( rxFuncPtr) rxFuncPtr->logStatus();
//      if( txFuncPtr)txFuncPtr->logStatus();
//      if( sndIO)sndIO->logStatus();
    }
}










