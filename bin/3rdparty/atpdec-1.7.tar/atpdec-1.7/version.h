const char version[]="Atpdec 1.7  (c) 2004-2005 Thierry Leconte F4DWV";

