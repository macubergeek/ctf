/*
 * $Id: dt_window.c,v 1.9 2009/05/30 00:45:51 kprox Exp $
 *
 * Copyright (C) 2002:
 * Ken Prox <kprox@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 *
 * --- This object creates a discrete time window. ---
 *
 * Example:
 *
 * Let's say you want to apply a Hamming window to the array `double x[128]'
 *
 * dt_window dt_w;
 * dt_w = dt_window_create(DT_HAMMING_WINDOW, 128);
 * dt_window_apply(dt_w, x);
 * dt_window_destroy(dt_w);
 *
 * To test this object:
 * 
 * gcc -D TEST_WINDOW -o window dt_window.c -lm
 * with profiling --> gcc -D TEST_WINDOW -o window dt_window.c -lm -pg -g, then gprof window
 */

#include <stdio.h>
#include <stdint.h>
#include <math.h>
#include <string.h>

#include "dt_window.h"

typedef struct {
    char *name;
    double (* function)(int32_t num, int32_t den);
} ts_window_function;

typedef struct x_dt_window {
    uint32_t size;
    double *elements;
    ts_window_function window_function;
} x_dt_window;

#ifdef TEST_WINDOW
static void print_window(dt_window w);
#endif /* TEST_WINDOW */

/* Add additional window functions here */
static double hamming_eq(int32_t num, int32_t den);
static double hanning_eq(int32_t num, int32_t den);
static double blackman_eq(int32_t num, int32_t den);
/* Table of discrete time functions. */
static const ts_window_function discrete_time_window_function_table[DT_NUMBER_OF_WINDOWS] = {
    {"Hamming",     &hamming_eq},
    {"Hanning",     &hanning_eq},
    {"Blackman",    &blackman_eq}
};
#define NUMBER_OF_WINDOW_FUNCTIONS (sizeof(discrete_time_window_function_table) / sizeof(discrete_time_window_function_table[0]))

/* Generic discrete time window function. */
static double* dt_window_compute(te_dt_window_type type, uint32_t size);

dt_window dt_window_create(te_dt_window_type type, uint32_t size)
{
    dt_window window;

    window = malloc(sizeof(x_dt_window));
	
    if(window != NULL) {
        window->size = size;
        memcpy(
               (void*)&window->window_function,
               (void*)&discrete_time_window_function_table[type],
                sizeof(ts_window_function)
              );
        if(type < NUMBER_OF_WINDOW_FUNCTIONS) {
            window->elements = dt_window_compute(type, size);
        }
    }
    return window;
}

void dt_window_apply(dt_window w, double *data)
{
    uint32_t i;
	
    if(w != NULL) {
        if(w->elements != NULL) {
            for(i=0; i < w->size; i++) {
                data[i] = data[i] * w->elements[i];
            }
        }
    }
}

void dt_window_destroy(dt_window *w)
{
    if(*w != NULL) {
        free((*w)->elements);
    }
    free(*w);
    *w = NULL;
}

static double* dt_window_compute(te_dt_window_type type, uint32_t size)
{
    uint32_t i, j;
    double *w;

    if((w = malloc(size * sizeof(double))) != NULL) {
        if(size == 1) {
            w[0] = 1;
        }
        else {
            j = size - 1;
            for(i = 0; i < size; i++) {
                w[i] = discrete_time_window_function_table[type].function(i, j);
            }
        }
    }
    return w;
}

static double hamming_eq(int32_t num, int32_t den)
{
    return (0.54 - 0.46 * cos(2.0 * M_PI * (double)num / (double)den));
}

static double hanning_eq(int32_t num, int32_t den)
{
    return (0.5 - 0.5 * cos(2.0 * M_PI * (double)num / (double)den));
}

static double blackman_eq(int32_t num, int32_t den)
{
    return ( (0.42 - 0.5 * cos(2.0 * M_PI * (double)num / (double)den)) + (0.08 * cos(4.0 * M_PI * (double)num / (double)den)) );
}

#ifdef TEST_WINDOW
static void print_window(dt_window w)
{
    int32_t i;
	
    if(w != NULL) {
        if(w->elements != NULL) {
            printf("\n%s window function.\n", w->window_function.name); 
            for(i=0; i < w->size; i++) {
                printf("w[%d] = %f\n", i, w->elements[i]);
            }
        }
    }
}

int32_t main(int32_t argc, char *arg[])
{
    te_dt_window_type i;
    uint32_t j;
    dt_window w;

    if(arg[1] == NULL) {
        j = 8;
    }
    else {
        j = atoi(arg[1]);
    }

    for(i = 0; i < DT_NUMBER_OF_WINDOWS; i++) {
        w = dt_window_create(i, j);
        print_window(w);
        dt_window_destroy(&w);
    }        
	
    return 0;
}
#endif /* TEST_WINDOW */
