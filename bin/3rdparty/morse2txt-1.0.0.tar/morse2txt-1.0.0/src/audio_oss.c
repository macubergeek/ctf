/*
 * Copyright by Ken Prox 2002, 2005, modified from recplay.c for use with morse2txt
 *
 * Original Copyright Info:
 * 
 * A simple recording and playback program for the Linux Sound Driver 2.0
 * or later.
 * 
 * Copyright by Hannu Savolainen 1993
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met: 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer. 2.
 * Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 */

#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif

#ifdef HAVE_SYS_SOUNDCARD_H
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>

#ifdef __STDC__
    #include <string.h>
#else /* __STDC__ */
    #include <strings.h>
#endif /* __STDC__ */

#include <sys/ioctl.h>
#include <sys/soundcard.h>

#include "audio_oss.h"
                                      /* # of frags | frag size 2^y */
#define DSP_FRAGMENT                    (0x7fff0000 | 0x000b)

int32_t audio_open_oss(p_audio_pub device)
{
    int32_t err;
    int32_t fctl;
    
    if(device->play_record == AUDIO_DEVICE_RECORD) {
        fctl = (O_RDONLY | O_NONBLOCK);
    }
    else if(device->play_record == AUDIO_DEVICE_PLAY) {
        fctl = (O_WRONLY | O_NONBLOCK);
    }        
    else {
        fctl = (O_RDONLY | O_NONBLOCK);
    }        

    /* Test to see if audio device is busy. */
    device->handle = open(device->name, fctl, 0);
    if (device->handle == -1) {
        perror (device->name);
        device->error_msg_handler("Audio device busy.\nAnother program may be using the sound device.");
        err = -1;
    }
    else {
        /*
         * Some apps close the audio device, and re-open w/o O_NONBLOCK.
         * Well, what if some other app opens the audio device midstream that process?
         * A locked condition can still occur.
         * Better to clear the O_NONBLOCK flag while the device is open. 
         */
        fcntl(device->handle, F_SETFL, 0);
        err = 0;
    }
    return err;
}

int32_t audio_init_oss(p_audio_pub device)
{
    int32_t tmp;
	
    device->dsp_channels = AUDIO_MONO;
    device->format = AFMT_S16_LE;
    device->samplesize = 16;
    device->buffer_segments = AUDIO_BUFFER_SEGMENTS;
    device->fragsize= DSP_FRAGMENT;

    if(device->fragsize != 0) {
        if(ioctl(device->handle, SNDCTL_DSP_SETFRAGMENT, &device->fragsize) == -1) {
            perror("SETFRAGMENT");
            device->error_msg_handler("Unable to set audio fragment.");
            return(-1);
        }
    }        

    tmp = device->samplesize;
    ioctl(device->handle, SNDCTL_DSP_SAMPLESIZE, &device->samplesize);
    if (tmp != device->samplesize) {
        fprintf(stderr, "Unable to set the sample size\n");
        device->error_msg_handler("Unable to set audio sample size.");
        return(-1);
    }

    if (ioctl(device->handle, SNDCTL_DSP_STEREO, &device->dsp_channels) == -1) {
        fprintf (stderr, "Unable to set mono/stereo\n");
        perror (device->name);
        device->error_msg_handler("Unable to set mono mode.");
        return(-1);
    }
    if(device->dsp_channels != AUDIO_MONO) {
        perror("mono format not supported");
    }

    device->format = AFMT_S16_LE;
    if (ioctl (device->handle, SNDCTL_DSP_SETFMT, &device->format) == -1) {
        fprintf (stderr, "Unable to little endian sound format\n");
        device->error_msg_handler("Unable to set little endian sound format.");
        perror (device->name);
        return(-1);
    }
    if(device->format != AFMT_S16_LE) {
        perror("Sound format not supported");
        device->error_msg_handler("Audio sound format not supported.");
    }

    if (ioctl (device->handle, SNDCTL_DSP_SPEED, &device->sample_frequency) == -1) {
        fprintf (stderr, "Unable to set audio sampling rate\n");
        perror (device->name);
        device->error_msg_handler("Unable to audio sampling rate.");
        return(-1);
    }
    ioctl (device->handle, SNDCTL_DSP_GETBLKSIZE, &device->audio_buffer_size);
    if(device->audio_buffer_size < 0) {
        perror ("GETBLKSIZE");
        return(-1);
    }
	
    /*                samples                      bits/Sa                     channels */
    /*                n                            16 (or 8) / 8               1, 2 */
    device->samples = device->audio_buffer_size / (device->samplesize >> 3) / (device->dsp_channels + 1);

    if ((device->audio_buffer_raw = malloc ((size_t)(device->audio_buffer_size * device->buffer_segments))) == NULL) {
        fprintf (stderr, "Unable to allocate input/output buffer\n");
        device->error_msg_handler("Unable to allocate input/output buffer.");
        return(-1);
    }
    return 0;
}

int32_t audio_close_oss(p_audio_pub device)
{
    if(device->handle != -1) {
        close (device->handle);
    }        
    return 0;
}

void audio_record_oss(p_audio_pub device, te_audio_segments buffer_segment)
{
    int32_t l;
    int32_t offset;

    offset = device->audio_buffer_size * buffer_segment;

    if((l = read (device->handle, &device->audio_buffer_raw[offset], device->audio_buffer_size)) <= 0) {
        fprintf (stderr, "Unable to read data from audio device\n");
        device->error_msg_handler("Unable to read data from audio device.\nTry lowering the sample rate.");
    }
}

void audio_play_oss(p_audio_pub device, te_audio_segments buffer_segment)
{
    int32_t l;
    int32_t offset;

    offset = device->audio_buffer_size * buffer_segment;

    if((l = write(device->handle, &device->audio_buffer_raw[offset], device->audio_buffer_size)) <= 0) {
        fprintf (stderr, "Unable to write data to audio device\n");
        device->error_msg_handler("Unable to write data to audio device.\nTry lowering the sample rate.");
    }
}
#endif /* HAVE_SYS_SOUNDCARD_H */
