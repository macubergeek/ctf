/*
 * $Id: agc.h,v 1.11 2009/05/30 00:45:51 kprox Exp $
 *
 * Copyright (C) 2002-2006:
 * Ken Prox <kprox@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */
#ifndef AGC_H
#define AGC_H

/** AGC algorithm types.
 *  \sa gain_decrease_correct
 *  \sa current_amplitude
 *  \sa max_amp
 *  \sa gain_increase_correct
 */
typedef enum {
    /*! This type of AGC reduces the gain by gain_decrease_correct when 
     *  current_amplitude is above max_amp.  If this is false, agc gain
     *  is increased by gain_increase_correct.
     */
    AGC_LINEAR_PEAK_LIMIT = 0,
    /*! This type of AGC multiplies the gain by (1 - gain_decrease_correct) when 
     *  current_amplitude is above max_amp.  If current_amplitude is below max_amp,
     *  and above noise_floor, it multiples the gain by (1 + gain_increase_correct).
     */
    AGC_PERCENTAGE_W_NOISE_FLOOR,
    /*! This type of AGC multiplies the gain by (1 - gain_decrease_correct) when 
     *  current_amplitude is above max_amp.  If current_amplitude is below max_amp
     *  it multiples the gain by (1 + gain_increase_correct).
     */
    AGC_PERCENTAGE_PEAK_LIMIT,
    /*! This type of AGC reduces computes the correct gain when 
     *  current_amplitude is above max_amp.  If this is false, agc gain
     *  is increased by gain_increase_correct.
     */
    AGC_LINEAR_PEAK_W_COMPUTED_GAIN_ON_CLIP,
    AGC_NUMBER_OF_ADJUSTMENT_TYPES
} te_agc_types;    

/** Pointer to a automatic gain object (private members).
 *  Used to scale the FFT data to fit on the FFT plot.
 */
typedef struct s_agc *agc;

/** Creates, and returns a pointer to an agc object. @sa agc_destroy
 *  \param max_gain  The maximum gain of the agc object.
 *  \param min_gain  The minimum gain of the agc object.
 *  \param noise_floor  The minimum amplitude required to compute a ngew gain.
 *  \param max_amp  The maximum amplitude desired.
 *  \param agc_type The type of AGC gain correction. 
 *  \param gain_increase_correct The factor by which the gain will be increased.
 *  \param gain_decrease_correct  The factor by which the gain will be decreased.
 */
agc agc_create(double max_gain,
               double min_gain,
               double noise_floor,
               double max_amp,
               te_agc_types agc_type,
               double gain_increase_correct,
               double gain_decrease_correct);

/** De-allocates the automatic gain object.
 *  @param gain_object Pointer to the gain object to destroy. @sa agc @sa agc_create
 */
void agc_destroy(agc *gain_object);

/** Updates the agc gain, returns the new gain. \sa agc_create
 *  @param gain_object Automatic gain control object.
 *  @param current_amplitude  The current amplitude.
 */
double agc_update(agc gain_object, double current_amplitude);

#endif  /* AGC_H */
