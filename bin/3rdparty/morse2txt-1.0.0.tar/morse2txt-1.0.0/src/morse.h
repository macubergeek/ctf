/*
 * $Id: morse.h,v 1.34 2009/05/30 00:45:51 kprox Exp $
 *
 * Copyright (C) 2002-2006:
 * Ken Prox <kprox@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */
#ifndef MORSE_H
#define MORSE_H

#include <stdint.h>
#include "audio.h"

/* begin debugging options */
/** Use the plotting capabilities from rscw for debugging purposes. */
#define DEBUG_GRAPH_INTERFACE 0
/* end debugging options */

//! Divide the number of FFT terms by this, before graphing
#define FFT_DATA_SIZE_DIVISOR               4

//! Possible ploting type supported in GUI.
typedef enum {
    /*! No plot. */
    NO_PLOT = 0,
    /*! Plot the FFT, normal for selecting frequency to decode. */
    PLOT_FFT,
    /*! Plot a display of the incoming audio. good for setting correct audio level. */
    PLOT_SCOPE
} te_morse_plot_type;

/** Filter apply options. */
typedef enum {
    /*! Do not apply Filter. */
    MORSE_DISABLE_FILTER = 0,
    /*! Apply Filter. */
    MORSE_ENABLE_FILTER
} te_morse_filter_enable;    

/** AGC (automatic gain control) options. */
typedef enum {
    /*! Do not apply AGC. */
    MORSE_DISABLE_AGC = 0,
    /*! Apply AGC. */
    MORSE_ENABLE_AGC
} te_morse_agc_enable;    

/** Morse Statistics Display. */
typedef struct morse_stats_ts {
    double avg_dit_dur;
    double avg_dah_dur;
    double dah_dit_ratio;
    double wpm;
} morse_stats_ts;    

//! Inteface functions for morse GUI handling.
typedef void (*UI_update_status)(uint32_t ffts, uint32_t samples, double wpm);
typedef void (*UI_scope_plot)(double *vector, uint32_t num_points);
typedef void (*UI_display_character)(char *character);
/** Inteface functions for debug plots */
typedef void (*UI_debug_plot)(const int8_t *plot, int32_t y);
typedef void (*UI_Morse_statistics)(const morse_stats_ts* morse_status_ps);

//! Returns the maximum words per minute that can be supported, based on seletected audio settings. */
double morse_max_wpm_supported(double sample_frequency, double packet_length);

//! Starts the data acquisition and morse code detector threads.
int32_t morse_start_threads(void);

//! Thread states.
typedef enum {
    THREADS_NOT_RUNNING = 0,
    THREADS_STARTING,
    THREADS_RUNNING,
/*! Waiting for pthread_join. */
    THREADS_CANCELING
} te_morse_thread_state;

/** Stops the data acquisition and morse code detector threads.
 *  \sa te_morse_thread_state 
 */
te_morse_thread_state morse_stop_threads(void);

/** Set the desired CW frequency to decode. */
void morse_set_cw_frequency(int32_t freq);

/** Set the bandwidth of the FIR window filter. */
void morse_set_filter_bandwidth(int32_t bw);
/** Get the bandwidth of the FIR window filter. */
int32_t morse_get_filter_bandwidth(void);

/** Set the number of taps in the FIR window filter. */
void morse_set_filter_taps(uint32_t taps);
/** Get the number of taps in the FIR window filter. */
uint32_t morse_get_filter_taps(void);

/** Enables or disables filter.
 *  \param apply Filter apply.
 *  \sa te_morse_filter_enable 
 */
void morse_set_filter_apply(te_morse_filter_enable apply);

/** Enables or disables AGC.
 *  \param agc_apply AGC apply.
 *  \sa te_morse_filter_enable 
 */
void morse_set_agc_apply(te_morse_agc_enable agc_apply);

//! Returns the current packet size for FFT tone detection.
uint32_t morse_get_tone_packet_size(void);
//! Sets the FFT data packet size to be used for morse tone detection.
void morse_set_tone_packet_size(int32_t tone_packet_size);

//! Returns the array size for the FFT data.
uint32_t morse_get_fft_data_size(void);
//! Sets the array data size for the FFT data array.
void morse_set_fft_data_size(uint32_t fft_data_size);
//! Returns the top (max amplitude) of the current FFT window.
double morse_get_fft_graph_top(void);
/** Returns pointer to the audio record device. */
p_audio_device morse_audio_rec_dev_get(void);

/** Get the current audio device type Id.
 *  @returns The audio devicetype ID.
 */
int32_t morse_audio_device_type_id_get(void);

/** Set the current audio device type Id.
 *  @param audio_device_type_id The Id of the audio device type..
 */
void morse_audio_device_type_id_set(int32_t audio_device_type_id);

/** Set the audio sample rate.
 *  @param Hertz The desired sample rate in Hertz.
 */
void morse_audio_sample_rate_set(int32_t Hertz);

/** Get the current audio sample rate.
 *  @returns Sample frequency.
 */
int32_t morse_audio_sample_rate_get(void);

//! Returns the current plot type, FFT, Scope, or NONE.
te_morse_plot_type morse_get_plot_type(void);
//! Set the desired plot type, this usually comes from some GUI callback/event.
void morse_set_plot_type(te_morse_plot_type plt_type);
/** Returns the current state of the morse threads. */
te_morse_thread_state morse_get_thread_state(void);

/** Morse Constructor
 *  Make sure all interfaces are NULL to start, this must be called before running morse.
 */
void morse_initialize(void);

/** Morse Destructor */
void morse_shutdown(void);

/*! Set the GUI handler for status bar updates. */
void set_update_status_hndlr(UI_update_status hndlr);

/*! Set the GUI handler for real-time data plotting for either FFT's or Scope. */
void set_scope_plot_hndlr(UI_scope_plot hndlr);

/*! Set the GUI handler that appends a decoded morece character to the display. */
void set_display_character_hndlr(UI_display_character hndlr);

/*! Set the GUI handler that displays Morse statistics. */
void set_Morse_statistics_display_hndlr(UI_Morse_statistics hndlr);

#if DEBUG_GRAPH_INTERFACE == 1
    void register_debug_plot(UI_debug_plot hndlr);
#else    
    #define register_debug_plot(a)
#endif    

#endif /* MORSE_H */
