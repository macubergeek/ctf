#ifndef CALLBACKS_H
#define CALLBACKS_H

#include <gnome.h>

gboolean
on_MainWindow_delete_event             (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_exit1_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_statistics_activate                 (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_preferences_activate                (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_icons_and_or_text_activate          (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_filter_bw_activate                  (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_startbutton_clicked                 (GtkToolButton   *toolbutton,
                                        gpointer         user_data);

void
on_stop_button_clicked                 (GtkToolButton   *toolbutton,
                                        gpointer         user_data);

void
on_clear_txt_button_clicked            (GtkToolButton   *toolbutton,
                                        gpointer         user_data);

void
on_scope_fft_button_clicked            (GtkToolButton   *toolbutton,
                                        gpointer         user_data);

void
on_agc_apply_btn_toggled               (GtkToggleToolButton *toggletoolbutton,
                                        gpointer         user_data);

void
on_enable_fir_button_toggled           (GtkToggleToolButton *toggletoolbutton,
                                        gpointer         user_data);

void
on_exit_button_clicked                 (GtkToolButton   *toolbutton,
                                        gpointer         user_data);

void
on_adjustment_release_event            (GtkAdjustment   *widget,
                                        gpointer        user_data);
#endif /* CALLBACKS_H */

