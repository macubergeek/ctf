#include <gnome.h>



void
on_stats_window_show                   (GtkWidget       *widget,
                                        gpointer         user_data);
gboolean
on_stats_window_delete_event           (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);
