/*
 * $Id: fir_win.c,v 1.16 2009/05/30 00:45:51 kprox Exp $
 *
 * Copyright (C) 2005:
 * Ken Prox <kprox@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 *
 * --- This object implements a FIR Filter Design Based on the Windows Method ---
 *
 * Example:
 *
 * Let's say you want to apply a bandpass filter to `double x[128]'
 *
 * p_fwin fw;
 * fw = fwin_create(8000.0,
                    200.0,
                    300.0,
                    FW_BANDPASS,
                    FW_NONE,
                    16);
 * fwin_apply(fw, x, 128);
 * fwin_destroy(fw);
 *
 * To test this object:
 * 
 * gcc -D TEST_FIR_WIN -o fir_win fir_win.c -lm 
 * with profiling --> add -pg -g
 *
 * With Discrete time window support, put this in a simple Makefile:
 * 
 *GCC=gcc
 *
 *all:
 *       $(GCC) -DTEST_FIR_WIN -c fir_win.c -g -Wall -O2
 *       $(GCC) -c dt_window.c -g -Wall -O2
 *       $(GCC) -lm -g -O2 -o fir_win.exe fir_win.o dt_window.o
 */

#include <stdlib.h>
#ifdef TEST_FIR_WIN
    #include <stdio.h>
#endif
#include <string.h>
#include <math.h>
#include <stdint.h>

#include "fir_win.h"

#if (FWIN_USE_WINDOW_FUNCTION == 1) 
    #include "dt_window.h"
#endif    

#define FW_2PI              (2.0 * M_PI)
#define DOUBLE_Z_FIR        2

/** \struct ts_fwin
 *  \brief Private Data for Fir Window Filter.
 */
typedef struct ts_fwin {
    /*! Sample frequency in Hertz. */
    double                  sample_freq;
    /*! Low frequency cut-off in Hertz. */
    double                  f_low;
    /*! High frequency cut-off in Hertz. */
    double                  f_high;
    /*! Filter Type (band_pass, band_stop, low_pass, high_pass. */
    te_fir_win_filter_type  filter_type;
    /*! Window method to apply to FIR filter coefficients. */
    te_fir_win_window_type  window_type;
    /*! FIR Filter Delay Line. */
    double                  *z;
    /*! Delay line state. */
    int32_t                 z_state;
    /*! FIR filter coefficients. */
    double                  *h;
    /*! FIR filter order N (taps). */
    uint32_t                taps;
    /*! Window function object for FIR filter coefficients. */
#if (FWIN_USE_WINDOW_FUNCTION == 1) 
    dt_window               h_window;
#endif    
} ts_fwin;

#if (FWIN_USE_WINDOW_FUNCTION == 1) 
static const te_dt_window_type FW_WINDOW_TABLE[FW_NUMBER_OF_WINDOW_TYPES] = {
    0,                      /* FW_NONE */
    DT_HAMMING_WINDOW,      /* FW_HAMMING */
    DT_HANNING_WINDOW,      /* FW_HANNING */
    DT_BLACKMAN_WINDOW      /* FW_BLACKMAN */
};
/** \todo These could be combined. */
static void fwin_apply_window(p_fwin fw);
static void fwin_reapply_window(p_fwin fw);
#else
    #define fwin_apply_window(a)
    #define fwin_reapply_window(a)
#endif

typedef void ( * fwin_filter_function)(p_fwin fw);

/* Computes H[] for a bandpass FIR filter using the Window method. */
static void band_pass(p_fwin fw);
/** \todo Implement band_stop. */
static void band_stop(p_fwin fw);
/** \todo Implement low_pass. */
static void low_pass(p_fwin fw);
/** \todo Implement high_pass. */
static void high_pass(p_fwin fw);
/* Computes H[] for a averaging FIR filter. H[] = { 1/taps, ... } */
static void average(p_fwin fw);

static const fwin_filter_function FW_FILTER_FUNCTIONS[FW_NUMBER_OF_FILTER_TYPES] = {
    band_pass,      /* FW_BANDPASS */
    band_stop,      /* FW_BANDSTOP */
    low_pass,       /* FW_LOWPASS  */
    high_pass,      /* FW_HIGHPASS */
    average         /* FW_AVERAGE  */
};

p_fwin fwin_create(double sample_freq,
                   double f_low,
                   double f_high,
                   te_fir_win_filter_type filter_type,
                   te_fir_win_window_type window_type,
                   uint32_t taps)
{
    p_fwin fw;

    if( (fw = malloc(sizeof(ts_fwin))) != NULL) {
        #if (FWIN_USE_WINDOW_FUNCTION == 1) 
        fw->h_window = NULL;
        #endif    
        fw->taps = taps;
        fw->window_type = window_type;
        fw->filter_type = filter_type;
        fw->sample_freq = sample_freq;
        fw->f_low = f_low;
        fw->f_high = f_high;
        fw->z_state = 0;
        if(
            ((fw->h = malloc((taps * sizeof(double)))) != NULL)
                && \
            ((fw->z = malloc((DOUBLE_Z_FIR * taps * sizeof(double)))) != NULL)
          )  
        {
            if(filter_type < FW_NUMBER_OF_FILTER_TYPES) {
                FW_FILTER_FUNCTIONS[filter_type](fw);
            }
            fwin_apply_window(fw);
        }
        else {
            free(fw->h);
            free(fw->z);
            free(fw);
            fw = NULL;
        }            
    }        
    return fw;
}

void fwin_change_freq(p_fwin fw,
                      double f_low,
                      double f_high)
{
    if(fw != NULL) {
        fw->f_low = f_low;
        fw->f_high = f_high;
        FW_FILTER_FUNCTIONS[fw->filter_type](fw);
        fwin_reapply_window(fw);
    }        
}

/* 
 * Double delay line FIR filter.
 * Applied in double z fashion.
 */
void fwin_apply(p_fwin fw, double *data, uint32_t size)
{
    uint32_t i, j;
    int32_t state;
    double accum;
    double *p_z, *p_h;
        
    if(fw != NULL) {
        state = fw->z_state;
        for(i = 0; i < size; i++) {
            /* store input at the beginning of the delay line as well as taps more */
            fw->z[state] = fw->z[state + fw->taps] = data[i];
            /* calculate the filter */
            p_z = fw->z + state; 
            p_h = fw->h;
            accum = 0.0;
            for (j = 0; j < fw->taps; j++) {
                accum += *p_h++ * *p_z++;
            }
            /* decrement state, wrap if below zero */
            state--;
            if(state < 0) {
                state += fw->taps;
            }
            fw->z_state = state;       
            data[i] = accum;            
        }
    }
}

void fwin_destroy(p_fwin *fw)
{
    if(*fw != NULL) {
        free((*fw)->h);
        free((*fw)->z);
#if (FWIN_USE_WINDOW_FUNCTION == 1) 
        free((*fw)->h_window);
#endif    
        free(*fw);
        *fw = NULL;
    }        
}

static void band_pass(p_fwin fw)
{
    uint32_t i;
    double w1, w2;
    double den, num;
    double N = (double)fw->taps;
        
    w1 = fw->f_low / fw->sample_freq * FW_2PI;  
    w2 = fw->f_high / fw->sample_freq * FW_2PI;  
    
    for(i = 0; i < fw->taps; i++) {
        den = M_PI * ((double)i - (N - 1.0) / 2.0);
        if(den != 0.0) {
            num = sin(w2 * ((double)i - (N - 1.0) / 2.0) ) - \
                  sin(w1 * ((double)i - (N - 1.0) / 2.0));
            fw->h[i] = num / den;
        }            
        else {
            fw->h[i] = ( w2 - w1 ) / M_PI;
        }            
    }
}                 

static void band_stop(p_fwin fw)
{
    fw = fw;
}

static void low_pass(p_fwin fw)
{
    fw = fw;
}

static void high_pass(p_fwin fw)
{
    fw = fw;
}

static void average(p_fwin fw)
{
    uint32_t i;
    double tmp = 1.0 / (double)fw->taps;
        
    for(i = 0; i < fw->taps; i++) {
        fw->h[i] = tmp;
    }
}                 

#if (FWIN_USE_WINDOW_FUNCTION == 1) 
static void fwin_apply_window(p_fwin fw)
{
    if(
        (fw->window_type < FW_NUMBER_OF_WINDOW_TYPES) 
            && \
        (fw->window_type != FW_NONE)
      )
    {
        fw->h_window = dt_window_create((te_dt_window_type)FW_WINDOW_TABLE[fw->window_type], fw->taps);
        dt_window_apply(fw->h_window, fw->h);
    }       
}

static void fwin_reapply_window(p_fwin fw)
{
    if(fw->window_type != FW_NONE) {
        dt_window_apply(fw->h_window, fw->h);
    }       
}
#endif

#ifdef TEST_FIR_WIN

#define TAPS    12

/* Desired H with out window function applied. */
static const double BP_TEST_VECTOR[] = {
   -2.3592e-02,
   -2.3653e-02,
   -1.4648e-02,
    1.4136e-17,
    1.4686e-02,
    2.3775e-02,
    2.3775e-02,
    1.4686e-02,
    1.4136e-17,
   -1.4648e-02,
   -2.3653e-02,
   -2.3592e-02
};

/* Desired H with Blackman window function applied. */
static const double BP_TEST_VECTOR_BM[] = {
    3.2740e-19,
   -7.7124e-04,
   -2.3423e-03,
    5.8578e-18,
    1.0810e-02,
    2.2991e-02,
    2.2991e-02,
    1.0810e-02,
    5.8578e-18,
   -2.3423e-03,
   -7.7124e-04,
    3.2740e-19
};

/** Array with a couple impulses. */
static double test[] = {
    0.0, 0.0, 0.0, 0.0, 0.0, 100.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    100.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 100.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
};    
#define SAMPLES (sizeof(test) / sizeof(double))


int main(int argc, char *arg[])
{
    int i;
    p_fwin fw;

    fw = fwin_create(8000.0,
                     750.0,
                     850.0,
                     FW_BANDPASS,
#if (FWIN_USE_WINDOW_FUNCTION == 1) 
                     FW_BLACKMAN,
#else
                     FW_NONE,
#endif                     
                     TAPS);

    printf("H[] computed, H[] test vector, H[] w/Blackman test vector\n");
    for(i = 0; i < TAPS; i++) {
        printf("%12.4E, %12.4E, %12.4E\n",
               fw->h[i],
               BP_TEST_VECTOR[i],
               BP_TEST_VECTOR_BM[i]);
    }        
    fwin_apply(fw, test, SAMPLES);
    fwin_change_freq(fw, 100.0, 200.0); 
    fwin_apply(fw, test, SAMPLES);
    fwin_destroy(&fw);
    return 0;
}
#endif /* TEST_FIR_WIN */
