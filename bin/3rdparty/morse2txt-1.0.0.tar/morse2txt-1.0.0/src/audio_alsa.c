/*
 * audio_alsa.c
 * $Id: audio_alsa.c,v 1.3 2009/05/30 00:45:51 kprox Exp $
 *
 * Copyright (C) 2005:
 * Ken Prox <kprox@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */

#ifdef __STDC__
    #include <string.h>
#else /* __STDC__ */
    #include <strings.h>
#endif /* __STDC__ */

#include "audio_alsa.h"

#ifdef HAVE_ALSA_ASOUNDLIB_H
/** @todo Lots todo here for alsa sound API. */
#endif /* HAVE_ALSA_ASOUNDLIB_H */
