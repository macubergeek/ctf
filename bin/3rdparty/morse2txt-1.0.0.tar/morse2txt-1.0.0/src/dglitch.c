/*
 * $Id: dglitch.c,v 1.14 2009/05/30 00:45:51 kprox Exp $
 *
 * Copyright (C) 2005:
 * Ken Prox <kprox@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 *
 * --- This object is a dglitch filter. ---
 *
 * Example:
 *
 * Let's say you want to dglitch the array `double x[128]'
 *
 * p_dglitch dg;
 * dg = dglitch_create(DG_MEDIAN, 128);
 * dglitch_apply(dg, x);
 * dglitch_destroy(dg);
 *
 * To test this object:
 * 
 * gcc -D TEST_DGLITCH -o dglitch dglitch.c -lgsl -lgslcblas
 * with profiling --> add -pg -g
 */

#include <stdint.h>
#include <stdlib.h>
#ifdef TEST_DGLITCH
    #include <stdio.h>
#endif
#include <string.h>
#include <gsl/gsl_sort.h>
#include <gsl/gsl_statistics.h>

#include "dglitch.h"

#define DG_STRIDE           (size_t)1

#define DEBUG_DEGLITCH(a) /* printf a */

/** \struct ts_dglitch
 *  \brief Private members of dglitch object. */ 
typedef struct ts_dglitch {
    /*! Delay line, previous measurements. */
    double *stack;
    /*! Delay line buffer used for sorting, required by gsl_sort(... */
    double *sorted_stack;
    /*! The window size of the de-glitch filter. */
    uint32_t window_size;
    /*! The de-glitch algorithm used. */
    te_dglitch_type dglitch_algor;
} ts_dglitch;

/** Push new number onto de-glitcher stack
 *  \param dg Pointer to deglitch object.
 *  \param num Number to push onto stack.
 *  @todo Should be implemented in double Z fir fashion.
 */
static void dg_push(p_dglitch dg, double num);

/** Temporary. */
static void dg_sort(double *vector, uint32_t size);
/** Temporary. */
static int32_t dg_compare(const void *val1, const void *val2);

p_dglitch dglitch_create(te_dglitch_type type, uint32_t window_size)
{
    p_dglitch dg;

    if( (dg = malloc(sizeof(struct ts_dglitch))) != NULL) {
        dg->window_size = window_size;
        if(
            ((dg->stack = malloc((window_size * sizeof(double)))) != NULL)
                && \
            ((dg->sorted_stack = malloc((window_size * sizeof(double)))) != NULL)
          )
        {
        }
        else {
            free(dg->sorted_stack);
            free(dg->stack);
            free(dg);
            dg = NULL;
        }            
    }        
    return dg;
}

void dglitch_apply(p_dglitch dg, double *data, uint32_t size)
{
    uint32_t i;
    
    if(dg != NULL) {
        for(i = 0; i < size; i++) {
            dg_push(dg, data[i]);
            (void)memcpy((void*)dg->sorted_stack, (void*)dg->stack, (size_t)(dg->window_size * sizeof(double)));
            /** \todo Problem HERE, gsl_sort freezes! This is a workaround. */
            dg_sort((void*)dg->sorted_stack, dg->window_size);
#if 0            
            gsl_sort(dg->sorted_stack, DG_STRIDE, dg->window_size); 
#endif            
            DEBUG_DEGLITCH( ("%12.3f,", data[i]) );
            data[i] = gsl_stats_median_from_sorted_data(dg->sorted_stack, DG_STRIDE, dg->window_size);
            DEBUG_DEGLITCH( ("%12.3f\n", data[i]) );
        }
    }                    
}

static void dg_sort(double *vector, uint32_t size)
{
    qsort((void*)vector, size, sizeof(double), dg_compare);
}

static int32_t dg_compare(const void *val1, const void *val2)
{
    int32_t ret;
    
    double a = *((double*)val1);
    double b = *((double*)val2);
    if(a < b) {
        ret = -1;
    }
    else if(a == b) {
        ret = 0;
    }
    else {
        ret = 1;
    }
    return ret;
}

void dglitch_destroy(p_dglitch *dg)
{
    if(*dg != NULL) {
        free((*dg)->stack);
        free((*dg)->sorted_stack);
        free(*dg);
        *dg = NULL;
    }        
}

static void dg_push(p_dglitch dg, double num)
{
    int32_t i;

    for(i = (dg->window_size - 1); i > 0; i--) {
        dg->stack[i] = dg->stack[i - 1];
    }
    dg->stack[0] = num;
}

#ifdef TEST_DGLITCH

static double test[] = {
    1.0,
    1.0,
    1.0,
    1.0,
    1.0,
    10.0,
    10.0,
    10.0,
    10.0,
    10.0,
    15.0,
    15.0,
    15.0,
    15.0,
    15.0,
    100.0,
    100.0,
    100.0,
    100.0,
    100.0,
    100.0
};
#define TEST_SIZE (sizeof(test) / sizeof(test[0]))

int32_t main(int32_t argc, char *arg[])
{
    int32_t i;
    
    p_dglitch dg;
    
    dg = dglitch_create(DG_MEDIAN, 5);
    dglitch_apply(dg, test, TEST_SIZE);
    dglitch_destroy(&dg);
    
    for(i = 0; i < TEST_SIZE; i++) {
        printf("%f\n", test[i]);
    }        
    return 0;
}
#endif /* TEST_DGLITCH */
