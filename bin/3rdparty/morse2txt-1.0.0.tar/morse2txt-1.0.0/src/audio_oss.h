/*
 * $Id: audio_oss.h,v 1.7 2009/05/30 00:45:51 kprox Exp $
 *
 * Copyright (C) 2002-2006:
 * Ken Prox <kprox@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */
#ifndef AUDIO_OSS_H
#define AUDIO_OSS_H

#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif

#include <stdint.h>
#include "audio.h"

#ifdef HAVE_SYS_SOUNDCARD_H 
    int32_t audio_open_oss(p_audio_pub device);
    int32_t audio_init_oss(p_audio_pub device);
    int32_t audio_close_oss(p_audio_pub device);
    void audio_record_oss(p_audio_pub device, te_audio_segments buffer_segment);
    void audio_play_oss(p_audio_pub device, te_audio_segments buffer_segment);
#else /* HAVE_SYS_SOUNDCARD_H */
    #define audio_open_oss NULL
    #define audio_init_oss NULL
    #define audio_close_oss NULL
    #define audio_record_oss NULL
    #define audio_play_oss NULL
#endif /* HAVE_SYS_SOUNDCARD_H */

#endif /* AUDIO_OSS_H */
