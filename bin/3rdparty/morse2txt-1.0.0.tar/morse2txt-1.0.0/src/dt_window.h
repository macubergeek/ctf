/*
 * $Id: dt_window.h,v 1.7 2009/05/30 00:45:51 kprox Exp $
 *
 * Copyright (C) 2002-2006:
 * Ken Prox <kprox@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */
#ifndef DT_WINDOW_H
#define DT_WINDOW_H

#include <stdlib.h>
#include <stdint.h>

typedef enum {
    DT_HAMMING_WINDOW = 0,
    DT_HANNING_WINDOW,
    DT_BLACKMAN_WINDOW,
    DT_NUMBER_OF_WINDOWS
} te_dt_window_type;

typedef struct x_dt_window *dt_window;

//! Pointer to an discrete time window object.
/*! Used to limit FFT leakage.
	\param type window function (hamming, hanning).
	\param size the size of the window function, same as the audio packet data size.
*/
dt_window dt_window_create(te_dt_window_type type, uint32_t size);

//! De-allocates the discrete time window object. \sa dt_window_create
void dt_window_destroy(dt_window *w);

//! Applies a discrete time window to real waveform data.
/*! \sa dt_window_create
	\param w pointer to discrete time window object.
	\param data pointer to real array to apply discrete time window funtion to.
*/
void dt_window_apply(dt_window w, double *data);

#endif  /* DT_WINDOW_H */
