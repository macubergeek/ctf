#ifndef UTILITY_H

/** Log events to a file with timestamp.
 *  @param fn Filename to save results to.
 *  @param event Name of the event.
 *  @returns errno Error for file access.
 *  @note When calling this from threads, each thread must have a unique
 *  filename.
 */ 
#include <stdint.h>

int time_stamp(char *fn, char *event);

int16_t millisec_get(void);


#define UTILITY_H
#endif /* UTILITY_H */
