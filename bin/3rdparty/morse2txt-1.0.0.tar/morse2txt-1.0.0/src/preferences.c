/*
 * $Id: preferences.c,v 1.9 2009/05/30 00:45:51 kprox Exp $
 *
 * Copyright (C) 2002-2006:
 * Ken Prox <kprox@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */
#include <gnome.h>

#include "interface.h"
#include "interface_il.h"
#include "audio.h"
#include "morse.h"

#include "preferences.h"

void load_config_file(void)
{
    char *s = NULL;
    static char tmp[AUDIO_DEVICE_NAME_LENGTH];

    gnome_config_push_prefix ("/morse2txt/GUI/");
    main_gui.pane_position = gnome_config_get_int("pane_position=250");
    main_gui.toolbar_style = gnome_config_get_int("toolbar_style=2");

    main_gui.width = gnome_config_get_int ("main_width=500");
    main_gui.height = gnome_config_get_int ("main_height=500");

    gnome_config_pop_prefix ();

    gnome_config_push_prefix ("/morse2txt/Morse/");
    morse_set_tone_packet_size(gnome_config_get_int ("tone_packet_size=64"));
    morse_set_fft_data_size(morse_get_tone_packet_size() / FFT_DATA_SIZE_DIVISOR);
    gnome_config_pop_prefix ();

    gnome_config_push_prefix ("/morse2txt/AudioDevice/");
    morse_audio_device_type_id_set(gnome_config_get_int ("device_type_id=0"));
    s = gnome_config_get_string ("device=/dev/dsp");
    g_snprintf(tmp, AUDIO_DEVICE_NAME_LENGTH, "%s", s);
    audio_device_name_set(morse_audio_rec_dev_get(), tmp);
    morse_audio_sample_rate_set(gnome_config_get_int ("sample_frequency=16000"));
    gnome_config_pop_prefix ();

    gnome_config_push_prefix ("/morse2txt/Filter/");
    morse_set_filter_bandwidth(gnome_config_get_int ("filter_bandwidth=1000"));
    morse_set_filter_taps(gnome_config_get_int ("filter_taps=32"));
    
    gnome_config_pop_prefix ();
}

void save_config_file(void)
{
    char *tmp;
    
    gnome_config_push_prefix ("/morse2txt/GUI/");
    gnome_config_set_int ("pane_position", main_gui.pane_position);
    gnome_config_set_int ("toolbar_style", main_gui.toolbar_style);
    
    gnome_config_set_int ("main_x_location", main_gui.x);
    gnome_config_set_int ("main_y_location", main_gui.y);
    gnome_config_set_int ("main_width", main_gui.width);
    gnome_config_set_int ("main_height", main_gui.height);

    gnome_config_pop_prefix ();

    gnome_config_push_prefix ("/morse2txt/Morse/");
    gnome_config_set_int ("tone_packet_size", morse_get_tone_packet_size());
    gnome_config_pop_prefix ();

    gnome_config_push_prefix ("/morse2txt/AudioDevice/");
    gnome_config_set_int ("device_type_id", morse_audio_device_type_id_get());
    gnome_config_set_int ("sample_frequency", morse_audio_sample_rate_get());
    audio_device_name_get(morse_audio_rec_dev_get(), &tmp);
    gnome_config_set_string ("device", tmp);
    gnome_config_pop_prefix ();

    gnome_config_push_prefix ("/morse2txt/Filter/");
    gnome_config_set_int ("filter_bandwidth", morse_get_filter_bandwidth());
    gnome_config_set_int ("filter_taps", morse_get_filter_taps());
    gnome_config_pop_prefix ();
    
    gnome_config_sync ();
}

