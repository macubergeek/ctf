#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>

#include <bonobo.h>
#include <gnome.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"

#include "interface_il.h"

#define STATUS_BAR_MESSAGE_LENGTH	25
#define NUMBER_OF_STATUS_BARS		03

#define GLADE_HOOKUP_OBJECT(component,widget,name) \
  g_object_set_data_full (G_OBJECT (component), name, \
    gtk_widget_ref (widget), (GDestroyNotify) gtk_widget_unref)

#define GLADE_HOOKUP_OBJECT_NO_REF(component,widget,name) \
  g_object_set_data (G_OBJECT (component), name, widget)

static void on_about1_activate(GtkMenuItem *menuitem, gpointer user_data);

static GnomeUIInfo file1_menu_uiinfo[] =
{
  {
    GNOME_APP_UI_ITEM, N_("E_xit"),
    NULL,
    (gpointer) on_exit1_activate, NULL, NULL,
    GNOME_APP_PIXMAP_STOCK, "gtk-quit",
    0, (GdkModifierType) 0, NULL
  },
  GNOMEUIINFO_END
};

static GnomeUIInfo view_menu_uiinfo[] =
{
  {
    GNOME_APP_UI_TOGGLEITEM, N_("Morse _Statistics"),
    NULL,
    (gpointer) on_statistics_activate, NULL, NULL,
    GNOME_APP_PIXMAP_NONE, NULL,
    0, (GdkModifierType) 0, NULL
  },
  GNOMEUIINFO_END
};

static GnomeUIInfo icons_only_uiinfo[] =
{
  {
    GNOME_APP_UI_ITEM, N_("_Icons Only"),
    NULL,
    (gpointer) on_icons_and_or_text_activate, (gpointer)"a", NULL,
    GNOME_APP_PIXMAP_NONE, NULL,
    0, (GdkModifierType) 0, NULL
  },
  {
    GNOME_APP_UI_ITEM, N_("_Text Only"),
    NULL,
    (gpointer) on_icons_and_or_text_activate, (gpointer)"b", NULL,
    GNOME_APP_PIXMAP_NONE, NULL,
    0, (GdkModifierType) 0, NULL
  },
  {
    GNOME_APP_UI_ITEM, N_("I_cons & Text"),
    NULL,
    (gpointer) on_icons_and_or_text_activate, (gpointer)"c", NULL,
    GNOME_APP_PIXMAP_NONE, NULL,
    0, (GdkModifierType) 0, NULL
  },
  GNOMEUIINFO_END
};

static GnomeUIInfo toolbar_menu_uiinfo[] =
{
  {
    GNOME_APP_UI_RADIOITEMS, NULL, NULL, icons_only_uiinfo,
    NULL, NULL, GNOME_APP_PIXMAP_NONE, NULL, 0,
    (GdkModifierType) 0, NULL
  },
  GNOMEUIINFO_END
};

static GnomeUIInfo settings_menu_uiinfo[] =
{
  {
    GNOME_APP_UI_ITEM, N_("_Preferences"),
    NULL,
    (gpointer) on_preferences_activate, NULL, NULL,
    GNOME_APP_PIXMAP_STOCK, "gtk-preferences",
    0, (GdkModifierType) 0, NULL
  },
  GNOMEUIINFO_SEPARATOR,
  {
    GNOME_APP_UI_SUBTREE, N_("_Toolbar"),
    NULL,
    toolbar_menu_uiinfo, NULL, NULL,
    GNOME_APP_PIXMAP_NONE, NULL,
    0, (GdkModifierType) 0, NULL
  },
  GNOMEUIINFO_END
};

static GnomeUIInfo bw25_hz_uiinfo[] =
{
  {
    GNOME_APP_UI_ITEM, N_("25 Hz"),
    NULL,
    (gpointer) on_filter_bw_activate, (gpointer)"a", NULL,
    GNOME_APP_PIXMAP_NONE, NULL,
    0, (GdkModifierType) 0, NULL
  },
  {
    GNOME_APP_UI_ITEM, N_("50 Hz"),
    NULL,
    (gpointer) on_filter_bw_activate, (gpointer)"b", NULL,
    GNOME_APP_PIXMAP_NONE, NULL,
    0, (GdkModifierType) 0, NULL
  },
  {
    GNOME_APP_UI_ITEM, N_("100 Hz"),
    NULL,
    (gpointer) on_filter_bw_activate, (gpointer)"c", NULL,
    GNOME_APP_PIXMAP_NONE, NULL,
    0, (GdkModifierType) 0, NULL
  },
  {
    GNOME_APP_UI_ITEM, N_("150 Hz"),
    NULL,
    (gpointer) on_filter_bw_activate, (gpointer)"d", NULL,
    GNOME_APP_PIXMAP_NONE, NULL,
    0, (GdkModifierType) 0, NULL
  },
  {
    GNOME_APP_UI_ITEM, N_("200 Hz"),
    NULL,
    (gpointer) on_filter_bw_activate, (gpointer)"e", NULL,
    GNOME_APP_PIXMAP_NONE, NULL,
    0, (GdkModifierType) 0, NULL
  },
  {
    GNOME_APP_UI_ITEM, N_("250 Hz"),
    NULL,
    (gpointer) on_filter_bw_activate, (gpointer)"f", NULL,
    GNOME_APP_PIXMAP_NONE, NULL,
    0, (GdkModifierType) 0, NULL
  },
  {
    GNOME_APP_UI_ITEM, N_("500 Hz"),
    NULL,
    (gpointer) on_filter_bw_activate, (gpointer)"g", NULL,
    GNOME_APP_PIXMAP_NONE, NULL,
    0, (GdkModifierType) 0, NULL
  },
  {
    GNOME_APP_UI_ITEM, N_("1000 Hz"),
    NULL,
    (gpointer) on_filter_bw_activate, (gpointer)"h", NULL,
    GNOME_APP_PIXMAP_NONE, NULL,
    0, (GdkModifierType) 0, NULL
  },
  GNOMEUIINFO_END
};

static GnomeUIInfo fir_bw_menu_uiinfo[] =
{
  {
    GNOME_APP_UI_RADIOITEMS, NULL, NULL, bw25_hz_uiinfo,
    NULL, NULL, GNOME_APP_PIXMAP_NONE, NULL, 0,
    (GdkModifierType) 0, NULL
  },
  GNOMEUIINFO_END
};

static GnomeUIInfo help1_menu_uiinfo[] =
{
  {
    GNOME_APP_UI_ITEM, N_("_About"),
    NULL,
    (gpointer) on_about1_activate, NULL, NULL,
    GNOME_APP_PIXMAP_STOCK, "gnome-stock-about",
    0, (GdkModifierType) 0, NULL
  },
  GNOMEUIINFO_END
};

static GnomeUIInfo menubar1_uiinfo[] =
{
  {
    GNOME_APP_UI_SUBTREE, N_("_File"),
    NULL,
    file1_menu_uiinfo, NULL, NULL,
    GNOME_APP_PIXMAP_NONE, NULL,
    0, (GdkModifierType) 0, NULL
  },
  GNOMEUIINFO_MENU_VIEW_TREE (view_menu_uiinfo),
  {
    GNOME_APP_UI_SUBTREE, N_("_Settings"),
    N_("Morse and Audio Settings"),
    settings_menu_uiinfo, NULL, NULL,
    GNOME_APP_PIXMAP_NONE, NULL,
    0, (GdkModifierType) 0, NULL
  },
  GNOMEUIINFO_SEPARATOR,
  {
    GNOME_APP_UI_SUBTREE, N_("Filter BW"),
    N_("Front End Filter Bandwidth"),
    fir_bw_menu_uiinfo, NULL, NULL,
    GNOME_APP_PIXMAP_NONE, NULL,
    0, (GdkModifierType) 0, NULL
  },
  GNOMEUIINFO_SEPARATOR,
  {
    GNOME_APP_UI_SUBTREE, N_("_Help"),
    NULL,
    help1_menu_uiinfo, NULL, NULL,
    GNOME_APP_PIXMAP_NONE, NULL,
    0, (GdkModifierType) 0, NULL
  },
  GNOMEUIINFO_END
};

GtkWidget*
create_MainWindow (void)
{
  GtkWidget *MainWindow;
  GtkWidget *vbox1;
  GtkWidget *menubar1;
  GtkWidget *toolbar1;
  GtkIconSize tmp_toolbar_icon_size;
  GtkWidget *tmp_image;
  GtkWidget *startbutton;
  GtkWidget *stop_button;
  GtkWidget *separatortoolitem1;
  GtkWidget *clear_txt_button;
  GtkWidget *scope_fft_button;
  GtkWidget *agc_apply_btn;
  GtkWidget *enable_fir_button;
  GtkWidget *separatortoolitem2;
  GtkWidget *exit_button;
  GtkWidget *vpaned1;
  GtkWidget *scrolledwindow1;
  GtkWidget *decoded_text;
  GtkWidget *scope;
  GtkWidget *hscale1;
  GtkWidget *label1;
  GtkWidget *hbox1;
  GtkWidget *samples_statusbar;
  GtkWidget *ffts_statusbar;
  GtkWidget *wpm_statusbar;
  GtkAccelGroup *accel_group;
  GtkTooltips *tooltips;

  /* modify */  
  GtkObject *adjustment;
  
  tooltips = gtk_tooltips_new ();

  accel_group = gtk_accel_group_new ();

  MainWindow = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (MainWindow), _("morse2txt"));
  /* modify */  
  gtk_window_set_default_size (GTK_WINDOW (MainWindow), main_gui.width, main_gui.height);

  vbox1 = gtk_vbox_new (FALSE, 0);
  gtk_widget_show (vbox1);
  gtk_container_add (GTK_CONTAINER (MainWindow), vbox1);

  menubar1 = gtk_menu_bar_new ();
  gtk_widget_show (menubar1);
  gtk_box_pack_start (GTK_BOX (vbox1), menubar1, FALSE, FALSE, 0);
  gnome_app_fill_menu (GTK_MENU_SHELL (menubar1), menubar1_uiinfo,
                       NULL, FALSE, 0);

  /** \todo Get rid of magic number. */
  if(main_gui.toolbar_style < 3) {
    gtk_check_menu_item_set_active (GTK_CHECK_MENU_ITEM (icons_only_uiinfo[main_gui.toolbar_style].widget), TRUE);
  }      

  toolbar1 = gtk_toolbar_new ();
  gtk_widget_show (toolbar1);
  gtk_box_pack_start (GTK_BOX (vbox1), toolbar1, FALSE, FALSE, 0);
  /* modify */  
  gtk_toolbar_set_style (GTK_TOOLBAR (toolbar1), main_gui.toolbar_style);
  tmp_toolbar_icon_size = gtk_toolbar_get_icon_size (GTK_TOOLBAR (toolbar1));

  tmp_image = gtk_image_new_from_stock ("gtk-execute", tmp_toolbar_icon_size);
  gtk_widget_show (tmp_image);
  startbutton = (GtkWidget*) gtk_tool_button_new (tmp_image, _("Start"));
  gtk_widget_show (startbutton);
  gtk_container_add (GTK_CONTAINER (toolbar1), startbutton);
  gtk_tool_item_set_tooltip (GTK_TOOL_ITEM (startbutton), tooltips, _("Start Decoding"), NULL);

  tmp_image = gtk_image_new_from_stock ("gnome-stock-not", tmp_toolbar_icon_size);
  gtk_widget_show (tmp_image);
  stop_button = (GtkWidget*) gtk_tool_button_new (tmp_image, _("Stop"));
  gtk_widget_show (stop_button);
  gtk_container_add (GTK_CONTAINER (toolbar1), stop_button);
  gtk_tool_item_set_tooltip (GTK_TOOL_ITEM (stop_button), tooltips, _("Stop Decoding"), NULL);

  separatortoolitem1 = (GtkWidget*) gtk_separator_tool_item_new ();
  gtk_widget_show (separatortoolitem1);
  gtk_container_add (GTK_CONTAINER (toolbar1), separatortoolitem1);

  tmp_image = gtk_image_new_from_stock ("gtk-clear", tmp_toolbar_icon_size);
  gtk_widget_show (tmp_image);
  clear_txt_button = (GtkWidget*) gtk_tool_button_new (tmp_image, _("Clear Text"));
  gtk_widget_show (clear_txt_button);
  gtk_container_add (GTK_CONTAINER (toolbar1), clear_txt_button);
  gtk_tool_item_set_tooltip (GTK_TOOL_ITEM (clear_txt_button), tooltips, _("Erase All Text"), NULL);

  tmp_image = gtk_image_new_from_stock ("gtk-convert", tmp_toolbar_icon_size);
  gtk_widget_show (tmp_image);
  scope_fft_button = (GtkWidget*) gtk_tool_button_new (tmp_image, _("Scope/FFT"));
  gtk_widget_show (scope_fft_button);
  gtk_container_add (GTK_CONTAINER (toolbar1), scope_fft_button);
  gtk_tool_item_set_tooltip (GTK_TOOL_ITEM (scope_fft_button), tooltips, _("FFT or Audio Display"), NULL);

  agc_apply_btn = (GtkWidget*) gtk_toggle_tool_button_new ();
  gtk_tool_button_set_label (GTK_TOOL_BUTTON (agc_apply_btn), _("AGC"));
  tmp_image = gtk_image_new_from_stock ("gtk-apply", tmp_toolbar_icon_size);
  gtk_widget_show (tmp_image);
  gtk_tool_button_set_icon_widget (GTK_TOOL_BUTTON (agc_apply_btn), tmp_image);
  gtk_widget_show (agc_apply_btn);
  gtk_container_add (GTK_CONTAINER (toolbar1), agc_apply_btn);
  gtk_tool_item_set_tooltip (GTK_TOOL_ITEM (agc_apply_btn), tooltips, _("Automatic Gain Control"), NULL);

  enable_fir_button = (GtkWidget*) gtk_toggle_tool_button_new ();
  gtk_tool_button_set_label (GTK_TOOL_BUTTON (enable_fir_button), _("Filter"));
  tmp_image = gtk_image_new_from_stock ("gtk-apply", tmp_toolbar_icon_size);
  gtk_widget_show (tmp_image);
  gtk_tool_button_set_icon_widget (GTK_TOOL_BUTTON (enable_fir_button), tmp_image);
  gtk_widget_show (enable_fir_button);
  gtk_container_add (GTK_CONTAINER (toolbar1), enable_fir_button);
  gtk_tool_item_set_tooltip (GTK_TOOL_ITEM (enable_fir_button), tooltips, _("Frontend FIR Filter"), NULL);

  separatortoolitem2 = (GtkWidget*) gtk_separator_tool_item_new ();
  gtk_widget_show (separatortoolitem2);
  gtk_container_add (GTK_CONTAINER (toolbar1), separatortoolitem2);

  tmp_image = gtk_image_new_from_stock ("gtk-quit", tmp_toolbar_icon_size);
  gtk_widget_show (tmp_image);
  exit_button = (GtkWidget*) gtk_tool_button_new (tmp_image, _("Exit"));
  gtk_widget_show (exit_button);
  gtk_container_add (GTK_CONTAINER (toolbar1), exit_button);
  gtk_tool_item_set_tooltip (GTK_TOOL_ITEM (exit_button), tooltips, _("Exit Application"), NULL);

  vpaned1 = gtk_vpaned_new ();
  gtk_widget_show (vpaned1);
  gtk_box_pack_start (GTK_BOX (vbox1), vpaned1, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (vpaned1), 10);
  GTK_WIDGET_UNSET_FLAGS (vpaned1, GTK_CAN_FOCUS);
  /* modify */  
  gtk_paned_set_position (GTK_PANED (vpaned1), main_gui.pane_position);

  scrolledwindow1 = gtk_scrolled_window_new (NULL, NULL);
  gtk_widget_show (scrolledwindow1);
  gtk_paned_pack1 (GTK_PANED (vpaned1), scrolledwindow1, FALSE, TRUE);
  GTK_WIDGET_UNSET_FLAGS (scrolledwindow1, GTK_CAN_FOCUS);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolledwindow1), GTK_POLICY_NEVER, GTK_POLICY_ALWAYS);
  gtk_scrolled_window_set_shadow_type (GTK_SCROLLED_WINDOW (scrolledwindow1), GTK_SHADOW_IN);

  decoded_text = gtk_text_view_new ();
  gtk_widget_show (decoded_text);
  gtk_container_add (GTK_CONTAINER (scrolledwindow1), decoded_text);
  gtk_tooltips_set_tip (tooltips, decoded_text, _("Decoded Morse"), NULL);
  gtk_text_view_set_editable (GTK_TEXT_VIEW (decoded_text), FALSE);
  gtk_text_view_set_wrap_mode (GTK_TEXT_VIEW (decoded_text), GTK_WRAP_CHAR);

  scope = gtk_curve_new ();
  gtk_widget_show (scope);
  gtk_paned_pack2 (GTK_PANED (vpaned1), scope, FALSE, TRUE);
  /* modify */  
  gtk_curve_set_range (GTK_CURVE (scope), 0, get_fft_data_size(), 0, get_fft_graph_top());

  /* not generated by Glade */  
  adjustment = gtk_adjustment_new(0, 0, (get_fft_data_size() - 1), 1, 0, 0);
  hscale1 = gtk_hscale_new (GTK_ADJUSTMENT (adjustment));
  gtk_widget_show (hscale1);
  gtk_box_pack_start (GTK_BOX (vbox1), hscale1, FALSE, TRUE, 0);
  GTK_WIDGET_UNSET_FLAGS (hscale1, GTK_CAN_FOCUS);
  gtk_scale_set_digits (GTK_SCALE (hscale1), 0);

  label1 = gtk_label_new (_("Frequency to Decode"));
  gtk_widget_show (label1);
  gtk_box_pack_start (GTK_BOX (vbox1), label1, FALSE, TRUE, 0);
  gtk_label_set_justify (GTK_LABEL (label1), GTK_JUSTIFY_CENTER);

  hbox1 = gtk_hbox_new (FALSE, 0);
  gtk_widget_show (hbox1);
  gtk_box_pack_start (GTK_BOX (vbox1), hbox1, FALSE, FALSE, 0);

  samples_statusbar = gtk_statusbar_new ();
  gtk_widget_show (samples_statusbar);
  gtk_box_pack_start (GTK_BOX (hbox1), samples_statusbar, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (samples_statusbar), 2);
  gtk_statusbar_set_has_resize_grip (GTK_STATUSBAR (samples_statusbar), FALSE);

  ffts_statusbar = gtk_statusbar_new ();
  gtk_widget_show (ffts_statusbar);
  gtk_box_pack_start (GTK_BOX (hbox1), ffts_statusbar, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (ffts_statusbar), 2);
  gtk_statusbar_set_has_resize_grip (GTK_STATUSBAR (ffts_statusbar), FALSE);

  wpm_statusbar = gtk_statusbar_new ();
  gtk_widget_show (wpm_statusbar);
  gtk_box_pack_start (GTK_BOX (hbox1), wpm_statusbar, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (wpm_statusbar), 2);
  gtk_statusbar_set_has_resize_grip (GTK_STATUSBAR (wpm_statusbar), FALSE);

  g_signal_connect ((gpointer) MainWindow, "delete_event",
                    G_CALLBACK (on_MainWindow_delete_event),
                    NULL);
  g_signal_connect ((gpointer) startbutton, "clicked",
                    G_CALLBACK (on_startbutton_clicked),
                    NULL);
  g_signal_connect ((gpointer) stop_button, "clicked",
                    G_CALLBACK (on_stop_button_clicked),
                    NULL);
  g_signal_connect ((gpointer) clear_txt_button, "clicked",
                    G_CALLBACK (on_clear_txt_button_clicked),
                    NULL);
  g_signal_connect ((gpointer) scope_fft_button, "clicked",
                    G_CALLBACK (on_scope_fft_button_clicked),
                    NULL);
  g_signal_connect ((gpointer) agc_apply_btn, "toggled",
                    G_CALLBACK (on_agc_apply_btn_toggled),
                    NULL);
  g_signal_connect ((gpointer) enable_fir_button, "toggled",
                    G_CALLBACK (on_enable_fir_button_toggled),
                    NULL);
  g_signal_connect ((gpointer) exit_button, "clicked",
                    G_CALLBACK (on_exit_button_clicked),
                    NULL);
  g_signal_connect ((gpointer) adjustment, "value_changed",
                    G_CALLBACK (on_adjustment_release_event),
                    NULL);

  /* Store pointers to all widgets, for use by lookup_widget(). */
  GLADE_HOOKUP_OBJECT_NO_REF (MainWindow, MainWindow, "MainWindow");
  GLADE_HOOKUP_OBJECT (MainWindow, vbox1, "vbox1");
  GLADE_HOOKUP_OBJECT (MainWindow, menubar1, "menubar1");
  GLADE_HOOKUP_OBJECT (MainWindow, menubar1_uiinfo[0].widget, "file1");
  GLADE_HOOKUP_OBJECT (MainWindow, file1_menu_uiinfo[0].widget, "exit1");
  GLADE_HOOKUP_OBJECT (MainWindow, menubar1_uiinfo[1].widget, "view");
  GLADE_HOOKUP_OBJECT (MainWindow, view_menu_uiinfo[0].widget, "statistics");
  GLADE_HOOKUP_OBJECT (MainWindow, menubar1_uiinfo[2].widget, "settings");
  GLADE_HOOKUP_OBJECT (MainWindow, settings_menu_uiinfo[0].widget, "preferences");
  GLADE_HOOKUP_OBJECT (MainWindow, settings_menu_uiinfo[1].widget, "separator1");
  GLADE_HOOKUP_OBJECT (MainWindow, settings_menu_uiinfo[2].widget, "toolbar");
  GLADE_HOOKUP_OBJECT (MainWindow, icons_only_uiinfo[0].widget, "icons_only");
  GLADE_HOOKUP_OBJECT (MainWindow, icons_only_uiinfo[1].widget, "text_only");
  GLADE_HOOKUP_OBJECT (MainWindow, icons_only_uiinfo[2].widget, "icons_and_text");
  GLADE_HOOKUP_OBJECT (MainWindow, menubar1_uiinfo[3].widget, "separator2");
  GLADE_HOOKUP_OBJECT (MainWindow, menubar1_uiinfo[4].widget, "fir_bw");
  GLADE_HOOKUP_OBJECT (MainWindow, bw25_hz_uiinfo[0].widget, "bw25_hz");
  GLADE_HOOKUP_OBJECT (MainWindow, bw25_hz_uiinfo[1].widget, "bw50_hz");
  GLADE_HOOKUP_OBJECT (MainWindow, bw25_hz_uiinfo[2].widget, "bw100_hz");
  GLADE_HOOKUP_OBJECT (MainWindow, bw25_hz_uiinfo[3].widget, "bw150_hz");
  GLADE_HOOKUP_OBJECT (MainWindow, bw25_hz_uiinfo[4].widget, "bw200_hz");
  GLADE_HOOKUP_OBJECT (MainWindow, bw25_hz_uiinfo[5].widget, "bw250_hz");
  GLADE_HOOKUP_OBJECT (MainWindow, bw25_hz_uiinfo[6].widget, "bw500_hz");
  GLADE_HOOKUP_OBJECT (MainWindow, bw25_hz_uiinfo[7].widget, "bw1000_hz");
  GLADE_HOOKUP_OBJECT (MainWindow, menubar1_uiinfo[5].widget, "separator3");
  GLADE_HOOKUP_OBJECT (MainWindow, menubar1_uiinfo[6].widget, "help1");
  GLADE_HOOKUP_OBJECT (MainWindow, help1_menu_uiinfo[0].widget, "about1");
  GLADE_HOOKUP_OBJECT (MainWindow, toolbar1, "toolbar1");
  GLADE_HOOKUP_OBJECT (MainWindow, startbutton, "startbutton");
  GLADE_HOOKUP_OBJECT (MainWindow, stop_button, "stop_button");
  GLADE_HOOKUP_OBJECT (MainWindow, separatortoolitem1, "separatortoolitem1");
  GLADE_HOOKUP_OBJECT (MainWindow, clear_txt_button, "clear_txt_button");
  GLADE_HOOKUP_OBJECT (MainWindow, scope_fft_button, "scope_fft_button");
  GLADE_HOOKUP_OBJECT (MainWindow, agc_apply_btn, "agc_apply_btn");
  GLADE_HOOKUP_OBJECT (MainWindow, enable_fir_button, "enable_fir_button");
  GLADE_HOOKUP_OBJECT (MainWindow, separatortoolitem2, "separatortoolitem2");
  GLADE_HOOKUP_OBJECT (MainWindow, exit_button, "exit_button");
  GLADE_HOOKUP_OBJECT (MainWindow, vpaned1, "vpaned1");
  GLADE_HOOKUP_OBJECT (MainWindow, scrolledwindow1, "scrolledwindow1");
  GLADE_HOOKUP_OBJECT (MainWindow, decoded_text, "decoded_text");
  GLADE_HOOKUP_OBJECT (MainWindow, scope, "scope");
  GLADE_HOOKUP_OBJECT (MainWindow, hscale1, "hscale1");
  GLADE_HOOKUP_OBJECT (MainWindow, label1, "label1");
  GLADE_HOOKUP_OBJECT (MainWindow, hbox1, "hbox1");
  GLADE_HOOKUP_OBJECT (MainWindow, samples_statusbar, "samples_statusbar");
  GLADE_HOOKUP_OBJECT (MainWindow, ffts_statusbar, "ffts_statusbar");
  GLADE_HOOKUP_OBJECT (MainWindow, wpm_statusbar, "wpm_statusbar");
  GLADE_HOOKUP_OBJECT_NO_REF (MainWindow, tooltips, "tooltips");

  gtk_window_add_accel_group (GTK_WINDOW (MainWindow), accel_group);

/* not generated by Glade */  
  main_gui.decoded_text_v = decoded_text;
  main_gui.samples_statusbar_v = samples_statusbar;
  main_gui.ffts_statusbar_v = ffts_statusbar;
  main_gui.wpm_statusbar_v = wpm_statusbar;
  main_gui.scope_v = scope;
  main_gui.hscale1_v = hscale1;
  main_gui.adjustment_frequency_v = adjustment;
  main_gui.label1_v = label1;
  main_gui.toolbar1_v = toolbar1;
  main_gui.main_window_v = MainWindow;

  return MainWindow;
}

GtkWidget*
create_morse_about (void)
{
  const gchar *authors[] = {"Ken Prox, ka8cln <kprox@users.sourceforge.net>", NULL };
  const gchar *documenters[] = { NULL };
  /* TRANSLATORS: Replace this string with your names, one name per line. */
  gchar *translators = {_("Fabian Affolter <fab@fedoraproject.org>, 2009.")};
  GtkWidget *morse_about;

  if (!strcmp (translators, "translator_credits"))
    translators = NULL;
  morse_about = gnome_about_new (PACKAGE, VERSION,
                        "",
                        "",
                        authors,
                        documenters,
                        translators,
                        NULL);
  gtk_container_set_border_width (GTK_CONTAINER (morse_about), 5);
  gtk_window_set_type_hint (GTK_WINDOW (morse_about), GDK_WINDOW_TYPE_HINT_DIALOG);

  /* Store pointers to all widgets, for use by lookup_widget(). */
  GLADE_HOOKUP_OBJECT_NO_REF (morse_about, morse_about, "morse_about");

  return morse_about;
}

static void
on_about1_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
    static GtkWidget* about = NULL;

    if (about) {
        if (about->window == NULL)
            return;
        
        gdk_window_show (about->window);
        gdk_window_raise (about->window);
        return;
    }
    
    about = create_morse_about ();

    gtk_signal_connect (GTK_OBJECT (about),
                "destroy",
                GTK_SIGNAL_FUNC (gtk_widget_destroyed),
                &about);

    gtk_widget_show (about);
}

