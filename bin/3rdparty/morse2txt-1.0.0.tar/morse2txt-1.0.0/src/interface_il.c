/*
 * $Id: interface_il.c,v 1.20 2009/05/30 00:45:51 kprox Exp $
 * interface_il.c
 *
 * Copyright (C) 2004, 2006:
 * Ken Prox <kprox@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 *
 *
 */
#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>

#include <gdk/gdkkeysyms.h>
#include <gnome.h>

#include <malloc.h>
#include <stdlib.h>
#include <gdk/gdk.h>
#include <glib.h>

#include "morse.h"
#include "audio.h"
#include "interface_il.h"
#include "support.h"

#define STATUS_BAR_MESSAGE_LENGTH   25
#define NUMBER_OF_STATUS_BARS       03
#define MAX_SPACES_TO_APPEND        30

/** Maximum number of plots for debug plotting. */
#define NUM_PLOTS   3

/** Prefix for bandwidth radio items in main GUI. */
#define BW_WIDGET_NAME_PREFIX   "bw"
/** Suffix for bandwidth radio items in main GUI. */
#define BW_WIDGET_NAME_SUFFIX   "_hz"

/** Max size of temporay text buffer.
 *  \sa name_buffer
 */
#define BW_WIDGET_NAME_LENGTH   16
/** Temporary buffer for text manipulations. */
static char name_buffer[BW_WIDGET_NAME_LENGTH];

/** Morse statistics display. */
GtkWidget* morse_stats = NULL;

/** Temporary array for GtkCurve data. */
static gfloat *y = NULL;

static char buffer[NUMBER_OF_STATUS_BARS][STATUS_BAR_MESSAGE_LENGTH];
G_LOCK_DEFINE(y);
G_LOCK_DEFINE(buffer);

static void update_status_bar(uint32_t ffts, uint32_t samples, double wpm);
static void update_statistics_window(const morse_stats_ts* stats_t);
static void gui_append_character_2_morse_text(char *character);
static void scope_fft_plot(double *vector, uint32_t num_points);
static void dialog_box(char *message);

#if DEBUG_GRAPH_INTERFACE == 1
   /** Program for plotting Morse internals while debugging. */
   #define DEBUG_PLOT_PRG "graph -T X -x 0 20"
   static void debug_plot(const int8_t *plot, int32_t y);
   static void open_plot_debug_pipe(void);
#else /* DEBUG_GRAPH_INTERFACE */
   #define open_plot_debug_pipe(void)
#endif /* DEBUG_GRAPH_INTERFACE */


/********************************************************************************/

//! Thread safe method that appends text to the decoded text widget.
/*! \sa decoded_text_v
    \param character pointer to one or more ascii characters
*/
static void gui_append_character_2_morse_text(char *character)
{
    GtkTextMark *mark = NULL;
    GtkTextIter iter_start, iter_end;
    
    gdk_threads_enter();
    gtk_text_buffer_insert_at_cursor(GTK_TEXT_VIEW(main_gui.decoded_text_v)->buffer, character, 1);
    /* begin autoscroll */  
    gtk_text_buffer_get_bounds(GTK_TEXT_VIEW(main_gui.decoded_text_v)->buffer, &iter_start, &iter_end);
    mark = gtk_text_buffer_create_mark(GTK_TEXT_VIEW(main_gui.decoded_text_v)->buffer, NULL, &iter_end, FALSE);
    gtk_text_view_scroll_mark_onscreen(GTK_TEXT_VIEW(main_gui.decoded_text_v), mark);
    gtk_text_buffer_delete_mark(GTK_TEXT_VIEW(main_gui.decoded_text_v)->buffer, mark);
    /* end autoscroll */  
    gdk_flush();
    gdk_threads_leave();
}


int32_t plot_fft_data_array_create(uint32_t num_points)
{
    if((y = malloc(num_points * sizeof(gfloat))) == NULL) {
        fprintf (stderr, "Unable to allocate fft plot buffer\n");
        return -1;
    }
    gtk_curve_set_vector(GTK_CURVE(main_gui.scope_v), num_points, y);
    gtk_curve_set_curve_type(GTK_CURVE(main_gui.scope_v), GTK_CURVE_TYPE_FREE);
    return 0;
}

void plot_fft_data_array_destroy(void)
{
    free(y);
    y = NULL;
}

/** This is called when the Statistics window is destroyed.
 */
void statistics_window_deleted_handler(void)
{
    GtkWidget *widget;

    widget = lookup_widget(main_gui.main_window_v, "statistics");
    gtk_check_menu_item_set_active(GTK_CHECK_MENU_ITEM(widget), FALSE);
    morse_stats = NULL;
}

//! Thread safe method that displays waveform on scope_v widget.
/*! \sa scope_v
    \param vector pointer to array of waveform to be plotted
    \param num_points size of array
*/
static void scope_fft_plot(double *vector, uint32_t num_points)
{
    uint32_t i;
    
    G_LOCK(y);

    for(i = 0; i < num_points; i++) {
        y[i] = (gfloat)vector[i];
    }

    gdk_threads_enter();
    gtk_curve_set_vector(GTK_CURVE(main_gui.scope_v), (int32_t)num_points, y);
    gdk_flush();
    gdk_threads_leave();
    G_UNLOCK(y);
}

//! Thread safe method that updates the status bar.
/*! \param ffts number of fft packets processed
    \param samples number of audio samples processed
    \param wpm code speed in Words per Minute
*/
static void update_status_bar(uint32_t ffts, uint32_t samples, double wpm)
{
    G_LOCK(buffer);

    g_snprintf(&buffer[0][0], STATUS_BAR_MESSAGE_LENGTH, "Samples: %d", samples);
    g_snprintf(&buffer[1][0], STATUS_BAR_MESSAGE_LENGTH, "FFT's: %d", ffts);
    g_snprintf(&buffer[2][0], STATUS_BAR_MESSAGE_LENGTH, "WPM: %2.1f", wpm);

    gdk_threads_enter();
    gtk_statusbar_push(GTK_STATUSBAR(main_gui.samples_statusbar_v), 1, &buffer[0][0]);
    gtk_statusbar_push(GTK_STATUSBAR(main_gui.ffts_statusbar_v), 1, &buffer[1][0]);
    gtk_statusbar_push(GTK_STATUSBAR(main_gui.wpm_statusbar_v), 1, &buffer[2][0]);
    gdk_flush();
    gdk_threads_leave();
    G_UNLOCK(buffer);
}

/** Thread safe method that updates the status bar.
 *  @param stats_t Various Morse Statistics
 */
static void update_statistics_window(const morse_stats_ts* stats_t)
{
    GtkWidget *widget;

    gdk_threads_enter();

    if(NULL != morse_stats)
    {
        widget = lookup_widget(morse_stats, "avg_dah_length_entry");
        snprintf(name_buffer, BW_WIDGET_NAME_LENGTH, "%6.3f", stats_t->avg_dah_dur);
        gtk_entry_set_text(GTK_ENTRY(widget), name_buffer);
    
        widget = lookup_widget(morse_stats, "avg_dit_length_entry");
        snprintf(name_buffer, BW_WIDGET_NAME_LENGTH, "%6.3f", stats_t->avg_dit_dur);
        gtk_entry_set_text(GTK_ENTRY(widget), name_buffer);

        widget = lookup_widget(morse_stats, "dah_dit_ratio_entry");
        snprintf(name_buffer, BW_WIDGET_NAME_LENGTH, "%6.3f", stats_t->dah_dit_ratio);
        gtk_entry_set_text(GTK_ENTRY(widget), name_buffer);

        widget = lookup_widget(morse_stats, "words_per_minute_entry");
        snprintf(name_buffer, BW_WIDGET_NAME_LENGTH, "%3.0f", stats_t->wpm);
        gtk_entry_set_text(GTK_ENTRY(widget), name_buffer);
    }

    gdk_flush();
    gdk_threads_leave();
}

//! Wrapper function for whatever GUI message box is implemented.
static void dialog_box(char *message)
{
    GtkWidget*  msg_box;
    
    msg_box = gtk_message_dialog_new(main_gui.main_window_v, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO, GTK_BUTTONS_OK, message); 
    gtk_dialog_run (GTK_DIALOG (msg_box));
    gtk_widget_destroy (msg_box);
}

void init_gui_interface_hooks(void)
{
    set_update_status_hndlr(&update_status_bar);
    set_display_character_hndlr(&gui_append_character_2_morse_text);
    set_scope_plot_hndlr(&scope_fft_plot);
    register_error_message_handler(&dialog_box);
    set_Morse_statistics_display_hndlr(&update_statistics_window);
    register_debug_plot(&debug_plot);
    open_plot_debug_pipe();
}

uint32_t get_fft_data_size(void) { return morse_get_fft_data_size(); }
int32_t get_fft_graph_top(void) { return morse_get_fft_graph_top(); }
uint32_t get_tone_packet_size(void) { return morse_get_tone_packet_size(); }

int32_t threads_stop(void)
{
    morse_stop_threads();
    preferences_enabled(TRUE);
    plot_fft_data_array_destroy();
    return 0;
}

void preferences_enabled(gboolean state)
{
    GtkWidget *widget;
    widget = lookup_widget(main_gui.main_window_v, "preferences");
    gtk_widget_set_sensitive(GTK_WIDGET(widget), state);
}

void interface_activate_bw_chk_item(const int32_t bw)
{
    GtkWidget *widget;
    
    /* form widget name. */
    snprintf(name_buffer, BW_WIDGET_NAME_LENGTH, "%s%d%s", BW_WIDGET_NAME_PREFIX, bw, BW_WIDGET_NAME_SUFFIX);
    widget = lookup_widget(main_gui.main_window_v, name_buffer);
    gtk_check_menu_item_set_active (GTK_CHECK_MENU_ITEM(widget), TRUE);
}

/** Debug graph support using DEBUG_PLOT_PRG. */
#if DEBUG_GRAPH_INTERFACE == 1

/* This could cause a instance of xpipe where ever this file is included. */
static FILE *xpipe = NULL;

static void open_plot_debug_pipe(void)
{
    if(NULL == (xpipe = popen(DEBUG_PLOT_PRG, "w"))) {
        fprintf(stderr, "Can't find %s.", DEBUG_PLOT_PRG);
    }
}

static void debug_plot(const int8_t *plot, int32_t y)
{
    static int32_t x[NUM_PLOTS];
    int32_t tmp;
        
    tmp = atoi(plot);
    if( (NULL != xpipe) && (NUM_PLOTS > tmp) ) {
        gdk_threads_enter();
        fprintf(xpipe, "%s %i %i\n", plot, x[tmp]++, y);
        fflush(xpipe);
        gdk_threads_leave();
    }
}
#endif
