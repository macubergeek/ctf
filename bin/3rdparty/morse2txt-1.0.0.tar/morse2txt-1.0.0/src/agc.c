/*
 * $Id: agc.c,v 1.11 2009/05/30 00:45:51 kprox Exp $
 *
 * Copyright (C) 2002, 2005:
 * Ken Prox <kprox@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 *
 * --- This object is an automatic gain control. ---
 *
 * Example:
 *
 * agc agc_object;
 * agc_object = agc_create(10.0, 0.02, 123.1, 1000.0, 0.10);
 * new_gain = agc_update(agc_object, amplitude);
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "agc.h"

/** AGC object private members. */
typedef struct s_agc
{
    /*! Maximum AGC gain permitted. */
    double maximum_gain;
    /*! Minimum AGC gain permitted. */
    double minimum_gain;
    /*! If above this threshold, decrease gain. */
    double max_amp;
    /*! Do not adjust gain if current_amplitude is below noise_floor.  Not used for some AGC algorithms.
     *  \sa current_amplitude
     */
    double noise_floor;
    /*! The current AGC gain. */
    double gain;
    te_agc_types agc_type;
    /*! AGC increase gain parameter. */
    double gain_increase_correction_factor;
    /*! AGC decrease gain parameter. */
    double gain_decrease_correction_factor;
} s_agc;

typedef double (* agc_algorithm)(agc gain_object, double current_amplitude);

static double agc_update_1(agc gain_object, double current_amplitude);
static double agc_update_2(agc gain_object, double current_amplitude);
static double agc_update_3(agc gain_object, double current_amplitude);
static double agc_update_4(agc gain_object, double current_amplitude);

static const agc_algorithm AGC_ALGOR_TABLE[AGC_NUMBER_OF_ADJUSTMENT_TYPES] = {
    agc_update_1, /* AGC_LINEAR_PEAK_LIMIT */
    agc_update_2, /* AGC_PERCENTAGE_W_NOISE_FLOOR */
    agc_update_3, /* AGC_PERCENTAGE_PEAK_LIMIT */
    agc_update_4  /* AGC_LINEAR_PEAK_W_COMPUTED_GAIN_ON_CLIP */
};

agc agc_create(double max_gain,
               double min_gain,
               double noise_floor,
               double max_amp,
               te_agc_types agc_type,
               double gain_increase_correct,
               double gain_decrease_correct)
{
    agc gain_object;

    if((gain_object = malloc(sizeof(struct s_agc))) != NULL) {
        gain_object->maximum_gain = max_gain;
        gain_object->minimum_gain = min_gain;
        gain_object->noise_floor = noise_floor;
        
        if(agc_type < AGC_NUMBER_OF_ADJUSTMENT_TYPES) {
            gain_object->agc_type = agc_type;
        }
        else {
            gain_object->agc_type = AGC_LINEAR_PEAK_LIMIT;
        }            
        
        gain_object->gain_increase_correction_factor = gain_increase_correct;
        gain_object->gain_decrease_correction_factor = gain_decrease_correct;
        gain_object->max_amp = max_amp;
        gain_object->gain = 1.0;
    }
    return gain_object;
}

double agc_update(agc gain_object, double current_amplitude)
{
    return AGC_ALGOR_TABLE[gain_object->agc_type](gain_object, current_amplitude);
}

static double agc_update_1(agc gain_object, double current_amplitude)
{
    if(current_amplitude > gain_object->max_amp) {
        gain_object->gain -= gain_object->gain_decrease_correction_factor;
    }
    else {
        if(gain_object->gain < gain_object->maximum_gain) {
            gain_object->gain += gain_object->gain_increase_correction_factor;
        }    
    }
    return gain_object->gain;
}

static double agc_update_2(agc gain_object, double current_amplitude)
{
    double temp;

    if(current_amplitude > gain_object->noise_floor)
    {
        if(current_amplitude < gain_object->max_amp) {
            if(gain_object->gain < gain_object->maximum_gain) {
                temp = (1.0 + gain_object->gain_increase_correction_factor);
                gain_object->gain *= temp;
            }
        }
        else if(current_amplitude >= gain_object->max_amp) {
            if(gain_object->gain > gain_object->minimum_gain) {
                temp = (1.0 - gain_object->gain_decrease_correction_factor);
                gain_object->gain *= temp;
            }
        }
        else { /* no else */ }
    }
    return gain_object->gain;
}

static double agc_update_3(agc gain_object, double current_amplitude)
{
    double temp;

    if(current_amplitude > gain_object->max_amp) {
        temp = (1.0 - gain_object->gain_decrease_correction_factor);
        gain_object->gain *= temp;
    }
    else {
        if(gain_object->gain < gain_object->maximum_gain) {
            temp = (1.0 + gain_object->gain_increase_correction_factor);
            gain_object->gain *= temp;
        }
    }
    return gain_object->gain;
}

static double agc_update_4(agc gain_object, double current_amplitude)
{
    if(
       (current_amplitude > gain_object->max_amp) 
            && \
       (gain_object->gain > 0.0) 
      ) 
    {
        gain_object->gain = gain_object->max_amp / (current_amplitude / gain_object->gain);
    }
    else {
        if(gain_object->gain < gain_object->maximum_gain) {
            gain_object->gain += gain_object->gain_increase_correction_factor;
        }    
    }
    return gain_object->gain;
}

void agc_destroy(agc *gain_object)
{
    free(*gain_object);
    *gain_object = NULL;
}
