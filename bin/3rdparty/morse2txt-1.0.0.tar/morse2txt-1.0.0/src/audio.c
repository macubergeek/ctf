/*
 * Copyright (C) 2005:
 * Ken Prox <kprox@users.sourceforge.net>
 *
 * $Id: audio.c,v 1.41 2009/05/30 00:45:51 kprox Exp $
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#include "audio.h"
#include "audio_oss.h"
#include "audio_alsa.h"

static void error_message(char *msg);
static message_handler msg_handler = NULL;

/** Structure of audio device \sa audio_create */
typedef struct ts_audio_device {
    pthread_cond_t segment_cond_t[AUDIO_BUFFER_SEGMENTS];
    pthread_mutex_t segment_mutex_t[AUDIO_BUFFER_SEGMENTS];
    /** Public settings for the audio device. */
    ts_audio_pub audio_pub;
    /** Functions for talking to device driver layer (abstracts out ALSA/OSS/...). */
    p_audio_api audio_api;
} ts_audio_device;

static const ts_audio_api AUDIO_DEVICE_TABLE[] = {
    /** OSS API for morse2txt. */
    {
        .audio_device_type_name         =   "OSS",
        .open                           =    audio_open_oss,
        .init                           =    audio_init_oss,
        .close                          =    audio_close_oss,
        .play                           =    audio_play_oss,
        .record                         =    audio_record_oss
    },
    /** Alsa API for morse2txt. */
    {
        .audio_device_type_name         =   "Alsa",
        .open                           =    audio_open_alsa,
        .init                           =    audio_init_alsa,
        .close                          =    audio_close_alsa,
        .play                           =    audio_play_alsa,
        .record                         =    audio_record_alsa
    },
    /* Terminator */
    AUDIO_DEVICE_TEMINATOR
};
#define AUDIO_NUMBER_OF_DEVICE_TYPES		( (sizeof(AUDIO_DEVICE_TABLE) / sizeof(AUDIO_DEVICE_TABLE[0])) - 1)

p_audio_device audio_create(uint32_t device_type,
                            te_audio_rec_play rec_play
                           )
{
    p_audio_device tmp = NULL;
    uint32_t i;

    if(NULL != (tmp = malloc(sizeof(ts_audio_device))) ) {
        /*
         * This is where we determine a valid OSS, ALSA, or ..., API.
         */
        if(device_type < AUDIO_NUMBER_OF_DEVICE_TYPES) {
            /* Set the audio api to the appropriate device type. */
            tmp->audio_api = (p_audio_api)&AUDIO_DEVICE_TABLE[device_type];
            /* Setup the callback function for GUI error display. */
            tmp->audio_pub.error_msg_handler = error_message;
            /* Define audio device type, record or play. */
            tmp->audio_pub.play_record = rec_play;
            /* Make sure raw buffer pointer is NULL */
            tmp->audio_pub.audio_buffer_raw = NULL;
            
            for(i = 0; i < AUDIO_BUFFER_SEGMENTS; i++) {
                pthread_cond_init(&tmp->segment_cond_t[i], NULL);
                pthread_mutex_init(&tmp->segment_mutex_t[i], NULL);
            }
        }
        else {
            /* The audio device type was in valid, return NULL. */
            free(tmp);
            tmp = NULL;
        }
    }
    return tmp;
}

int32_t audio_open(p_audio_device device, int32_t sample_frequency)
{
    int32_t tmp;
    
    if(NULL != device) {
        /* Define sample frequency. */
        device->audio_pub.sample_frequency = sample_frequency;
        tmp = device->audio_api->open(&device->audio_pub);
        tmp = device->audio_api->init(&device->audio_pub);
    }
    else {
       tmp = -1;
    }
    return tmp;
}

int32_t audio_close(p_audio_device device)
{
    if(NULL != device) {
        return device->audio_api->close(&device->audio_pub);
    }
    else {
        return -1;
    }        
}

int32_t audio_init(p_audio_device device)
{
    if(NULL != device) {
    	return device->audio_api->init(&device->audio_pub);
    }
    else {
        return -1;
    }                
}

int32_t audio_destroy(p_audio_device *device)
{
    if(NULL != device) {
        if(NULL != *device) {
            (void)(*device)->audio_api->close(&(*device)->audio_pub);
            free((*device)->audio_pub.audio_buffer_raw);
            free(*device);
            *device = NULL;
        }
    }        
    return 0;
}

void audio_capture(p_audio_device device, te_audio_segments buffer_segment)
{
    if(NULL != device) {
        device->audio_api->record(&device->audio_pub, buffer_segment);
        pthread_cond_signal(&device->segment_cond_t[buffer_segment]);
    }        
}

void audio_capture_wait(p_audio_device device, te_audio_segments buffer_segment)
{
    if(NULL != device) {
        pthread_cond_wait(&device->segment_cond_t[buffer_segment], &device->segment_mutex_t[buffer_segment]);
    }
}

void audio_play(p_audio_device device, te_audio_segments buffer_segment)
{
    if(NULL != device) {
        device->audio_api->play(&device->audio_pub, buffer_segment);
    }        
}

void audio_raw2double(p_audio_device device, te_audio_segments buffer_segment, double *audio_data)
{
    int32_t i;
    int32_t start, end, step;
    uint8_t *ptmp_u8;
    int16_t tmp_s16;
    double *ptmp_d = audio_data;

    if(NULL != device) {
        start = device->audio_pub.audio_buffer_size * buffer_segment;
        ptmp_u8 = &device->audio_pub.audio_buffer_raw[start];

        end = start + device->audio_pub.audio_buffer_size;
        step = 2 * (device->audio_pub.dsp_channels + 1);
    
        for(i = start; i < end; i += step) {
            tmp_s16 = (int16_t)(ptmp_u8[0] + (ptmp_u8[1] << 8));
            *ptmp_d = (double)tmp_s16;
            ptmp_d++;
            ptmp_u8 += step;
        }
        pthread_mutex_unlock(&device->segment_mutex_t[buffer_segment]);
    } 
}

void audio_double2raw(p_audio_device device, te_audio_segments buffer_segment, double *audio_data)
{
    int32_t i;
    int32_t start, end, step;
    int16_t ptmp_s16;
    uint8_t *ptmp_u8;
    double *ptmp_d = audio_data;

    if(NULL != device) {
        start = device->audio_pub.audio_buffer_size * buffer_segment;
        ptmp_u8 = &device->audio_pub.audio_buffer_raw[start];

        end = start + device->audio_pub.audio_buffer_size;
        step = 2 * (device->audio_pub.dsp_channels + 1);
    
        for(i = start; i < end; i += step) {
            ptmp_s16 = (int16_t)*ptmp_d++ & 0xFFFF;
            *ptmp_u8++ = (uint8_t)ptmp_s16 & 0xFF;
            *ptmp_u8++ = (uint8_t)(ptmp_s16 >> 8) & 0xFF;
        }
    }        
}

uint32_t audio_device_samples_get(p_audio_device device)
{
    uint32_t tmp;

    tmp = 0;
    if(NULL != device) {
        tmp = device->audio_pub.samples;
    }        
    return tmp;
}    

static void error_message(char *msg)
{
    if(msg_handler == NULL) {
        printf("%s\n", msg);
    }
    else {
        msg_handler(msg);
    }
}

/*
 * Audio device type queries.
 */
int32_t audio_supported_device_types_get(void)
{
    return AUDIO_NUMBER_OF_DEVICE_TYPES;
}

char* audio_device_type_name_get(int32_t audio_device_type_id)
{
    return AUDIO_DEVICE_TABLE[audio_device_type_id].audio_device_type_name;
}

/*
 * Audio device filename/streamname support functions.
 */
void audio_device_name_set(p_audio_device device, const char *name)
{
    if(NULL != device) {
        snprintf(device->audio_pub.name, AUDIO_DEVICE_NAME_LENGTH, name);
    }
}

void audio_device_name_get(p_audio_device device, char **name)
{
    if(NULL != device) {
        *name = device->audio_pub.name;
    }
}

/*
 * Audio device properties.
 */
void audio_sample_rate_set(p_audio_device device, int32_t Hertz)
{
    if(NULL != device) {
        device->audio_pub.sample_frequency = Hertz;
    }
}    

int32_t audio_sample_rate_get(p_audio_device device)
{
    int32_t tmp;
    
    /** @note This assumes record and playback are at the same rate.
     *  The audio API could support multiple cards at different rates, but that
     *  capability will not be used for now.
     */ 
    if(NULL != device) {
        tmp = device->audio_pub.sample_frequency;
    }
    else {
        tmp = 0;
    }
    return tmp;
} 


void register_error_message_handler(message_handler handler)
{
    msg_handler = handler;
}
