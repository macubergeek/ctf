/*
 * morse.c
 * $Id: morse.c,v 1.68 2009/05/30 00:45:51 kprox Exp $
 *
 * Copyright (C) 2002-2006:
 * Ken Prox <kprox@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */

#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>

#include <gsl/gsl_errno.h>
#include <gsl/gsl_fft_real.h>
#include <gsl/gsl_fft_halfcomplex.h>

#include "agc.h"
#include "dt_window.h"
#include "dglitch.h"

#include "morse.h"
#include "utility.h"
#include "fir_win.h"

/** Needed to unpack the in place radix2 FFT terms 0 to N/2 - 1 */
#define REAL(z,i) ((z)[i])
#define IMAG(z,i,length) ((i) == 0 ? 0 : (z)[length-i])

#define THIRTY_SIX_WPM                      (double)36.000
/** This is the duration of a dit morse element in seconds at 36 words per minute.
 *  The units are Seconds/dit @ 36wpm.
 */
#define DIT_DUR_AT_36_WPM                   (double)00.0325
/** Words per minute seconds per dit. */
#define WPM_SECONDS_PER_DIT                 (double)(DIT_DUR_AT_36_WPM * THIRTY_SIX_WPM)

/** The minumum number of packets that will make up a dit.
 *  This limit is used to control transient noise immunity.
 */
#define MIN_NUM_PACKS_PER_DIT               6

/** Maximum value of the FFT graph display. */
#define FFT_GRAPH_TOP                       (double)100000.0
/** @todo Change based on rolling average of packet amplitude array. */
#define CW_ON_AMPLITUDE                     (FFT_GRAPH_TOP * 0.51)
/** @todo Change based on rolling average of packet amplitude array. */
#define CW_OFF_AMPLITUDE                    (FFT_GRAPH_TOP * 0.5)
#define MORSE_AGC_TYPE                      AGC_LINEAR_PEAK_W_COMPUTED_GAIN_ON_CLIP
#define FFT_DATA_MAX_GAIN                   (double)10.0
#define FFT_DATA_MIN_GAIN                   (double)0.1
#define AGC_FULL_SCALE_DELAY_SECS           (double)3.0
#define FFT_NOISE_FLOOR                     (double)50000.0
#define FFT_SCOPE_GAIN_UP_CRR_FACTOR        (double)0.025
#define FFT_SCOPE_GAIN_DOWN_CRR_FACTOR      (double)0.05

#define AUDIO_SEGMENTS_PER_STATUS_UPDATE    5


#if !(defined(FALSE) || defined(TRUE))
    #define FALSE                   0
    #define TRUE                    1
#endif

/* Character Status flags */
#define CLEAR_CHARACTER_STATUS      0x00u
#define END_OF_CHARACTER            0x01u
#define VALID_CW_ON_TONE_DETECTED   0x02u
#define VALID_CW_OFF_TONE_DETECTED  0x04u

/* Word status flags. */
#define CLEAR_WORD_STATUS           0x00u
#define END_OF_WORD                 0x01u

#define SHORT_DAH_VS_DITS           (double)2.4000
#define LONG_DAH_VS_DITS            (double)3.6000
#define SHORT_DIT_VS_DAHS           (double)0.2667
#define LONG_DIT_VS_DAHS            (double)0.4000

#define SHORT_ELEMENT               (double)0.7500
#define LONG_ELEMENT                (double)1.2500

#define CHARACTER_SPACE_DITS        (double)2.5000
#define WORD_SPACE_DITS             (double)6.0000

#define MORSE_ELEMENT_HISTORY       5

/*
 * begin debugging options 
 */
#define DEBUG_DIT_DAH_DETECTION(a) /* printf a */
#define DEBUG_MORSE_STATISTICS(a) /* printf a */
#define DEBUG_MORSE_TIMING(a) /* printf a */
#define DEBUG_TONE_DETECTION(a) /* printf a */
#define DEBUG_RAW_FFT_ARRAY(a)  /* printf a */
#define DEBUG_DGLITCHED_FFT_ARRAY(a)  /* printf a */
#define DEBUG_DATA_COLLECTION_THREAD(a)  /* printf a */
#define DEBUG_AUDIO_PP_THREAD(a) /* printf a */
#define DEBUG_MORSE_THREAD(a) /* printf a */
/*
 * end debugging options 
 */

/** \struct IMorse
 *  \brief Interface that GUI functions register to.
 */
typedef struct IMorse {
    /*! User interface status bar. */
    UI_update_status         cb_morse_status;
    /*! User interface time or FFT plot. */
    UI_scope_plot            cb_scope_plot;
    /*! User interface for decoded characters. */
    UI_display_character     cb_display_character;
    /** User Interface handler for debugging. */
    UI_debug_plot            debug_plot;
    /** User interface for Morse Statistics. */
    UI_Morse_statistics      cb_Morse_statistics;
} IMorse;

static IMorse user_interface;

static te_morse_plot_type scope_or_fft = PLOT_FFT;

/** \struct ts_morse_2_char
 *  \brief Morse code stream to ASCII character element.
 */
typedef struct ts_morse_2_char
{
/*! The morse code stream. */
/*! Morse code streams are defines as follows:
    The first three nibbles represent the morse character data stream, the fourth
    nibble represents the number of elements in the character.
    A binary 1, corresponds to a dah, and a binary 0 corresponds to a dit.
    For example: 
        c -.-. is represented by b1010 0000 0000 0100, or 0xA004
*/
    uint32_t morse;
/*! The character(s) represented by the morse data stream as defined in morse. */
    char *character;
} ts_morse_2_char;

/** Morse code stream to acsii conversion table.
 *  An array of ts_morse_2_char structs.
 *  @sa ts_morse_2_char
 */
const ts_morse_2_char MORSE_CODE_DECODE_TABLE[] = {
    {0x0001, "e"}, /* .             */
    {0x8001, "t"}, /* _             */
    {0x0002, "i"}, /* . .           */
    {0xC002, "m"}, /* _ _           */
    {0x8002, "n"}, /* _ .           */
    {0x4002, "a"}, /* . _           */
    {0x0003, "s"}, /* . . .         */
    {0x8003, "d"}, /* _ . .         */
    {0xC003, "g"}, /* _ _ .         */
    {0x2003, "u"}, /* . . _         */
    {0x4003, "r"}, /* . _ .         */
    {0xA003, "k"}, /* _ . _         */
    {0x6003, "w"}, /* . _ _         */
    {0xE003, "o"}, /* _ _ _         */
    {0x8004, "b"}, /* _ . . .       */
    {0xA004, "c"}, /* _ . _ .       */
    {0x2004, "f"}, /* . . _ .       */
    {0x0004, "h"}, /* . . . .       */
    {0x7004, "j"}, /* . _ _ _       */
    {0x4004, "l"}, /* . _ . .       */
    {0xB004, "y"}, /* _ . _ _       */
    {0x6004, "p"}, /* . _ _ .       */
    {0xD004, "q"}, /* _ _ . _       */
    {0x1004, "v"}, /* . . . _       */
    {0x9004, "x"}, /* _ . . _       */
    {0xC004, "z"}, /* _ _ . .       */
    {0xF805, "0"}, /* _ _ _ _ _     */
    {0x7805, "1"}, /* . _ _ _ _     */
    {0x3805, "2"}, /* . . _ _ _     */
    {0x1805, "3"}, /* . . . _ _     */
    {0x0805, "4"}, /* . . . . _     */
    {0x0005, "5"}, /* . . . . .     */
    {0x8005, "6"}, /* _ . . . .     */
    {0xC005, "7"}, /* _ _ . . .     */
    {0xE005, "8"}, /* _ _ _ . .     */
    {0xF005, "9"}, /* _ _ _ _ .     */
    {0x8406, "-"}, /* _ . . . . _   */
    {0x9005, "/"}, /* _ . . _ .     */
    {0x5406, "."}, /* . _ . _ . _   */
    {0xCC06, ","}, /* _ _ . . _ _   */
    {0x3006, "?"}, /* . . _ _ . .   */
    {0x8805, "="}, /* _ . . . _     */
    {0x6806, "@"}, /* . _ _ . _ .   */
    {0xB005, "("}, /* _ . _ _ .     */
    {0xB406, ")"}, /* _ . _ _ . _   */
    {0x3406, "_"}, /* . . _ _ _ .   */
    {0x4806,"\""}, /* _ . _ _ . _   */
    {0x7806, "'"}, /* . _ _ _ _ .   */
    {0xE006, ":"}, /* _ _ _ . . .   */
    {0xA806, ";"}, /* _ . _ . _ .   */
    {0x1207, "$"}, /* . . . _ . . _ */
    {0x5005, "+"}, /* . _ . _ .     */
    {0xE004, "!"}, /* _ _ _ .       */
    {0x4005, "&"}  /* . _ . . .    */
};
#define MORSE_CODE_DECODE_TABLE_SIZE (sizeof(MORSE_CODE_DECODE_TABLE) / sizeof(struct ts_morse_2_char))

/** CW level detection states.
 *  CW_ON, tone is present
 *  CW_OFF, tone is not present
 */
typedef enum {CW_ON, CW_OFF} te_cw;

/** Basic Morse elements. */
typedef enum {DAH, DIT} te_morse_element_type;

/** Morse code detector settings. */ 
typedef struct ts_morse_settings {
/*! The audio data post processing packet size. 
 *  The Maximum WPM that can be decoded is inversly proportional
 *  to the tone packet size.
 */
    uint32_t tone_packet_size;

/*! The size of the fft to be plotted on the main gui. */
    uint32_t fft_data_size;
/*! Used to improve immunity to transient noise. */
/*! If cw tones are detected that are shorter this, it's considerd noise. */    
    double minimum_tone_duration;
/*! The duration of a single fft packet given the current audio settings. */
    double tone_packet_duration;
/*! Frequency resolution. */
    double fft_freq_step;     
/*! Size of the fft packet amplitude array. */
    uint32_t fft_amp_pa_size;
/** Audio Device Type, or audio type Id. */
    int32_t audio_type_id;
/** Data for audio device (audio capture). */
    p_audio_device audio_rec_dev;
/** Data for audio playback device (play filtered audio). */
    p_audio_device audio_play_dev;
/** Audio Device Sample frequency in Hertz. */
    int32_t sample_frequency;
} ts_morse_settings;

/** Keeps track of morse timing averages (dit and dah). */
typedef struct ts_morse_statistics
{
    /*! Duration of the last MORSE_ELEMENT_HISTORY elements (dits or dahs). */
    double duration_history[MORSE_ELEMENT_HISTORY];
    /*! The average duration. */
    double avg_duration;
    /*! Number of valid timing measurements stored. */
    int32_t samples;
} ts_morse_statistics;

/** Timing of current Morse dit or dah element. */
typedef struct ts_morse_element
{
    /*! Morse element, DIT or DAH. */
    te_morse_element_type dah_or_dit;
    /*! Duration of the current measurement. */
    double duration;
    /*! Duration of the previous element. */
    double previous_duration;
} ts_morse_element;

/** Morse character object. */
typedef struct ts_morse_char
{
    /*! Dit-dah stream. */
    uint8_t dit_dahs;
    /*! The bit position that the next Morse element will be stored in dit_dahs. */
    uint8_t element_position_mask;
    /*! Number of Morse elements in character. */
    uint8_t elements;
    /*! The decoding status of the current character. */
    uint8_t char_status;
    /*! The end of word status of a character. */
    uint8_t word_status;
} ts_morse_char, *p_morse_char;

/** Morse code data, one per decoding thread. Currently, only one. */
typedef struct ts_morse_data {
    /*! Discrete time window object */
    dt_window dt_w;
    /*! Computed AGC gain up increment. */
    double agc_dg;
    /*! Apply AGC boolean. */
    te_morse_agc_enable apply_agc;
    /*! Automatic Gain Control object. */
    agc scope_gain;
    /*! Current fft data gain. */
    double fft_data_gain;
    /*! Running dit statistics. */
    ts_morse_statistics dit_statistics;
    /*! Running dah statixtics. */
    ts_morse_statistics dah_statistics;
    /*! Frequency being decoded \todo Needs to be frequency, not index of FFT frequency step. */
    int32_t cw_frequency;
    /*! Running CW on and off durations. */
    double cw_on_duration, cw_off_duration;
    /*! State of the cw on/off state machine. */
    te_cw state;
    /*! */
    ts_morse_element morse_element;
    /*! The current morse character being constructed. */
    ts_morse_char morse_char;
    /*! Current words per minute for morse de-coder thread. */
    double words_per_minute;
    /*! Number of taps in the FIR filter. */
    uint32_t filter_taps;
    /*! FFT filter (High - Low) frequency. */
    double filter_bandwidth;
    /*! FFT window noise filter */
    p_fwin fir_filter; 
    /*! Equal 1, apply filter, equal 0, do not apply fir filter. */
    te_morse_filter_enable apply_fir;
    /*! Remove glitches packet amplitude array (post fft processing). */
    p_dglitch packet_amp_array_dg;
    /*! Pointer to array of fft packet amplitudes. */
    double *fft_amp_pa;
} ts_morse_data, *p_morse_data;

static ts_morse_settings morse_settings;

/* This could become an array, for decoding more than one signal at a time. */
static ts_morse_data morse_thread;

/* NOTE: this should be owned by the morse decoding thread if/when there are multiple morse decoding threads. */
static double *fft_data;
static double *audio_data;

static volatile te_morse_thread_state run = THREADS_NOT_RUNNING;

/** Number of threads in morse2txt. */
typedef enum {
    /*! Collects data from soundcard. */
    DATA_COLLECTION_THREAD = 0,
    /*! Scales raw data from soundcard. */
    AUDIO_POST_PROCESSING_THREAD,
    /*! Decodes Morse. */
    MORSE_CODE_DECODING_THREAD,
    NUMBER_OF_THREADS
} te_morse_threads;
/** Array of thread ID's. */
static pthread_t tid[NUMBER_OF_THREADS];

static pthread_mutex_t m_audio_post_processing = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t audio_post_processing_complete = PTHREAD_COND_INITIALIZER;

/** \todo - If multiple morse threads are running, these can no longer have local global scope. */
static int32_t fft_performed = 0;
static int32_t samples_processed = 0;

/*
 * Local functions
 */

/** Audio collection data thread. */
static void data_collection(void *param);
/** Audio post processing thread. */
static void audio_post_process(void *param);
/** Morse de-coding thread. */
static void morse_code(void * param);

/** Close audio device, and free all objects. */
static void free_all(void);

/* Creates an array of the fft packet amplitudes at a fixed frequency. */
static void morse_create_fft_amp_array(p_morse_data morse_thread_data);
static void duration_2_morse_element(p_morse_data morse_thread_data);
static void check_for_eoc_eow(p_morse_data morse_thread_data);
static char *morse2txt(p_morse_char morse_char);
static void reset_morse_char(p_morse_char morse_char);
static void compute_morse_statistics(ts_morse_statistics *dit_dah, double duration);
static void add_element_2_morse_character(p_morse_data morse_thread_data);
static void morse_measure_fft_packet_timing(p_morse_data morse_thread_data);
static void morse_calculate_current_wpm(p_morse_data morse_thread_data);
static void morse_recompute_filter(void);

/** Interface handler for GUI status */
static void update_status(int32_t ffts, uint32_t samples, double wpm);
/** Interface handler that plots a graph on the GUI. */
static void scope_plot(double *vector, uint32_t num_points);
/** Interface handler to display a received character on the GUI. */
static void display_character(char *character);
/** Interface function for displaying Morse Statistics. */
static void update_morse_statistics(p_morse_data morse_data_p);

/* Debugging Interface Functions */
#if DEBUG_GRAPH_INTERFACE == 1
    static void morse_debug_plot(const int8_t *plot, int32_t y);
    static void morse_debug_plot(const int8_t *plot, int32_t y)
    {
        if(user_interface.debug_plot != NULL) {user_interface.debug_plot(plot, y);}
    }

    void register_debug_plot(UI_debug_plot hndlr) {user_interface.debug_plot = hndlr;}
#else
    #define morse_debug_plot(a, b)
#endif

int32_t morse_start_threads(void)
{
    int32_t error = 0;

    if(run != THREADS_NOT_RUNNING) {
        goto morse_running;
    }
    run = THREADS_STARTING;

    morse_thread.agc_dg = (FFT_DATA_MAX_GAIN - FFT_DATA_MIN_GAIN) * (double)morse_settings.tone_packet_size \
                / AGC_FULL_SCALE_DELAY_SECS / (double)morse_settings.sample_frequency;

    fft_performed = samples_processed = 0;

    /* Open the audio device. */
    if(audio_open(morse_settings.audio_rec_dev, morse_settings.sample_frequency) != 0) {
        goto err_hndlr;
    }

    /* Compute after opening audio device, so the ACTUAL sample rate is known. */
    morse_settings.minimum_tone_duration = \
        (double)morse_settings.tone_packet_size / (double)audio_sample_rate_get(morse_settings.audio_rec_dev) * (double)MIN_NUM_PACKS_PER_DIT;

    /* NOTE: Watch math here, these numbers should be some power two.  Denominator and Numerator. */
    morse_settings.fft_amp_pa_size = (int32_t)audio_device_samples_get(morse_settings.audio_rec_dev) / (int32_t)morse_settings.tone_packet_size;
    morse_thread.dit_statistics.samples = 0;
    morse_thread.dah_statistics.samples = 0;

    /* Create an array for the FFT data. */
    if(NULL == (fft_data = malloc(morse_settings.tone_packet_size * sizeof(double)))) {
        goto err_hndlr;
    }        

    /* Create a discrete time window for application to the audio packets prior to FFT. */
    if(NULL == (morse_thread.dt_w = dt_window_create(DT_HAMMING_WINDOW, morse_settings.tone_packet_size))) {
        goto err_hndlr;
    }        

    /* Create an AGC object. */
    if(NULL == (morse_thread.scope_gain = agc_create(FFT_DATA_MAX_GAIN,
                                                     FFT_DATA_MIN_GAIN,
                                                     FFT_NOISE_FLOOR,
                                                     FFT_GRAPH_TOP,
                                                     MORSE_AGC_TYPE,
                                                     morse_thread.agc_dg,
                                                     FFT_SCOPE_GAIN_DOWN_CRR_FACTOR))) {
        goto err_hndlr;
    }        

    /* Create a DeGlitch object. */
    if(NULL == (morse_thread.packet_amp_array_dg = dglitch_create(DG_MEDIAN, MIN_NUM_PACKS_PER_DIT))) {
        goto err_hndlr;
    }        

    /* Duration in time represented by one FFT. */
    morse_settings.tone_packet_duration = 1.0 / (double)morse_settings.sample_frequency * (double)morse_settings.tone_packet_size;
    /* FFT frequency resolution. */
    morse_settings.fft_freq_step = (double)morse_settings.sample_frequency / (double)morse_settings.tone_packet_size;
    
    /* Create a FIR filter object. */
    if(NULL == (morse_thread.fir_filter = fwin_create((double)morse_settings.sample_frequency,
                                                      500.0,
                                                      1500.0,
                                                      FW_BANDPASS,
                                                      FW_BLACKMAN,
                                                      morse_thread.filter_taps))) {
        goto err_hndlr;
    }        
                                            
    morse_recompute_filter();

    /* Create an array for audio packet amplitudes. */
    if(NULL == (morse_thread.fft_amp_pa = malloc(morse_settings.fft_amp_pa_size * sizeof(double)))) {
        goto err_hndlr;
    }        
        
    /* Create an array for real audio data. */
    if(NULL == (audio_data = malloc(audio_device_samples_get(morse_settings.audio_rec_dev) * sizeof(double)))) {
        goto err_hndlr;
    }        

    run = THREADS_RUNNING;
    /*
     * not necessary to pass morse_data to thread, but in the future, this could pave the way 
     * for decoding more than one signal at a time.  Could be usefull when monitoring multiple QSO's.
     * In this case, code must be made re-entrant, no local static variables in functions.
     */
    (void)pthread_create(&tid[MORSE_CODE_DECODING_THREAD], NULL, (void*)&morse_code, (void*)&morse_thread);
    (void)pthread_create(&tid[DATA_COLLECTION_THREAD], NULL, (void*)&data_collection, NULL);
    (void)pthread_create(&tid[AUDIO_POST_PROCESSING_THREAD], NULL, (void*)&audio_post_process, NULL);

    /** @note Goto's are bad?  I'm sure that's what you were taught...
     * It does yield a unified exit strategy for a function though, 
     * without explicit multiple exit points.  No need to "nest"
     * all of the above if statements as well.
     */

    /* no error */
    goto morse_running;

err_hndlr:
    error = -1;
    free_all();
    run = THREADS_NOT_RUNNING;

morse_running:
    return error;
}

te_morse_thread_state morse_stop_threads(void)
{
    if(run == THREADS_RUNNING) {
        run = THREADS_CANCELING;
        pthread_join(tid[DATA_COLLECTION_THREAD], NULL);
        pthread_join(tid[AUDIO_POST_PROCESSING_THREAD], NULL);
        pthread_join(tid[MORSE_CODE_DECODING_THREAD], NULL);
        free_all();
        run = THREADS_NOT_RUNNING;
    }
    return run;
}

static void free_all(void)
{
    dt_window_destroy(&morse_thread.dt_w);
    agc_destroy(&morse_thread.scope_gain);
    dglitch_destroy(&morse_thread.packet_amp_array_dg);
    fwin_destroy(&morse_thread.fir_filter);
    audio_close(morse_settings.audio_rec_dev);
    free(fft_data);
    free(audio_data);
    free(morse_thread.fft_amp_pa);
    fft_data = NULL;
    morse_thread.fft_amp_pa = NULL;
}

static void data_collection(void *param)
{
    static uint32_t buffer_segment;

    param = param;
    
    buffer_segment = BUFFER_SEGMENT_1;
    while(run == THREADS_RUNNING) {
        audio_capture(morse_settings.audio_rec_dev, buffer_segment);
        DEBUG_DATA_COLLECTION_THREAD( ("dc acq seg %d.\n", buffer_segment) );
        buffer_segment++;
        if(buffer_segment >= AUDIO_BUFFER_SEGMENTS) {
            buffer_segment = BUFFER_SEGMENT_1;
        }
    }
    pthread_exit(NULL);
}

static void audio_post_process(void *param)
{
    static te_audio_segments buffer_segment;

    param = param;
    
    buffer_segment = BUFFER_SEGMENT_1;
    while(run == THREADS_RUNNING) {
        DEBUG_AUDIO_PP_THREAD( ("audio pp wait seg %d.\n", buffer_segment) );
        audio_capture_wait(morse_settings.audio_rec_dev, buffer_segment);
        audio_raw2double(morse_settings.audio_rec_dev, buffer_segment, audio_data);
        DEBUG_AUDIO_PP_THREAD( ("audio pp done seg %d.\n", buffer_segment) );
        pthread_cond_broadcast(&audio_post_processing_complete);
        buffer_segment++;
        samples_processed += audio_device_samples_get(morse_settings.audio_rec_dev);
        if(buffer_segment >= AUDIO_BUFFER_SEGMENTS) {
            buffer_segment = BUFFER_SEGMENT_1;
        }
        /* display the audio data on the plot. */
        if(scope_or_fft == PLOT_SCOPE) {
            scope_plot(audio_data, morse_settings.tone_packet_size);
        }
    }
    pthread_cond_signal(&audio_post_processing_complete);
    pthread_exit(NULL);
}

static void morse_code(void *param)
{
    p_morse_data tmp = ((p_morse_data)(param));

    while(run == THREADS_RUNNING) {
        DEBUG_MORSE_THREAD( ("wait for audio post process\n") );
        pthread_cond_wait(&audio_post_processing_complete, &m_audio_post_processing);
        /* Step 1) Filter raw audio data. */
        if(tmp->apply_fir == MORSE_ENABLE_FILTER) {
            fwin_apply(tmp->fir_filter, audio_data, audio_device_samples_get(morse_settings.audio_rec_dev));
        }
        DEBUG_MORSE_THREAD( ("FIR done\n") );
        /* Step 2) Create an array of fft amplitudes for a fixed frequency. */
        /*         Apply agc (automatic gain control).                      */
        /*         Scale amplitudes using AGC gain.                         */
        /*         Update time or fft domain plot.                          */
        morse_create_fft_amp_array(tmp);
        pthread_mutex_unlock(&m_audio_post_processing);

        /* Step 3) De-glitch the array of fft amplitudes. */
        dglitch_apply(tmp->packet_amp_array_dg, tmp->fft_amp_pa, morse_settings.fft_amp_pa_size);
        DEBUG_MORSE_THREAD( ("de-glitch done\n") );

        /* Step 4) Measure timing of fft packets, and decode morse elements. */
        morse_measure_fft_packet_timing(tmp);
        DEBUG_MORSE_THREAD( ("fft packet timing done\n") );

        /* Calculate the current wpm for the status display. */
        morse_calculate_current_wpm(tmp);

        /* Update the status display. */
        update_status(fft_performed, (uint32_t)samples_processed, tmp->words_per_minute);
        update_morse_statistics(tmp);
    }
    pthread_exit(NULL);
}

static void morse_create_fft_amp_array(p_morse_data morse_thread_data)
{
    uint32_t i, j, k;
    int32_t gsl_error;

    /*
     * The beginning of locating tones in a audio segment.
     */
    k = 0;
    for(i = 0; i < audio_device_samples_get(morse_settings.audio_rec_dev); i += morse_settings.tone_packet_size) {
        /* apply a discrete time window to the packet, supresses FFT leakage */
        dt_window_apply(morse_thread_data->dt_w, &audio_data[i]);

        /* perform a FFT on the packet */
        gsl_error = gsl_fft_real_radix2_transform(&audio_data[i], 1, morse_settings.tone_packet_size);

        fft_performed += 1;
        /* create an array of the FFT Amplitude, unpack the inplace FFT */
        for (j = 0; j < morse_settings.tone_packet_size; j++) {
            fft_data[j] = sqrt(pow(REAL(&audio_data[i], j), 2.0) + \
                               pow(IMAG(&audio_data[i], j, morse_settings.tone_packet_size), 2.0));
            fft_data[j] *= morse_thread_data->fft_data_gain;
        }

        /* get the amplitude of the selcted frequency, store in packet amplitude array. */
        morse_thread_data->fft_amp_pa[k] = fft_data[morse_thread_data->cw_frequency];

        /* update fft gain */
        if(morse_thread_data->apply_agc == MORSE_ENABLE_AGC) {
            morse_thread_data->fft_data_gain = agc_update(morse_thread_data->scope_gain, morse_thread_data->fft_amp_pa[k]); 
        }

        DEBUG_TONE_DETECTION( ("%8.2f, %8.2f\n", morse_thread_data->fft_data_gain, morse_thread_data->fft_amp_pa[k]) );
        DEBUG_RAW_FFT_ARRAY( ("%10.2f\n", morse_thread_data->fft_amp_pa[k]) );
        morse_debug_plot("2", (int32_t)(morse_thread_data->fft_amp_pa[k] / 10.0));
        k++;

        /* display the FFT on the plot. */
        if(scope_or_fft == PLOT_FFT) {
            scope_plot(fft_data, morse_settings.fft_data_size);
        }
    }
}

/** Measures the duration of a fft tone packet, detects presence of tone.
 *  @param morse_thread_data Pointer to morse decoding thread data.
 *  @sa p_morse_data
 */
static void morse_measure_fft_packet_timing(p_morse_data morse_thread_data)
{
    uint32_t i;

    /** \todo - Is de-glitching necessary here? */
    for(i = 0; i < morse_settings.fft_amp_pa_size; i++) {

        switch(morse_thread_data->state) {
            case CW_ON:
                if(
                    (morse_thread_data->fft_amp_pa[i] <= CW_OFF_AMPLITUDE)
                        && \
                    (morse_thread_data->cw_on_duration >= morse_settings.minimum_tone_duration)
                  )
                {
                    morse_thread_data->morse_element.duration = morse_thread_data->cw_on_duration;
                    duration_2_morse_element(morse_thread_data);
                    add_element_2_morse_character(morse_thread_data);
                    morse_thread_data->state = CW_OFF;
                    morse_thread_data->cw_off_duration = morse_settings.tone_packet_duration;
                    morse_thread_data->morse_char.char_status |= VALID_CW_ON_TONE_DETECTED;
                }
                else if(morse_thread_data->fft_amp_pa[i] <= CW_OFF_AMPLITUDE) {
                    /* 
                     * Noise, which will add energy to off states,
                     * will be counted as a time interval that belongs to the off state,
                     * if the on state is deemed too short for the selected audio settings.
                     */
                    morse_thread_data->cw_off_duration += morse_thread_data->cw_on_duration;
                    morse_thread_data->state = CW_OFF;
                    DEBUG_MORSE_TIMING(("noise in cw_off state\n"));
                }
                else {
                    /* tone remains on, increment the duration by the per packet time interval. */
                    morse_thread_data->cw_on_duration += morse_settings.tone_packet_duration;
                    DEBUG_MORSE_TIMING(("cw_on duration %e seconds\n", morse_thread_data->cw_on_duration));
                }
                break;

            case CW_OFF:
                if(
                    (morse_thread_data->fft_amp_pa[i] >= CW_ON_AMPLITUDE)
                        && \
                    (morse_thread_data->cw_off_duration >= morse_settings.minimum_tone_duration)
                  )
                {
                    morse_thread_data->state = CW_ON;
                    DEBUG_MORSE_TIMING(("cw_off duration was %e seconds\n", morse_thread_data->cw_off_duration));
                    morse_thread_data->morse_char.char_status |= VALID_CW_OFF_TONE_DETECTED;
                    morse_thread_data->cw_on_duration = morse_settings.tone_packet_duration;
                }
                else if(morse_thread_data->fft_amp_pa[i] >= CW_ON_AMPLITUDE) {
                    /* 
                     * Noise, which can subtract energy from valid on states,
                     * will be counted as a time interval that belongs to the on state,
                     * if the off state is deemed too short for the selected audio settings.
                     */
                    morse_thread_data->cw_on_duration += morse_thread_data->cw_off_duration;
                    morse_thread_data->state = CW_ON;
                    DEBUG_MORSE_TIMING(("noise in cw_on state\n"));
                }
                else {
                    morse_thread_data->cw_off_duration += morse_settings.tone_packet_duration;
                }
                break;

            default:
                morse_thread_data->state = CW_OFF;
                break;
        }
        DEBUG_DGLITCHED_FFT_ARRAY( ("%4.2f, %10.2f\n", morse_thread_data->fft_data_gain, morse_thread_data->fft_amp_pa[i]) );
        morse_debug_plot("0", (int32_t)(morse_thread_data->fft_amp_pa[i] / 5.0));
        check_for_eoc_eow(morse_thread_data);
    }
}

/** Calculates the current received Morse speed in Words per Minute.
 *  @param morse_thread_data Pointer to morse decoding thread data.
 *  @sa p_morse_data
 *  @sa DIT_DUR_AT_36_WPM
 *  @sa WPM_SECONDS_PER_DIT
 */
static void morse_calculate_current_wpm(p_morse_data morse_thread_data)
{
    if(morse_thread_data->dit_statistics.avg_duration > 0) {
         /* (wpm seconds per dit) * (dit per second) */
        morse_thread_data->words_per_minute = WPM_SECONDS_PER_DIT / morse_thread_data->dit_statistics.avg_duration;
    }
    else { 
        morse_thread_data->words_per_minute = 0.0;
    }
}

/** Looks for a morse end of character or end of word.
 *  @param morse_thread_data Pointer to morse decoding thread data.
 *  @sa p_morse_data
 */
static void check_for_eoc_eow(p_morse_data morse_thread_data)
{
    int32_t ctmp, wtmp;

    if(morse_thread_data->dit_statistics.avg_duration > 0) {
        ctmp = wtmp = 0;
        if(morse_thread_data->cw_off_duration >= (CHARACTER_SPACE_DITS * morse_thread_data->dit_statistics.avg_duration)) {
            ctmp |= END_OF_CHARACTER;
        }
        if(morse_thread_data->cw_off_duration >= (WORD_SPACE_DITS * morse_thread_data->dit_statistics.avg_duration)) {
            wtmp |= END_OF_WORD;
        }

        if(
           (wtmp & END_OF_WORD)
              && \
           (!(morse_thread_data->morse_char.word_status & END_OF_WORD))
          )
        {
            morse_thread_data->morse_char.word_status |= END_OF_WORD;
            display_character(" ");
            DEBUG_DIT_DAH_DETECTION(("EOW\n"));
        }
        else if(
                (ctmp & END_OF_CHARACTER)
                    && \
                !(morse_thread_data->morse_char.char_status & END_OF_CHARACTER)
                    && \
                (morse_thread_data->morse_char.char_status & VALID_CW_ON_TONE_DETECTED)
                    && \
                (morse_thread_data->morse_char.char_status & VALID_CW_OFF_TONE_DETECTED)
               )
        {
            morse_thread_data->morse_char.char_status |= END_OF_CHARACTER;
            display_character(morse2txt(&morse_thread_data->morse_char));
            reset_morse_char(&morse_thread_data->morse_char);
            morse_thread_data->morse_char.word_status = 0;
            DEBUG_DIT_DAH_DETECTION(("EOC\n"));
        }
        else { /* no else */ }
    }
}

/** Measures the duration of morse elements.
 *  @param morse_thread_data Pointer to morse decoding thread data.
 *  @sa p_morse_data
 */
static void duration_2_morse_element(p_morse_data morse_thread_data)
{
    if((morse_thread_data->morse_element.duration >= (SHORT_DAH_VS_DITS * morse_thread_data->morse_element.previous_duration)) &&
       (morse_thread_data->morse_element.duration <= (LONG_DAH_VS_DITS * morse_thread_data->morse_element.previous_duration))) {
        compute_morse_statistics(&morse_thread_data->dah_statistics, morse_thread_data->cw_on_duration);
    }
    else if((morse_thread_data->morse_element.duration >= (SHORT_DIT_VS_DAHS * morse_thread_data->morse_element.previous_duration)) &&
            (morse_thread_data->morse_element.duration <= (LONG_DIT_VS_DAHS * morse_thread_data->morse_element.previous_duration))) {
        compute_morse_statistics(&morse_thread_data->dit_statistics, morse_thread_data->cw_on_duration);
    }
    else {; /* not enough information */}

    if((morse_thread_data->morse_element.duration >= (SHORT_DAH_VS_DITS * morse_thread_data->dit_statistics.avg_duration)) &&
       (morse_thread_data->morse_element.duration <= (LONG_DAH_VS_DITS * morse_thread_data->dit_statistics.avg_duration))) {
        morse_thread_data->morse_element.dah_or_dit = DAH;
        DEBUG_DIT_DAH_DETECTION(("dah "));
    }
    else if((morse_thread_data->morse_element.duration >= (SHORT_DIT_VS_DAHS * morse_thread_data->dah_statistics.avg_duration)) &&
            (morse_thread_data->morse_element.duration <= (LONG_DIT_VS_DAHS * morse_thread_data->dah_statistics.avg_duration))) {
        morse_thread_data->morse_element.dah_or_dit = DIT;
        DEBUG_DIT_DAH_DETECTION(("dit "));
    }
    else if((morse_thread_data->morse_element.duration >= (SHORT_ELEMENT * morse_thread_data->dah_statistics.avg_duration)) &&
            (morse_thread_data->morse_element.duration <= (LONG_ELEMENT * morse_thread_data->dah_statistics.avg_duration))) {
        morse_thread_data->morse_element.dah_or_dit = DAH;
        DEBUG_DIT_DAH_DETECTION(("dah "));
    }
    else if((morse_thread_data->morse_element.duration >= (SHORT_ELEMENT * morse_thread_data->dit_statistics.avg_duration)) &&
            (morse_thread_data->morse_element.duration <= (LONG_ELEMENT * morse_thread_data->dit_statistics.avg_duration))) {
        morse_thread_data->morse_element.dah_or_dit = DIT;
        DEBUG_DIT_DAH_DETECTION(("dit "));
    }
    else {; /* not enough information */}
    morse_thread_data->morse_element.previous_duration = morse_thread_data->morse_element.duration;
}

/** Add a dit or dah element to the current character being decoded.
 *  @param morse_thread_data Morse decoding thread data.
 *  @sa p_morse_data
 */
static void add_element_2_morse_character(p_morse_data morse_thread_data)
{
    if(morse_thread_data->morse_element.dah_or_dit == DAH) {
        morse_thread_data->morse_char.dit_dahs |= morse_thread_data->morse_char.element_position_mask;
    }
    morse_thread_data->morse_char.elements++;
    morse_thread_data->morse_char.element_position_mask >>= 1;
}

/** Resets the bit representation of a Morse character, ready for new character.
 *  @param morse_char Morse bit representation of ASCII character, as timed elements.
 *  @sa p_morse_char
 */
static void reset_morse_char(p_morse_char morse_char)
{
    morse_char->element_position_mask = 0x80;
    morse_char->dit_dahs = 0;
    morse_char->elements = 0;
    morse_char->char_status = CLEAR_CHARACTER_STATUS;
}

/** Converts a morse element "bit map" to a ASCII character.
 *  @param morse_char Decoded bit representation of a Morse character.
 *  @sa p_morse_char
 *  @sa MORSE_CODE_DECODE_TABLE
 */
static char *morse2txt(p_morse_char morse_char)
{
    uint32_t i, j;
    char *text = "~";

    i = (morse_char->dit_dahs << 8) | morse_char->elements;

    for(j = 0; j < MORSE_CODE_DECODE_TABLE_SIZE; j++) {
        if(i == MORSE_CODE_DECODE_TABLE[j].morse) {
            text = MORSE_CODE_DECODE_TABLE[j].character;
            break;
        }
    }
    return text;
}

/** Convers and adapts to varying Morse receive speeds, within limits of samplerate and bandwidth.
 *  @param dit_dah Morse statistics.
 *  @param duration Duration of last detected .
 *  @sa ts_morse_statistics
 */
static void compute_morse_statistics(ts_morse_statistics *dit_dah, double duration)
{
    int32_t i;
    double sum;

    if(dit_dah->samples < MORSE_ELEMENT_HISTORY) {
        dit_dah->samples++;
    }

    for(i = (dit_dah->samples - 1); i > 0; i--) {
        dit_dah->duration_history[i] = dit_dah->duration_history[i - 1];	
    }

    dit_dah->duration_history[0] = duration;	

    sum = 0;
    for(i = 0; i < dit_dah->samples; i++) {
        sum = sum + dit_dah->duration_history[i];
    }

    dit_dah->avg_duration = sum / (double)dit_dah->samples;

    DEBUG_MORSE_STATISTICS(("samples %d\tsum %f\tavg_duration %f\n", dit_dah->samples, sum, dit_dah->avg_duration));
}

/** Recompute FIR filter coefecients when different frequency or bandwidth is selected. */
static void morse_recompute_filter(void)
{
    double fl, fh;
    fl = (morse_settings.fft_freq_step * (double)morse_thread.cw_frequency) - (morse_thread.filter_bandwidth / 2.0);
    fh = (morse_settings.fft_freq_step * (double)morse_thread.cw_frequency) + (morse_thread.filter_bandwidth / 2.0);
    if (fl <= 0.0) {
        fl = 0.0;
    }
    fwin_change_freq(morse_thread.fir_filter, fl, fh);
}

/*
 * Interface functions for reading/writing morse.c properties.
 */
void morse_set_filter_apply(te_morse_filter_enable apply) { morse_thread.apply_fir = apply; }
void morse_set_agc_apply(te_morse_agc_enable agc_apply) { morse_thread.apply_agc = agc_apply; }
void morse_set_cw_frequency(int32_t freq)
{
    morse_thread.cw_frequency = freq;
    morse_recompute_filter();
}
void morse_set_filter_bandwidth(int32_t bw)
{
    morse_thread.filter_bandwidth = (double)bw;
    morse_recompute_filter();
}
int32_t morse_get_filter_bandwidth(void) { return (int32_t)morse_thread.filter_bandwidth; }
void morse_set_filter_taps(uint32_t taps) { morse_thread.filter_taps = taps; }
uint32_t morse_get_filter_taps(void) { return morse_thread.filter_taps; }
uint32_t morse_get_tone_packet_size(void) { return morse_settings.tone_packet_size; }
void morse_set_tone_packet_size(int32_t tone_packet_size) { morse_settings.tone_packet_size = tone_packet_size; }
uint32_t morse_get_fft_data_size(void) { return morse_settings.fft_data_size; }
void morse_set_fft_data_size(uint32_t fft_data_size) { morse_settings.fft_data_size = fft_data_size; }
double morse_get_fft_graph_top(void) { return FFT_GRAPH_TOP; }
p_audio_device morse_audio_rec_dev_get(void) { return morse_settings.audio_rec_dev; }
void morse_audio_sample_rate_set(int32_t Hertz) { morse_settings.sample_frequency = Hertz; }    
/** @note This assumes record and playback are at the same rate.
  *  The audio API could support multiple cards at different rates, but that
  *  capability will not be used for now.
  */ 
int32_t morse_audio_sample_rate_get(void) { return morse_settings.sample_frequency; } 

/* Get or Set the audio device type ID. */
int32_t morse_audio_device_type_id_get(void)
{
    return morse_settings.audio_type_id;
}
/** Set the current audio device type Id.
 *  @param audio_device_type_id The Id of the audio device type..
 */
void morse_audio_device_type_id_set(int32_t audio_device_type_id)
{
    morse_settings.audio_type_id = audio_device_type_id;
}


/*
 * Returns morse thread state. 
 */
te_morse_thread_state morse_get_thread_state(void) { return run; }

/*
 * Returns the current plot type. 
 */
te_morse_plot_type morse_get_plot_type(void) { return scope_or_fft; }
/*
 * Sets the current plot type. 
 */
void morse_set_plot_type(te_morse_plot_type plt_type) { scope_or_fft = plt_type; }

/*
 * Computes the maximum words per minute that can be supported
 * according to the audio setting and packet size chosen.. 
 */
double morse_max_wpm_supported(double sample_frequency, double packet_length)
{
    return (double)(WPM_SECONDS_PER_DIT * sample_frequency / (double)packet_length / (double)MIN_NUM_PACKS_PER_DIT);
}

/*
 * GUI Interface function for status. 
 */
static void update_status(int32_t ffts, uint32_t samples, double wpm)
{
    static int32_t i;

    if(++i >= AUDIO_SEGMENTS_PER_STATUS_UPDATE) {
        i = 0;
        if(user_interface.cb_morse_status != NULL) {
            user_interface.cb_morse_status(ffts, samples, wpm);
        }
        else {
            printf("fft's = %d, samples = %d, wpm = %f\n", ffts, samples, wpm);
        }
    }
}

/*
 * GUI Interface function for plotter. 
 */
static void scope_plot(double *vector, uint32_t num_points)
{
    if(user_interface.cb_scope_plot != NULL) {
        user_interface.cb_scope_plot(vector, num_points);
    }
}

/*
 * GUI Interface function for display of decoded character. 
 */
static void display_character(char *character)
{
    if(user_interface.cb_display_character != NULL) {
        user_interface.cb_display_character(character);
    }
    else {
        printf("Decoded character = %s\n", character);
    }
}

/*
 * GUI Interface function for Morse Statistics. 
 */
static void update_morse_statistics(p_morse_data morse_data_p)
{
    static int32_t i;
    morse_stats_ts morse_stats_s;
    
    morse_stats_s.avg_dah_dur = morse_data_p->dah_statistics.avg_duration;
    morse_stats_s.avg_dit_dur = morse_data_p->dit_statistics.avg_duration;
    morse_stats_s.wpm = morse_data_p->words_per_minute;
    if(0.0 != morse_stats_s.avg_dit_dur) {
        morse_stats_s.dah_dit_ratio = morse_stats_s.avg_dah_dur / morse_stats_s.avg_dit_dur;
    }

    if(++i >= AUDIO_SEGMENTS_PER_STATUS_UPDATE) {
        i = 0;
        if(NULL != user_interface.cb_Morse_statistics) {
            user_interface.cb_Morse_statistics(&morse_stats_s);
        }
    }
}

/** register status bar GUI handler. */
void set_update_status_hndlr(UI_update_status hndlr) {user_interface.cb_morse_status = hndlr;}
/** register plot handler. */
void set_scope_plot_hndlr(UI_scope_plot hndlr) {user_interface.cb_scope_plot = hndlr;}
/** register display character handler. */
void set_display_character_hndlr(UI_display_character hndlr) {user_interface.cb_display_character = hndlr;}
/** register Morse statistics display handler. */
void set_Morse_statistics_display_hndlr(UI_Morse_statistics hndlr) {user_interface.cb_Morse_statistics = hndlr;}

void morse_initialize(void)
{
    user_interface.cb_morse_status = NULL;
    user_interface.cb_scope_plot = NULL;
    user_interface.cb_display_character = NULL;
    user_interface.debug_plot = NULL;
    user_interface.cb_Morse_statistics = NULL;
    
    /* Create an audio device. */
    morse_settings.audio_rec_dev = audio_create(morse_settings.audio_type_id, AUDIO_DEVICE_RECORD);
}

void morse_shutdown(void)
{
    audio_destroy(&morse_settings.audio_rec_dev);
}
