/*
 *  $Id: utility.c,v 1.5 2009/05/30 00:45:51 kprox Exp $
 */
#include <stdio.h>
#include <sys/timeb.h>
#include <fcntl.h>
#include <errno.h>

#include "utility.h"

int time_stamp(char *fn, char *event)
{
	struct timeb time_stamp;
	FILE *target = NULL;

	target = fopen (fn, "a");
	if(target != NULL) {
		ftime(&time_stamp);
		fprintf(target, "%-30s%ld.%d\n", event, time_stamp.time, time_stamp.millitm);
		fclose(target);
	}
	return errno;
}

int16_t millisec_get(void)
{
    struct timeb time_stamp;

    ftime(&time_stamp);
    return time_stamp.millitm;
}

