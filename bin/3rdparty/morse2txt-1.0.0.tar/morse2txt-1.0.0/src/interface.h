#ifndef INTERFACE_H
#define INTERFACE_H

GtkWidget* create_MainWindow (void);
GtkWidget* create_morse_about (void);
#endif /* INTERFACE_H */
