/*
 * interface_il.h
 *
 * Copyright (C) 2004, 2005:
 * Ken Prox <kprox@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 *
 *
 */
#ifndef INTERFACE_IL_H
#define INTERFACE_IL_H

#include <stdint.h>
#include <gnome.h>
#include <stdio.h>

//! Main gui widgets.
struct main_widgets {
//! Position x of main gui \a (unused).
    gint16 x;
//! Position y of main gui \a (unused).
    gint16 y;
//! Width of main gui \a (unused).
    guint width;
//! Height of main gui \a (unused).
    guint height;
//! Toolbar Style
/*! Icons only
    Icons & Text
    Text only
*/
    gint toolbar_style;
//! Position of splitter on the main gui.	
    gint pane_position;
//! Pointer to main gui widget, handy when creating modal message boxes.        
    gpointer main_window_v;
//! Widget on main gui that conatains the decoded text.
    gpointer decoded_text_v;
//! Displays the number of audio samples processed.
    gpointer samples_statusbar_v;
//! Displays the number of fft packets processed.
    gpointer ffts_statusbar_v;
//! Displays the current morse code speed in Words per Minute.
    gpointer wpm_statusbar_v;
//! Widget that displays the fft processed or raw audio packets.
    gpointer scope_v;
//! Widget containing adjustment frequency widget.
/*! \sa adjustment_frequency_v
*/
    gpointer hscale1_v;
//! Widget used to select audio frequency to decode.
/*! \sa hscale1_v
*/
    gpointer adjustment_frequency_v;
    gpointer label1_v;
//! Main gui toolbar.
    gpointer toolbar1_v;
//! Properties main gui.
    gpointer properties_v;
} main_gui;

//! Method that allocates the waveform data to be displayed by the scope_v widget.
/*! \sa scope_v plot_fft_data_array_destroy
    \param num_points size of array to create
*/
int32_t plot_fft_data_array_create(uint32_t num_points);

//! De-allocates array created by plot_fft_data_array_create.
/*! \sa plot_fft_data_array_create
*/
void plot_fft_data_array_destroy(void);

//! Used to enable/disable access to the preferences when the morse code threads are stopped/running.
void preferences_enabled(gboolean state);

uint32_t get_fft_data_size(void);
int32_t get_fft_graph_top(void);
uint32_t get_tone_packet_size(void);

//! Registers GUI handlers into Morse GUI Handler Interface.
void init_gui_interface_hooks(void);

//! This function is put into the GUI main loop to cancel running threads.
int32_t threads_stop(void);

/** Used to activate the appropriate bandwidth radio box when the application is started.
 *  \param bw Bandwidth in Hertz.
 */
void interface_activate_bw_chk_item(const int32_t bw);

extern GtkWidget* morse_stats;

void statistics_window_deleted_handler(void);

#endif /* INTERFACE_IL_H */
