#include <gnome.h>


void
on_morse2txt_properties_apply          (GnomePropertyBox *propertybox,
                                        gint             page_num,
                                        gpointer         user_data);

void
on_morse2txt_properties_show           (GtkWidget       *widget,
                                        gpointer         user_data);

void
widget_in_property_box_changed         (GtkComboBox     *combobox,
                                        gpointer         user_data);
