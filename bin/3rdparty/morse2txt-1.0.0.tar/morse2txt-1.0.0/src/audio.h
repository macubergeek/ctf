/*
 * Copyright (C) 2006:
 * Ken Prox <kprox@users.sourceforge.net>
 *
 * $Id: audio.h,v 1.30 2009/05/30 00:45:51 kprox Exp $
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */
#ifndef AUDIO_H
#define AUDIO_H

#include <stdint.h>

#define AUDIO_DEVICE_NAME_LENGTH    20

/** Pointer to audio device object. \sa audio_create */
typedef struct ts_audio_device *p_audio_device;
/** Pointer to audio api's \sa ts_audio_api */
typedef struct ts_audio_api *p_audio_api;

/** Audio segments used in audio record/playback */
typedef enum te_audio_segments {
/** Index for audio buffer segment 1. */
    BUFFER_SEGMENT_1 = 0,
/** Index for audio buffer segment 2. */
    BUFFER_SEGMENT_2,
/** Number of audio buffer segments.
    The audio buffer is broken up into 2 segments.  
	That is, th audio buffer looks like this:\n
	[<---- Segment 1 ---->|<---- Segment 2 ---->]\n\n
	When audio data is being written to Segment 1, Segment 2 is\n
	being post processed. And visa versa.
*/
    AUDIO_BUFFER_SEGMENTS
} te_audio_segments;

/** Audio segments used in audio record/playback */
typedef enum te_audio_channels {
/** One Channel. */
    AUDIO_MONO = 0,
/** Two Channels. */
    AUDIO_STEREO
} te_audio_channels;

typedef void (*message_handler)(char* message);
typedef void (*audio_error_message_handler)(char* error_message);

/** Audio direction, record or play */
typedef enum te_audio_rec_play {
    AUDIO_DEVICE_RECORD = 0,
    AUDIO_DEVICE_PLAY
} te_audio_rec_play;

/** Part of audio object that are accessable by the OSS and ALSA API's \sa p_audio_device */
typedef struct ts_audio_pub {
    /** Record or Playback device \sa te_audio_rec_play */
    te_audio_rec_play play_record;
    /** Both OSS and ALSA devices are opened via a name. */
    char name[AUDIO_DEVICE_NAME_LENGTH];
    /** Number of bits per sample. */
    int32_t samplesize;
    /** Sample frequency of audio device in Hertz.. */
    int32_t sample_frequency;
    /** LE or BE. */
    int32_t format;
    /** IO handle for audio device, -1 if unable to open. */
    int32_t handle;
    /** Number of audio buffer segments.
     *  @sa te_audio_segments */
    te_audio_segments buffer_segments;
    /** Number of bytes in the audio buffer (twice samples per segment). */
    int32_t audio_buffer_size;
    int32_t fragsize;
    /** The raw audio buffer. */
    uint8_t *audio_buffer_raw;
    /** Number of DSP channels. */
    te_audio_channels dsp_channels;
    int32_t samples;
    /** Callback for GUI handler to display error messages. */
    audio_error_message_handler error_msg_handler;
} ts_audio_pub, *p_audio_pub;

/** Audio API that morse2txt will use to control OSS or ALSA audio devices. */
typedef struct ts_audio_api {
    char*   audio_device_type_name;
    int32_t (*open)(p_audio_pub device);
    int32_t (*init)(p_audio_pub device);
    int32_t (*close)(p_audio_pub device);
    void (*play)(p_audio_pub device, te_audio_segments buffer_segment);
    void (*record)(p_audio_pub device, te_audio_segments buffer_segment);
} ts_audio_api;

/** Used to terminate search for supported audio device types. */
#define AUDIO_DEVICE_TEMINATOR {0, NULL, NULL, NULL, NULL, NULL}

/** Creates an audio object.
 *  \param device_type OSS, ALSA, ... 
 *  \param rec_play REcord or Playback device. \sa te_audio_rec_play
 *  \returns Pointer to audio object. \sa p_audio_device
 */
p_audio_device audio_create(uint32_t device_type,
                            te_audio_rec_play rec_play
                           );

/** Open audio device.
 *  \note Audio device MUST be created first. \sa audio_create
 *  \param device Pointer to audio device object. \sa p_audio_device
 *  \param sample_frequency Sample frequency in Hertz.
 *  \returns -1 if error, 0 if no error.
 */
int32_t audio_open(p_audio_device device, int32_t sample_frequency);

/** Close audio device.
 *  \note Audio device MUST be created first. \sa audio_create
 *  \param device Pointer to audio device object. \sa p_audio_device
 *  \returns -1 if error, 0 if no error.
 */
int32_t audio_close(p_audio_device device);

/** Initialize audio device.
 *  \note Audio device MUST be opened first. \sa audio_open
 *  \param device Pointer to audio device object. \sa p_audio_device
 *  \returns -1 if error, 0 if no error.
 */
int32_t audio_init(p_audio_device device);

/** Close and release audio device.
 *  \note Audio device MUST be created for this to apply. \sa audio_create
 *  \param device Pointer to audio device object. \sa p_audio_device
 *  \returns -1 if error, 0 if no error.
 */
int32_t audio_destroy(p_audio_device *device);

/** Capture raw audio data from audio device.
 *  @param device The audio device object. @sa p_audio_device
 *  @param buffer_segment The buffer segment to put data into.
*/
void audio_capture(p_audio_device device, te_audio_segments buffer_segment);

/** Blocking function that releases when buffer segment has been captured.
 *  @param device The audio device object. @sa p_audio_device
 *  @param buffer_segment The buffer segment capture to wait on.
*/
void audio_capture_wait(p_audio_device device, te_audio_segments buffer_segment);

/** Send raw audio data to audio device.
 *  @param device The audio device object. @sa p_audio_device
 *  @param buffer_segment The buffer segment to play.
*/
void audio_play(p_audio_device device, te_audio_segments buffer_segment);

/** Converts the raw audio data to real.
 *  @note Real data is required GSL's FFT library.
 *  @param device The audio device object. @sa p_audio_device
 *  @param buffer_segment the buffer segment to convert to real.
 *  @param audio_data Pointer to scaled audio data.
 */
void audio_raw2double(p_audio_device device, te_audio_segments buffer_segment, double *audio_data);

/** Converts double audio data to raw for soundcard.
 *  @param device The audio device object.
 *  @param buffer_segment the buffer segment to convert to fill with raw.
 *  @param audio_data Pointer to double formatted audio data.
    @note This assumes that the real audio data is not clipped.
 *  @sa p_audio_device
 */
void audio_double2raw(p_audio_device device, te_audio_segments buffer_segment, double *audio_data);

/** Used to register an external error message handler function. */
void register_error_message_handler(message_handler handler);

/** Returns the samples that will be captured by the audio device. \sa p_audio_device
 *  \param device Pointer to the audio device \sa audio_create
 *  \returns The number of samples to be acquired by the audio device.
 */ 
uint32_t audio_device_samples_get(p_audio_device device);

/** Get the number of audio device types supported (OSS, Alsa, etc.).
 *  @returns The number of audio device API's supported. 
 */ 
int32_t audio_supported_device_types_get(void);

/** Get the name of audio device type.
 *  @param audio_device_type_id Device type Id.
 *  @returns Pointer to the name of the audio device API (OSS, Alsa, ...) 
 */ 
char* audio_device_type_name_get(int32_t audio_device_type_id);

/** Set the audio device name, i.e. /dev/dsp.
 *  @param device Pointer to the audio device 
 *  @param name Audio device name to set.
 *  @sa audio_create
 */ 
void audio_device_name_set(p_audio_device device, const char *name);

/** Get the audio device name, i.e. /dev/dsp.
 *  @param device Pointer to the audio device 
 *  @param name Destination for audio device name.
 */ 
void audio_device_name_get(p_audio_device device, char **name);

/** Set the audio device sample rate.
 *  @param device Pointer to the audio device 
 *  @param Hertz Frequency in Hertz.
 */ 
void audio_sample_rate_set(p_audio_device device, int32_t Hertz);

/** Get the audio sample rate.
 *  @returns Sample rate in Hertz.
 */ 
int32_t audio_sample_rate_get(p_audio_device device);

#endif /* AUDIO_H */
