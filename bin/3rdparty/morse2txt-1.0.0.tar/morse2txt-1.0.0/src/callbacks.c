#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gnome.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "morse.h"
#include "interface_il.h"
#include "prop_interface.h"
#include "morse_stats_i.h"

static void read_main_gui_user_preferences(void);

gboolean
on_MainWindow_delete_event             (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
    g_idle_add((GSourceFunc)threads_stop, NULL);
    read_main_gui_user_preferences();
    gtk_main_quit ();
    return FALSE;
}


void
on_exit1_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
    g_idle_add((GSourceFunc)threads_stop, NULL);
    read_main_gui_user_preferences();
    gtk_main_quit();
}


void
on_statistics_activate                 (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
    static gboolean show_gb;
    
    if(NULL == morse_stats) {
        morse_stats = create_stats_window();
    }

    if(FALSE == show_gb) {
        gtk_widget_show(morse_stats);
        show_gb = TRUE;
    }
    else {
        gtk_widget_hide(morse_stats);
        show_gb = FALSE;
    }
}


void
on_preferences_activate                (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
    main_gui.properties_v = create_morse2txt_properties ();
    gtk_widget_show (main_gui.properties_v);
}

void
on_filter_bw_activate                    (GtkMenuItem     *menuitem,
                                          gpointer         user_data)
{
    int freq;
    /** Workaround for multiple callbacks. */
    char *tmp = ((char*)user_data);
    
    switch(tmp[0]) {
        case 'a':
            freq = 25;
            break;
            
        case 'b':
            freq = 50;
            break;
            
        case 'c':
            freq = 100;
            break;
            
        case 'd':
            freq = 150;
            break;
            
        case 'e':
            freq = 200;
            break;
            
        case 'f':
            freq = 250;
            break;
            
        case 'g':
            freq = 500;
            break;
            
        default:
        case 'h':
            freq = 1000;
            break;
    }            
    morse_set_filter_bandwidth(freq);
}

void
on_icons_and_or_text_activate          (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
    /** Workaround for multiple callbacks. */
    char *tmp = ((char*)user_data);
    
    switch(tmp[0])
    {
        case 'a':
            if(main_gui.toolbar1_v) { /* a hack to get rid of Gtk warnings when application is first run */
                gtk_toolbar_set_style (GTK_TOOLBAR(main_gui.toolbar1_v), GTK_TOOLBAR_ICONS);
            }
            main_gui.toolbar_style = GTK_TOOLBAR_ICONS;
            break;
        
        case 'b':
            if(main_gui.toolbar1_v) { /* a hack to get rid of Gtk warnings when application is first run */
                gtk_toolbar_set_style(GTK_TOOLBAR(main_gui.toolbar1_v), GTK_TOOLBAR_TEXT);
            }
            main_gui.toolbar_style = GTK_TOOLBAR_TEXT;
            break;
            
        default:
        case 'c':
            if(main_gui.toolbar1_v) { /* a hack to get rid of Gtk warnings when application is first run */
                gtk_toolbar_set_style (GTK_TOOLBAR(main_gui.toolbar1_v), GTK_TOOLBAR_BOTH);
            }    
            main_gui.toolbar_style = GTK_TOOLBAR_BOTH;
            break;
    }
}

void
on_startbutton_clicked                 (GtkToolButton   *toolbutton,
                                        gpointer         user_data)
{
    if(morse_get_thread_state() == THREADS_NOT_RUNNING) {
        if(
             (0 == plot_fft_data_array_create( get_tone_packet_size() ))
                && \
             (0 == morse_start_threads())
          )     
        {
            preferences_enabled(FALSE);
        }            
        else {
            preferences_enabled(TRUE);
        }
    }        
}

void
on_stop_button_clicked                 (GtkToolButton   *toolbutton,
                                        gpointer         user_data)
{
    g_idle_add((GSourceFunc)threads_stop, NULL);
}

void
on_clear_txt_button_clicked            (GtkToolButton   *toolbutton,
                                        gpointer         user_data)
{
    GtkTextIter start, end;

    gtk_text_buffer_get_bounds(GTK_TEXT_VIEW(main_gui.decoded_text_v)->buffer, &start, &end);
    gtk_text_buffer_delete(GTK_TEXT_VIEW(main_gui.decoded_text_v)->buffer, &start, &end);
}

void
on_scope_fft_button_clicked            (GtkToolButton   *toolbutton,
                                        gpointer         user_data)
{
    switch(morse_get_plot_type()) {
    default:
        case PLOT_FFT:
            morse_set_plot_type(PLOT_SCOPE);
            gtk_widget_hide(main_gui.label1_v);
            gtk_widget_hide(main_gui.hscale1_v);
            gtk_curve_set_range(GTK_CURVE(main_gui.scope_v), 0.0, (gfloat)morse_get_fft_data_size(), -32000.0, 32000.0);
            break;
        case PLOT_SCOPE:
            morse_set_plot_type(PLOT_FFT);
            gtk_widget_show(main_gui.hscale1_v);
            gtk_widget_show(main_gui.label1_v);
            gtk_curve_set_range(GTK_CURVE(main_gui.scope_v), 0.0, (gfloat)morse_get_tone_packet_size(), 0.0, morse_get_fft_graph_top());
            break;
    }
}

void
on_agc_apply_btn_toggled               (GtkToggleToolButton *toggletoolbutton,
                                        gpointer         user_data)
{
    te_morse_agc_enable tmp;
    
    tmp = MORSE_DISABLE_AGC;        
    
    if(gtk_toggle_tool_button_get_active(GTK_TOGGLE_TOOL_BUTTON(toggletoolbutton)) == TRUE) {
        tmp = MORSE_ENABLE_AGC;        
    }
    morse_set_agc_apply(tmp);
}

void
on_enable_fir_button_toggled           (GtkToggleToolButton *toggletoolbutton,
                                        gpointer         user_data)
{
    te_morse_filter_enable tmp;
    
    tmp = MORSE_DISABLE_FILTER;        
    
    if(gtk_toggle_tool_button_get_active(GTK_TOGGLE_TOOL_BUTTON(toggletoolbutton)) == TRUE) {
        tmp = MORSE_ENABLE_FILTER;        
    }
    morse_set_filter_apply(tmp);
}

void
on_exit_button_clicked                 (GtkToolButton   *toolbutton,
                                        gpointer         user_data)
{
    g_idle_add((GSourceFunc)threads_stop, NULL);
    read_main_gui_user_preferences();
    gtk_main_quit();
}


void
on_adjustment_release_event        (GtkAdjustment   *widget,
                                    gpointer         user_data)
{
    morse_set_cw_frequency((int)gtk_adjustment_get_value(GTK_ADJUSTMENT(widget))); 
}

static void read_main_gui_user_preferences(void)
{
    GtkWidget *widget;
    main_gui.x = GTK_WIDGET(main_gui.main_window_v)->allocation.x;
    main_gui.y = GTK_WIDGET(main_gui.main_window_v)->allocation.y;
    main_gui.width = GTK_WIDGET(main_gui.main_window_v)->allocation.width;
    main_gui.height = GTK_WIDGET(main_gui.main_window_v)->allocation.height;
    widget = lookup_widget(main_gui.main_window_v, "vpaned1");
    main_gui.pane_position = gtk_paned_get_position(GTK_PANED(widget));
}
