/*
 * $Id: dglitch.h,v 1.8 2009/05/30 00:45:51 kprox Exp $
 *
 * Copyright (C) 2002-2006:
 * Ken Prox <kprox@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */
#ifndef DGLITCH_H
#define DGLITCH_H

#include <stdint.h>

/** De-glitch algorithm types. */
typedef enum {
    DG_MEDIAN = 0,
    DG_NUMBER_OF_DGLITCH_ALGORS
} te_dglitch_type;

/** Pointer to the deglitch object. */
typedef struct ts_dglitch *p_dglitch;

/** Creates a deglitch object.
 *  @param type Type of DeGlitch object to create. @sa te_dglitch_type
 *  @param window_size Number of consecutive samples used to compute one deglitched value.
 *  @returns Pointer to the created deglitch object.
 */
p_dglitch dglitch_create(te_dglitch_type type, uint32_t window_size);

/** Destroys, and frees all memory from a deglitch object.
 *  \param dg Pointer to the deglitch object to be freed.
 */
void dglitch_destroy(p_dglitch *dg);

/** Apply the deglitch algorith to the data.
 *  \param dg Pointer to the deglitch object.
 *  \param data Pointer to the data to be deglitched.
 *  \param size Number of data points in data.
 */
void dglitch_apply(p_dglitch dg, double *data, uint32_t size);

#endif  /* DGLITCH_H */
