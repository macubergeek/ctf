/*
 * morse: a morse code decoder for use with a soundcard.
 *
 * Copyright (C) 2002-2006:
 * Ken Prox <kprox@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
*/

#include <gnome.h>
#include <gdk/gdk.h>
#include <glib.h>

#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif

#include "interface.h"
#include "interface_il.h"
#include "support.h"
#include "preferences.h"
#include "morse.h"

int main(int argc, char *argv[])
{
  GtkWidget *MainWindow;

  morse_initialize();
  init_gui_interface_hooks();
 /* init threads */
  g_thread_init(NULL);
  gdk_threads_init();
  
  gtk_set_locale ();

  gnome_init("morse2txt", VERSION, argc, argv);
  /*
   * The following code was added by Glade to create one of each component
   * (except popup menus), just so that you see something after building
   * the project. Delete any components that you don't want shown initially.
   */
  load_config_file();

  MainWindow = create_MainWindow ();
  interface_activate_bw_chk_item(morse_get_filter_bandwidth());
  gtk_widget_show (MainWindow);

  gdk_threads_enter();
  gtk_main ();
  gdk_threads_leave();

  save_config_file();

  morse_shutdown();

  return 0;
}




