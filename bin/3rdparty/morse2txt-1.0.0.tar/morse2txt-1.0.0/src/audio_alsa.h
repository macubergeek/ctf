/*
 * $Id: audio_alsa.h,v 1.4 2009/05/30 00:45:51 kprox Exp $
 *
 * Copyright (C) 2002-2006:
 * Ken Prox <kprox@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */
#ifndef AUDIO_ALSA_H
#define AUDIO_ALSA_H

#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif

#include "audio.h"

#ifdef HAVE_ALSA_ASOUNDLIB_H 
    #define audio_open_alsa NULL
    #define audio_init_alsa NULL
    #define audio_close_alsa NULL
    #define audio_record_alsa NULL
    #define audio_play_alsa NULL
#else /* HAVE_ALSA_ASOUNDLIB_H */
    #define audio_open_alsa NULL
    #define audio_init_alsa NULL
    #define audio_close_alsa NULL
    #define audio_record_alsa NULL
    #define audio_play_alsa NULL
#endif /* HAVE_ALSA_ASOUNDLIB_H */

#endif /* AUDIO_ALSA_H */
