/*
 * $Id: fir_win.h,v 1.9 2009/05/30 00:45:51 kprox Exp $
 *
 * Copyright (C) 2002-2006:
 * Ken Prox <kprox@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */
#ifndef FIR_WIN_H
#define FIR_WIN_H

#include <stdint.h>

/** Enables (1) or disables (0) Window function support. */
#define FWIN_USE_WINDOW_FUNCTION 1

/** FIR filter types. */
typedef enum {
    /*! Bandpass filter */
    FW_BANDPASS = 0,
    /*! Bandstop filter \todo Implement bandstop. */
    FW_BANDSTOP,
    /*! Lowpass filter \todo Implement lowpass. */
    FW_LOWPASS,
    /*! Highpass filter \todo Implement highpass. */
    FW_HIGHPASS,
    /*! Average filter 
     *  Sample frequency, low and high cutoff frequency, and window type do not apply.
     */
    FW_AVERAGE,
    FW_NUMBER_OF_FILTER_TYPES
} te_fir_win_filter_type;

/** Fir Filter coefficient window.  */
typedef enum {
    FW_NONE = 0,
    FW_HAMMING,
    FW_HANNING,
    FW_BLACKMAN,
    FW_NUMBER_OF_WINDOW_TYPES
} te_fir_win_window_type;

/** Pointer to Fir Window filter. */
typedef struct ts_fwin *p_fwin;

/** Creates a FIR filter via the window method.
  * \param sample_freq Sample frequency in Hertz.
  * \param f_low Low frequency cut-off in Hertz.
  * \param f_high High frequency cut-off in Hertz.
  * \param filter_type Filter type, band-pass, high-pass, low-pass, etc...
  * \param window_type Window applied to the FIR filter coefficients.
  * \param taps Number of FIR filter taps (N).
  * \returns Pointer to the FIR filter object.
 */
p_fwin fwin_create(double sample_freq,
                   double f_low,
                   double f_high,
                   te_fir_win_filter_type filter_type,
                   te_fir_win_window_type window_type,
                   uint32_t taps);

/** Changes the frequency response of an existing FIR filter.
  * \param fw Pointer to existing FIR filter object.
  * \param f_low New low frequency cut-off in Hertz.
  * \param f_high New high frequency cut-off in Hertz.
 */
void fwin_change_freq(p_fwin fw,
                      double f_low,
                      double f_high);

/** Destroys, and frees all memory from a window FIR filter object.
  * \param fw Pointer to the FIR filter object to be freed.
 */
void fwin_destroy(p_fwin *fw);

/** Apply the FIR filter to sampled data.
  * \param fw Pointer to the FIR filter object.
  * \param data Pointer to the data to be filtered.
  * \param size Number of data points in data.
 */
void fwin_apply(p_fwin fw, double *data, uint32_t size);

#endif  /* FIR_WIN_H */
