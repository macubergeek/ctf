#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gnome.h>
#include <stdint.h>

#include "prop_callbacks.h"
#include "prop_interface.h"
#include "support.h"

#include "preferences.h"
#include "morse.h"
#include "audio.h"
#include "interface_il.h"

#define ENTRY_LENGTH    10

void
on_morse2txt_properties_apply          (GnomePropertyBox *propertybox,
                                        gint             page_num,
                                        gpointer         user_data)
{
    const gchar *s = NULL;
    GtkWidget *tmp;
    static char ctmp[AUDIO_DEVICE_NAME_LENGTH];
    
    tmp = lookup_widget(main_gui.properties_v, "comboboxentryDevicePath");
    s = gtk_combo_box_get_active_text(GTK_COMBO_BOX(tmp));
    g_snprintf(ctmp, AUDIO_DEVICE_NAME_LENGTH, "%s", s);
    audio_device_name_set(morse_audio_rec_dev_get(), ctmp);
    
    tmp = lookup_widget(main_gui.properties_v, "comboboxentryDeviceType");
    morse_audio_device_type_id_set((int32_t)gtk_combo_box_get_active(GTK_COMBO_BOX(tmp)));
    
    tmp = lookup_widget(main_gui.properties_v, "comboboxentrySampleFrequency");
    morse_audio_sample_rate_set(atoi(gtk_combo_box_get_active_text(GTK_COMBO_BOX(tmp))));
    
    tmp = lookup_widget(main_gui.properties_v, "comboboxentryFFTPacketLength");
    morse_set_tone_packet_size(atoi(gtk_combo_box_get_active_text(GTK_COMBO_BOX(tmp))));

    tmp = lookup_widget(main_gui.properties_v, "comboboxentryFilterTaps");
    morse_set_filter_taps(atoi(gtk_combo_box_get_active_text(GTK_COMBO_BOX(tmp))));
    
    morse_set_fft_data_size(morse_get_tone_packet_size() / FFT_DATA_SIZE_DIVISOR);
    gtk_curve_set_range (GTK_CURVE (main_gui.scope_v), 0.0, (gfloat)morse_get_fft_data_size(), 0.0, morse_get_fft_graph_top());
    
    gtk_adjustment_set_value(GTK_ADJUSTMENT(main_gui.adjustment_frequency_v), 0.0);
    GTK_ADJUSTMENT(main_gui.adjustment_frequency_v)->lower = 0.0;
    GTK_ADJUSTMENT(main_gui.adjustment_frequency_v)->upper = (gfloat)(morse_get_fft_data_size() - 1);
}


void
on_morse2txt_properties_show           (GtkWidget       *widget,
                                        gpointer         user_data)
{
    GtkWidget *tmp;
    double freq_resolution, max_wpm;
    int packet_length, sample_freq;
    static char c_tmp[ENTRY_LENGTH];
    char *tmp_char;
    int32_t i;

    sample_freq = morse_audio_sample_rate_get();
    packet_length = morse_get_tone_packet_size();

    freq_resolution = (double)sample_freq / (double)packet_length;
    max_wpm = morse_max_wpm_supported((double)sample_freq, (double)packet_length);

    g_snprintf(c_tmp, ENTRY_LENGTH, "%d", morse_get_tone_packet_size());
    tmp = lookup_widget(main_gui.properties_v, "comboboxentryFFTPacketLength");
    gtk_entry_set_text(GTK_ENTRY(GTK_BIN(tmp)->child), c_tmp);

    g_snprintf(c_tmp, ENTRY_LENGTH, "%2.1f", freq_resolution);
    tmp = lookup_widget(main_gui.properties_v, "frequency_resolution_entry");
    gtk_entry_set_text(GTK_ENTRY(tmp), c_tmp);

    g_snprintf(c_tmp, ENTRY_LENGTH, "%2.1f", max_wpm);
    tmp = lookup_widget(main_gui.properties_v, "maximum_wpm_entry");
    gtk_entry_set_text(GTK_ENTRY(tmp), c_tmp);

    g_snprintf(c_tmp, ENTRY_LENGTH, "%d", sample_freq);
    tmp = lookup_widget(main_gui.properties_v, "comboboxentrySampleFrequency");
    gtk_entry_set_text(GTK_ENTRY(GTK_BIN(tmp)->child), c_tmp);
    
    tmp = lookup_widget(main_gui.properties_v, "comboboxentryDevicePath");
    audio_device_name_get(morse_audio_rec_dev_get(), &tmp_char);
    gtk_entry_set_text(GTK_ENTRY(GTK_BIN(tmp)->child), tmp_char);

    tmp = lookup_widget(main_gui.properties_v, "comboboxentryFilterTaps");
    g_snprintf(c_tmp, ENTRY_LENGTH, "%d", morse_get_filter_taps());
    gtk_entry_set_text(GTK_ENTRY(GTK_BIN(tmp)->child), c_tmp);

    tmp = lookup_widget(main_gui.properties_v, "comboboxentryDeviceType");
    i = 0;
    while(NULL != (tmp_char = audio_device_type_name_get(i))) {
        gtk_combo_box_append_text(GTK_COMBO_BOX(tmp), tmp_char);
        i++;
    }
    gtk_combo_box_set_active(GTK_COMBO_BOX(tmp), (gint)morse_audio_device_type_id_get());

    gnome_property_box_set_modified(GNOME_PROPERTY_BOX(main_gui.properties_v), FALSE);
}


void
widget_in_property_box_changed         (GtkComboBox     *combobox,
                                        gpointer         user_data)
{
    GtkWidget *tmp;
    double freq_resolution, max_wpm;
    int packet_length, sample_freq;

    char c_tmp[ENTRY_LENGTH];

    gnome_property_box_changed (GNOME_PROPERTY_BOX (main_gui.properties_v));

    tmp = lookup_widget(main_gui.properties_v, "comboboxentrySampleFrequency");
    sample_freq = atoi(gtk_entry_get_text(GTK_ENTRY(GTK_BIN(tmp)->child)));

    tmp = lookup_widget(main_gui.properties_v, "comboboxentryFFTPacketLength");
    packet_length = atoi(gtk_entry_get_text(GTK_ENTRY(GTK_BIN(tmp)->child)));

    freq_resolution = (double)sample_freq / (double)packet_length;
    max_wpm = morse_max_wpm_supported((double)sample_freq, (double)packet_length);

    g_snprintf(c_tmp, ENTRY_LENGTH, "%2.1f", freq_resolution);
    tmp = lookup_widget(main_gui.properties_v, "frequency_resolution_entry");
    gtk_entry_set_text(GTK_ENTRY(tmp), c_tmp);

    g_snprintf(c_tmp, ENTRY_LENGTH, "%2.1f", max_wpm);
    tmp = lookup_widget(main_gui.properties_v, "maximum_wpm_entry");
    gtk_entry_set_text(GTK_ENTRY(tmp), c_tmp);
}
