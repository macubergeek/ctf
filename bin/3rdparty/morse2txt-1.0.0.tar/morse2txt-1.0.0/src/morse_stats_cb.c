#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gnome.h>

#include "morse_stats_cb.h"
#include "morse_stats_i.h"
#include "support.h"
#include "interface_il.h"

void
on_stats_window_show                   (GtkWidget       *widget,
                                        gpointer         user_data)
{

}

gboolean
on_stats_window_delete_event           (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
    statistics_window_deleted_handler();
    return FALSE;
}

